-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2021 at 01:17 AM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ogamc_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `lname` varchar(45) DEFAULT NULL,
  `fname` varchar(45) DEFAULT NULL,
  `mname` varchar(45) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `sex` varchar(45) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `contact` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `code` varchar(45) DEFAULT NULL,
  `pass` varchar(45) DEFAULT NULL,
  `date_added` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `lname`, `fname`, `mname`, `age`, `sex`, `birthdate`, `address`, `contact`, `email`, `code`, `pass`, `date_added`, `status`) VALUES
(1, 'Basallote', 'John Jordan', 'Maniclang', 20, 'M', '2020-03-11', 'Marinig', '09654654545', 'jordan24@gmail.com', 'jordan', 'jordanasd', '11/05/2021', 1),
(2, 'Diesta', 'Shaira', 'Garcia', 20, 'F', '1998-03-15', 'Marinig', '09856323365', 'shaira@gmail.com', 'shaira', 'shaira', '11/05/2021', 1),
(16, 'Metica', 'Marlyn', 'Gonzales', 20, 'F', '2020-03-06', 'b', '09856326598', 'marylyn@gmail.com', 'marlyn', 'marlyn', '11/04/2021', 1),
(17, 'Pedido', 'Mozart King', 'Pedido', 20, 'F', '1998-03-10', 'Marinig', '09856269856', 'mozart@yahoo.com', 'mozart', 'mozart', '11/05/2021', 0),
(18, 'Senica', 'Raffy', 'Tulfo', 20, 'M', '1998-03-18', 'Marinig', '09856326598', 'raff@gmail.com', 'raffy', 'raffy', '11/05/2021', 0),
(19, 'Herrera', 'Blessie', 'Lirio', 20, 'F', '1998-03-11', 'a', '09291389218', 'blessie@gmail.com', 'blessy', 'blessy', '11/04/2021', 0),
(20, 'Alegre', 'Elliezar', 'Larios', 22, 'M', '1999-11-17', 'SPL', '09091273828', 'Ellie525@gmail.com', 'ellie', '12345', '11/10/2021', 1);

-- --------------------------------------------------------

--
-- Table structure for table `areacode`
--

CREATE TABLE `areacode` (
  `areacode_id` int(11) NOT NULL,
  `areacode` varchar(20) NOT NULL,
  `description` varchar(40) NOT NULL,
  `remarks` varchar(50) NOT NULL,
  `date_added` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `areacode`
--

INSERT INTO `areacode` (`areacode_id`, `areacode`, `description`, `remarks`, `date_added`, `status`) VALUES
(1, 'RMA1', 'BLD 1', 'Class Room', '2021-11-06', 1),
(2, 'RMA2', 'BLD 1', 'Class Room', '2021-11-05', 1),
(3, 'RMB1', 'BLD2', 'Class Room', '2021-11-12', 0),
(4, 'CLAB1', 'BLD1', 'Computer Lab', '2021-11-05', 1),
(5, 'CLAB2', 'BLD1', 'Computer Lab', '2021-11-05', 1),
(6, 'RCA1', 'BLD3', 'Class Room', '2021-11-05', 0),
(7, 'RCAB', 'BLD 3', 'Class Room', '2021-11-10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `company_id` int(11) NOT NULL,
  `company_name` varchar(45) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `contact` varchar(11) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `date_added` varchar(45) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`company_id`, `company_name`, `description`, `contact`, `email`, `address`, `date_added`, `status`) VALUES
(1, 'College of Computer Studies', 'College Dept.', '09484542545', 'CCS@gmail.com', 'SPCPC BLD', '11/08/2021', 1),
(2, 'College of Engineering', 'College Dept.', '09896545456', 'COE@gmail.com', 'SPCPC BLD', '11/08/2021', 1),
(3, 'College of Business Administration', 'College Dept.', '09654544645', 'CBAA@yahoo.com', 'SPCPC BLD 1A', '11/08/2021', 0),
(4, 'College of ICT ', 'College Dept.', '09545669855', 'ICTfedco089@gmail.com', 'SPCPC BLD 1B', '11/08/2021', 1),
(5, 'College of Education', 'College Dept.', '09667346562', 'COED@gmail.com', 'SPCPC', '11/08/2021', 1),
(6, 'College of Nursing', 'College Dept.', '09454545454', 'CON@gmail.com', 'SPCPC', '11/08/2021', 0),
(7, 'College of Business Accountancy', 'College Dept.', '09484564564', 'CBA@gmail.com', 'SPCPC BLD 1A', '11/08/2021', 0),
(8, 'College of Information Technology', 'College Dept.', '09397482763', 'CIT@gmail.com', 'SPCPC BLD 1A', '11/08/2021', 1),
(9, 'College of Arts and Sciences', 'College Dept.', '09012893787', 'CAS@yahoo.com', 'SPCPC', '11/08/2021', 0);

-- --------------------------------------------------------

--
-- Table structure for table `coordinator`
--

CREATE TABLE `coordinator` (
  `coordinator_id` int(11) NOT NULL,
  `lname` varchar(45) DEFAULT NULL,
  `fname` varchar(45) DEFAULT NULL,
  `mname` varchar(45) DEFAULT NULL,
  `age` varchar(2) DEFAULT NULL,
  `sex` varchar(1) DEFAULT NULL,
  `birthdate` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `contact` varchar(11) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `code` varchar(45) DEFAULT NULL,
  `pass` varchar(45) DEFAULT NULL,
  `date_added` varchar(45) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coordinator`
--

INSERT INTO `coordinator` (`coordinator_id`, `lname`, `fname`, `mname`, `age`, `sex`, `birthdate`, `address`, `contact`, `email`, `code`, `pass`, `date_added`, `status`) VALUES
(1, 'Galpo', 'Armie', 'Bakla', '24', 'F', '1997-03-17', 'San Isidro', '09645454545', 'armie123@yahoo.com', 'armie', 'armie', '11/05/2021', 0),
(2, 'Pos', 'Philip', 'David', '23', 'M', '1997-03-12', 'Marinig', '09565564545', 'philip@gmail.com', 'philip', 'philip', '11/05/2021', 0),
(3, 'Ceteriales', 'Christine Joy', 'Saludo', '22', 'F', '1997-03-19', 'San Isidro', '09454546546', 'cj1239@yahoo.com', 'cj', 'cj', '03/17/2020', 0),
(4, 'Nodo', 'Ronelyn', 'Castro', '21', 'F', '1998-03-18', 'Marinig', '09454564654', 'ronelyn@yahoo.com', 'ron', 'ron', '03/17/2020', 1),
(5, 'Ramos', 'Ace', 'Galang', '20', 'M', '1999-03-17', 'Bigaa', '09855454542', 'aceramos@yahoo.com', 'ace', 'ace', '11/05/2021', 1),
(6, 'Yncierto', 'Kim', 'Saldo', '20', 'F', '1999-03-17', 'Sta. Rosa', '09845215588', 'kim12939@yahoo.com', 'kim', 'kim', '11/05/2021', 1);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` int(11) NOT NULL,
  `coursecode_id` int(11) NOT NULL,
  `areacode_id` int(11) NOT NULL,
  `coursetitle_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `remarks` varchar(40) NOT NULL,
  `date_added` date NOT NULL,
  `approval` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `coursecode_id`, `areacode_id`, `coursetitle_id`, `unit_id`, `teacher_id`, `remarks`, `date_added`, `approval`, `status`) VALUES
(1, 1, 1, 1, 3, 1, 'LAB', '2021-11-09', 1, 0),
(2, 7, 1, 2, 3, 1, 'LEC', '2021-11-09', 1, 0),
(3, 7, 5, 5, 3, 5, 'LEC', '2021-11-09', 2, 1),
(4, 8, 1, 1, 3, 5, 'LEC', '2021-11-09', 2, 1),
(5, 9, 3, 3, 3, 3, 'LEC', '2021-11-09', 1, 0),
(6, 10, 5, 6, 3, 3, 'LEC', '2021-11-09', 1, 0),
(7, 5, 4, 6, 3, 1, 'Fine...', '2021-11-10', 1, 0),
(8, 6, 5, 6, 3, 1, 'Fine...', '2021-11-10', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `coursecode`
--

CREATE TABLE `coursecode` (
  `coursecode_id` int(11) NOT NULL,
  `coursecode` varchar(20) NOT NULL,
  `description` varchar(40) NOT NULL,
  `remarks` varchar(50) NOT NULL,
  `date_added` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coursecode`
--

INSERT INTO `coursecode` (`coursecode_id`, `coursecode`, `description`, `remarks`, `date_added`, `status`) VALUES
(1, 'CS102A', 'Computer Prorgamming 1', 'C++ and C#', '2021-11-05', 1),
(2, 'CS101A', 'Computer Fundamentals', 'Excel,Ms Word', '2021-11-05', 1),
(3, 'CS103', 'E-Commerce', 'TQM', '2021-11-05', 1),
(4, 'CS102B', 'Database Management', 'SQL, Acces', '2021-11-05', 1),
(5, 'CS102AL', 'Computer Programming', 'Computer Laboratory', '2021-11-05', 1),
(6, 'CS201', 'Computer Programming', 'GUI, JAVA', '2021-11-03', 1),
(7, 'RIZAL 1', 'RIZAL Lifeworks', 'Lecture Room', '2021-11-04', 0),
(8, 'FILIPINO 1', 'Sining at Pananaliksik', 'Lecture Room', '2021-11-05', 0),
(9, 'LIT 1', 'Literature', 'Lecture Room', '2021-11-05', 1),
(10, 'ETHICS 1', 'Ethics IT Politics', 'Lecture', '2021-11-08', 1),
(11, 'CS105A', 'Data Structure and Algorithms', 'Lecture', '2021-11-08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `coursetitle`
--

CREATE TABLE `coursetitle` (
  `coursetitle_id` int(11) NOT NULL,
  `coursetitle` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `remarks` varchar(50) NOT NULL,
  `date_added` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coursetitle`
--

INSERT INTO `coursetitle` (`coursetitle_id`, `coursetitle`, `description`, `remarks`, `date_added`, `status`) VALUES
(1, 'Associate Computer Technology', 'ACT', 'IT', '2021-11-05', 0),
(2, 'Information Computer Technology', 'ICT', 'IT', '2021-11-05', 0),
(3, 'Associate Computer Hardware', 'ACH', 'IT', '2021-11-05', 1),
(4, 'BS Information Technology Web Development', 'BSIT-WD', 'IT', '2021-11-05', 1),
(5, 'BS Information Technology Database Management', 'BSIT-DB', 'IT', '2021-11-05', 1),
(6, 'BS Computer Science', 'BSCS', 'CS', '2021-11-05', 1),
(7, 'BS Nursing', 'BSN', 'NS', '2021-11-10', 1),
(8, 'Associate Computer Secretarial', 'ASC', 'IT', '2021-11-10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `format`
--

CREATE TABLE `format` (
  `format_id` int(11) NOT NULL,
  `format` varchar(20) NOT NULL,
  `description` varchar(40) NOT NULL,
  `remarks` varchar(40) NOT NULL,
  `date_added` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `format`
--

INSERT INTO `format` (`format_id`, `format`, `description`, `remarks`, `date_added`, `status`) VALUES
(1, 'Presentation', 'Text...', 'Text...', '2021-11-08', 1),
(2, 'Workshop', 'Text...', 'Text...', '2021-11-08', 1),
(3, 'Zoom Presentation', 'Text...', 'Text...', '2021-11-08', 0),
(4, 'Zoom Activity', 'Text...', 'Text...', '2021-11-08', 0),
(5, 'Examinization', 'Comment...', 'Comment...', '2021-11-08', 0);

-- --------------------------------------------------------

--
-- Table structure for table `hrstaff`
--

CREATE TABLE `hrstaff` (
  `hrstaff_id` int(11) NOT NULL,
  `lname` varchar(45) DEFAULT NULL,
  `fname` varchar(45) DEFAULT NULL,
  `mname` varchar(45) DEFAULT NULL,
  `age` varchar(45) DEFAULT NULL,
  `sex` varchar(1) DEFAULT NULL,
  `birthdate` date DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `contact` varchar(11) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `code` varchar(45) DEFAULT NULL,
  `pass` varchar(45) DEFAULT NULL,
  `date_added` varchar(45) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hrstaff`
--

INSERT INTO `hrstaff` (`hrstaff_id`, `lname`, `fname`, `mname`, `age`, `sex`, `birthdate`, `address`, `contact`, `email`, `code`, `pass`, `date_added`, `status`) VALUES
(1, 'Tan', 'Janus Raymond', 'Garcia', '24', 'M', '1998-03-16', 'Marinig', '0985625698', 'janus11234@gmail.com', 'janus', 'janus', '11/05/2021', 0),
(2, 'Ogalesco', 'John Patrick', 'Hernandez', '22', 'M', '1997-03-10', 'Pulo', '09856265985', 'patrick@yahoo.com', 'patrick', 'patrick', '11/05/2021', 0),
(3, 'Hernandez', 'Gloria', 'Magaling', '24', 'F', '1999-03-17', 'Marinig', '09856325269', 'gloria@yahoo.com', 'gloria', 'gloria', '11/04/2021', 1),
(4, 'Alegre', 'Elliezar', 'Larios', '20', 'M', '1996-03-12', 'Pulo', '09564654654', 'ellie34@gmail.com', 'ellie', 'ellie', '03/19/2020', 1),
(5, 'Alegre', 'Jilliane Rose', 'Larios', '20', 'F', '2000-03-11', 'Pulo', '09454512315', 'jilliane877@yahoo.com', 'jilliane', 'jilliane', '03/19/2020', 1);

-- --------------------------------------------------------

--
-- Table structure for table `learn`
--

CREATE TABLE `learn` (
  `learn_id` int(11) NOT NULL,
  `learn` varchar(20) NOT NULL,
  `description` varchar(40) NOT NULL,
  `remarks` varchar(40) NOT NULL,
  `date_added` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `learn`
--

INSERT INTO `learn` (`learn_id`, `learn`, `description`, `remarks`, `date_added`, `status`) VALUES
(1, 'Class 1', 'Comment...', 'Comment...', '2021-11-08', 1),
(2, 'Class 2', 'Comment...', 'Comment...', '2021-11-08', 1),
(3, 'Class 3', 'Comment...', 'Comment...', '2021-11-08', 1),
(4, 'Class 4', 'Comment...', 'Comment...', '2021-11-08', 1),
(5, 'Class 5', 'Remarks...', 'Remarks...', '2021-11-08', 0),
(6, 'Class 6', 'Remarks...', 'Remarks...', '2021-11-08', 0),
(7, 'Class 7', 'Content...', 'Content...', '2021-11-08', 0),
(8, 'Class 8', 'Text...', 'Text...', '2021-11-08', 1),
(9, 'Class 9', 'Fine...', 'Fine...', '2021-11-08', 0);

-- --------------------------------------------------------

--
-- Table structure for table `module`
--

CREATE TABLE `module` (
  `module_id` int(11) NOT NULL,
  `module` varchar(20) NOT NULL,
  `description` varchar(50) NOT NULL,
  `remarks` varchar(50) NOT NULL,
  `date_added` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `module`
--

INSERT INTO `module` (`module_id`, `module`, `description`, `remarks`, `date_added`, `status`) VALUES
(1, 'Module 1', 'Introduction', 'Fine...', '2021-11-08', 1),
(2, 'Module 2', 'Skills and Elements', 'Fine...', '2021-11-08', 1),
(3, 'Module 3', 'LSP', 'Comments...', '2021-11-08', 1),
(4, 'Module 2 (Cont.)', 'Skills and Elements', 'Fine...', '2021-11-08', 1),
(5, 'Student Presentation', 'Presentation', 'Content...', '2021-11-08', 0);

-- --------------------------------------------------------

--
-- Table structure for table `recruitment`
--

CREATE TABLE `recruitment` (
  `recruitment_id` int(11) NOT NULL,
  `lname` varchar(45) DEFAULT NULL,
  `fname` varchar(45) DEFAULT NULL,
  `mname` varchar(45) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `sex` varchar(1) DEFAULT NULL,
  `birthdate` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `contact` varchar(11) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `code` varchar(45) DEFAULT NULL,
  `pass` varchar(45) DEFAULT NULL,
  `date_added` varchar(45) DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `recruitment`
--

INSERT INTO `recruitment` (`recruitment_id`, `lname`, `fname`, `mname`, `age`, `sex`, `birthdate`, `address`, `contact`, `email`, `code`, `pass`, `date_added`, `status`) VALUES
(1, 'Rayala', 'Mhay', 'Flor', 24, 'F', '1995-03-17', 'Sta. Rosa', '09856325698', 'mhay@yahoo.com', 'mhay', 'mhay', '03/17/2020', 1),
(2, 'Ruiz', 'Stephanie Honey', 'Tiffany', 21, 'M', '1998-03-17', 'Sta. Rosa', '09856325698', 'step@yahoo.com', 'step', 'step', '03/17/2020', 1),
(3, 'Valdueza', 'April Lou', 'Castillo', 22, 'F', '1997-03-17', 'Tarikan', '09654564544', 'april_lou@yahoo.com', 'april', 'april', '03/17/2020', 1),
(4, 'Yncierto', 'Emmanuel', 'Sojaco', 22, 'M', '1997-03-17', 'Sta. Rosa', '09564654545', 'emman@yahoo.com', 'emman', 'emman', '11/08/2021', 1),
(5, 'Pedraja', 'Cecilia', 'Ramos', 24, 'F', '1996-03-17', 'Sta. Rosa', '09546456456', 'cecilia123@gmail.com', 'cecil', 'cecil', '03/17/2020', 0),
(6, 'Bautista', 'Luigi', 'Castillano', 21, 'F', '1998-03-17', 'Marinig', '09645646545', 'luigi87@yahoo.com', 'luigi', 'luigi', '11/08/2021', 0);

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` int(11) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `birthdate` date NOT NULL,
  `age` int(3) NOT NULL,
  `sex` varchar(1) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact` varchar(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `code` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `date_added` varchar(45) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `lname`, `fname`, `mname`, `birthdate`, `age`, `sex`, `address`, `contact`, `email`, `code`, `pass`, `date_added`, `status`) VALUES
(1, 'De Claro', 'Eunice', 'Larios', '1997-12-10', 24, 'F', 'San Roque SPL', '09128308128', 'eunice12@gmail.com', 'eunice', 'eunice789', '11/09/2021', 0),
(2, 'Juntura', 'Maricel', 'Barakuda', '2000-11-09', 21, 'F', 'San Roque SPL', '09192832838', 'junturam23@gmail.com', 'juntura', '09876', '11/08/2021', 1),
(3, 'Marasigan', 'Roel', 'Buenas', '1980-11-10', 31, 'M', 'Langgam SPL', '09912378127', 'roel231@gmail.com', 'roel', 'roel', '11/09/2021', 1),
(4, 'Orcega', 'Marian', 'Puring', '1979-11-09', 32, 'F', 'Calendola SPL', '09192387218', 'Marian546@gmail.com', 'marian', 'marian123', '11/10/2021', 1),
(5, 'Teroso', 'Michelle', 'Bueno', '1998-11-09', 23, 'F', 'Calendola SPL', '09128392173', 'Michelle231@gmail.com', 'bueno', 'bueno12', '11/08/2021', 0);

-- --------------------------------------------------------

--
-- Table structure for table `topic`
--

CREATE TABLE `topic` (
  `topic_id` int(11) NOT NULL,
  `topic` varchar(50) NOT NULL,
  `description` varchar(40) NOT NULL,
  `remarks` varchar(40) NOT NULL,
  `date_added` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `topic`
--

INSERT INTO `topic` (`topic_id`, `topic`, `description`, `remarks`, `date_added`, `status`) VALUES
(1, 'Basic Concepts', 'Text...', 'Text...', '2021-11-09', 1),
(2, 'Politics', 'Text...', 'Text...', '2021-11-09', 0),
(3, 'Vocabulary', 'Teaching', 'Teaching', '2021-11-09', 1),
(4, 'Phraseology', 'Teaching', 'Teaching', '2021-11-09', 1),
(5, 'LSP Application', 'Overview', 'Overview', '2021-11-09', 1),
(6, 'LSP Tools', 'Building and Analyzing ', 'Overview', '2021-11-09', 1),
(7, 'Teaching Grammar', 'Teaching', 'Teaching', '2021-11-09', 1),
(8, 'Discourse Organization', 'Teaching', 'Teaching', '2021-11-09', 0),
(9, 'Language Skill', 'Practicing', 'Teaching', '2021-11-09', 1),
(10, 'Miscellaneous Tools', 'Project Activities', 'Project Due', '2021-11-09', 1),
(11, 'Presentation', 'Student Projects', 'Student Projects', '2021-11-09', 1);

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE `unit` (
  `unit_id` int(11) NOT NULL,
  `unit` int(11) NOT NULL,
  `description` varchar(50) NOT NULL,
  `remarks` varchar(40) NOT NULL,
  `date_added` date NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`unit_id`, `unit`, `description`, `remarks`, `date_added`, `status`) VALUES
(1, 1, '1 unit', 'Lecture', '2021-11-08', 1),
(2, 2, '2 units', 'Lecture', '2021-11-08', 1),
(3, 3, '3 units', 'Pure Lab', '2021-11-08', 1),
(4, 5, '5 units Seminar', 'Pure Seminar', '2021-11-08', 1),
(5, 6, '6 units Pure Lab', 'Pure Lab', '2021-11-08', 1),
(6, 7, '7 units Pure Lecture', 'Pure Lecture', '2021-11-08', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `areacode`
--
ALTER TABLE `areacode`
  ADD PRIMARY KEY (`areacode_id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`company_id`);

--
-- Indexes for table `coordinator`
--
ALTER TABLE `coordinator`
  ADD PRIMARY KEY (`coordinator_id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `coursecode`
--
ALTER TABLE `coursecode`
  ADD PRIMARY KEY (`coursecode_id`);

--
-- Indexes for table `coursetitle`
--
ALTER TABLE `coursetitle`
  ADD PRIMARY KEY (`coursetitle_id`);

--
-- Indexes for table `format`
--
ALTER TABLE `format`
  ADD PRIMARY KEY (`format_id`);

--
-- Indexes for table `hrstaff`
--
ALTER TABLE `hrstaff`
  ADD PRIMARY KEY (`hrstaff_id`);

--
-- Indexes for table `learn`
--
ALTER TABLE `learn`
  ADD PRIMARY KEY (`learn_id`);

--
-- Indexes for table `module`
--
ALTER TABLE `module`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `recruitment`
--
ALTER TABLE `recruitment`
  ADD PRIMARY KEY (`recruitment_id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`);

--
-- Indexes for table `topic`
--
ALTER TABLE `topic`
  ADD PRIMARY KEY (`topic_id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`unit_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `areacode`
--
ALTER TABLE `areacode`
  MODIFY `areacode_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `company_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `coordinator`
--
ALTER TABLE `coordinator`
  MODIFY `coordinator_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `coursecode`
--
ALTER TABLE `coursecode`
  MODIFY `coursecode_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `coursetitle`
--
ALTER TABLE `coursetitle`
  MODIFY `coursetitle_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `format`
--
ALTER TABLE `format`
  MODIFY `format_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `hrstaff`
--
ALTER TABLE `hrstaff`
  MODIFY `hrstaff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `learn`
--
ALTER TABLE `learn`
  MODIFY `learn_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `module`
--
ALTER TABLE `module`
  MODIFY `module_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `recruitment`
--
ALTER TABLE `recruitment`
  MODIFY `recruitment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `teacher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `topic`
--
ALTER TABLE `topic`
  MODIFY `topic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `unit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
