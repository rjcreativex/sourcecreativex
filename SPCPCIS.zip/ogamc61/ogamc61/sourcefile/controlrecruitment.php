<?php 
    include '../sourcefile/functions.php';
?>
<?php 
    include 'themepart/mylinkcss.php';
?>
<?php 
    include 'themepart/admin.php';
?>
<?php 
    include 'themepart/top_menu.php';
?>
<br>
  <div class="content-wrapper">
     <form class="form-group">
        <div class="col-md-12">
        <div class="card bg-light">
        <div class="card-body">
             <h4 class="card-title" style="font-size:20px;"> Recruitment <i class="fa fa-users" style="font-size:24px"></i></h4>
             <p class="card-text">Control everything here. Create, Find, Activate and Deactivate Recruitment.</p>
             <button type="button" class="btn btn-success" data-toggle="modal" data-target="#createrecruitmentmodal"><i class="far fa-plus-square"></i> Add New Recruitment </button>
        </div>
      </div>
    </div>
  </form>
  
<form class="form-control-lg">
  <div class="input-group mb-3">
    <div class="input-group-prepend">
      <button class="btn btn-primary"><i class="fa fa-search"></i></button>
    </div>
    <input type="text" id="controlrecruitmentmaininput1" class="form-control form-control-lg" placeholder="Type anything you search.." style="font-size:14px;">
  </div>
</form><br>

    <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
            </div>
            <div class="card-body">
              <table id="datatablerecruitment2" class="table table-hover">
                <thead class="table-light">
                <tr>
                  <th># Recruitment ID</th>
                  <th>Lastname</th>
                  <th>Firstname</th>
                  <th>Middlename</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Recruitment ID</th>
                </tr>
                </thead>
                <tbody id="controlrecruitmentmainoutput1">
                <?php
                $recruitment = new Recruitment();
                $recruitment->startreadrecruitment();
                $recruitment_all = $recruitment->get_recruitment_credential("all");

                if($recruitment_all !== null) {
                    for( $r=0; $r < count($recruitment_all["recruitment_id"]); $r++ ) {
                        ?>
                        <tr>
                            <th scope="row"><?php echo $recruitment_all["recruitment_id"][$r] ?></th>
                            <td><?php echo $recruitment_all["lname"][$r];?></td>
                            <td><?php echo $recruitment_all["fname"][$r];?></td>
                            <td><?php echo $recruitment_all["mname"][$r];?></td>
                            <td><?php echo $recruitment_all["contact"][$r]; ?></td>
                            <td><?php echo $recruitment_all["email"][$r]; ?></td>
                            <td>
                            <button class="btn btn-success recruitment-record-table-row" data-toggle="modal" data-target="#updaterecruitmentmodal" data-recruitmentdata ='{ 
                            "recruitment_id" : "<?php echo $recruitment_all["recruitment_id"][$r] ?>",
                            "lname" : "<?php echo $recruitment_all["lname"][$r] ?>",
                            "fname" : "<?php echo $recruitment_all["fname"][$r] ?>",
                            "mname" : "<?php echo $recruitment_all["mname"][$r] ?>",   
                            "age" : "<?php echo $recruitment_all["age"][$r] ?>",
                            "sex" : "<?php echo $recruitment_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $recruitment_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $recruitment_all["address"][$r] ?>", 
                            "contact" : "<?php echo $recruitment_all["contact"][$r] ?>",
                            "email" : "<?php echo $recruitment_all["email"][$r] ?>", 
                            "code" : "<?php echo $recruitment_all["code"][$r] ?>", 
                            "pass" : "<?php echo $recruitment_all["pass"][$r] ?>", 
                            "status" : "<?php echo $recruitment_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                              <td>
                            <button class="btn btn-info recruitment-record-table-row-view" data-target="#recruitment1-<?php echo $recruitment_all["recruitment_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View </button>
                          </td>
                            <td>
                                <?php
                                    if ($recruitment_all["status"][$r]) echo '<span class="badge badge-success"style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger"style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
        <td>
        <?php echo $recruitment_all["recruitment_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="recruitment1-<?php echo $recruitment_all["recruitment_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-users"></i> Recruitment View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Recruitment code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Recruitment ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["recruitment_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                               <?php
                                    if ($recruitment_all["status"][$r]) echo '<span class="badge badge-success"style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger"style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
                        </tr>
                        <?php
                    }
                }
            ?> 
                </tbody id="controlrecruitmentmainoutput1">
                <tfoot class="table-light">
                <tr>
                  <th># Recruitment ID</th>
                  <th>Lastname</th>
                  <th>Firstname</th>
                  <th>Middlename</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Recruitment ID</th>
                </tr>
                </tfoot>
              </table>
            </div>
          </div>

      <form class="form-control-lg">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <button class="btn btn-primary"><i class="fa fa-search"></i></button>
            </div>
            <input type="text" id="controlrecruitmentmaininput2" class="form-control form-control-lg" placeholder="Type anything you search.." style="font-size:14px;">
            </div>
          </form><br>

          <div class="card">
            <div class="card-header">
              <h3 class="card-title"> Recruitment List <i class="fa fa-users" style="font-size:25px"></i></h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="datatablerecruitment1" class="table">
                <thead class="table-light">
                <tr>
                  <th># Recruitment ID</th>
                  <th>Lastname</th>
                  <th>Firstname</th>
                  <th>Middlename</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Recruitment ID</th>
                </tr>
                </thead>
                <tbody id="controlrecruitmentmainoutput2">
                 <?php
                $recruitment = new Recruitment();
                $recruitment->startreadrecruitment();
                $recruitment_all = $recruitment->get_recruitment_credential("all");

                if($recruitment_all !== null) {
                    for( $r=0; $r < count($recruitment_all["recruitment_id"]); $r++ ) {
                        ?>
                        <tr>
                            <th scope="row"><?php echo $recruitment_all["recruitment_id"][$r] ?></th>
                            <td><?php echo $recruitment_all["lname"][$r];?></td>
                            <td><?php echo $recruitment_all["fname"][$r];?></td>
                            <td><?php echo $recruitment_all["mname"][$r];?></td>
                            <td><?php echo $recruitment_all["contact"][$r]; ?></td>
                            <td><?php echo $recruitment_all["email"][$r]; ?></td>
                            <td>
                            <button class="btn btn-success recruitment-record-table-row" data-toggle="modal" data-target="#updaterecruitmentmodal" data-recruitmentdata ='{ 
                            "recruitment_id" : "<?php echo $recruitment_all["recruitment_id"][$r] ?>",
                            "lname" : "<?php echo $recruitment_all["lname"][$r] ?>",
                            "fname" : "<?php echo $recruitment_all["fname"][$r] ?>",
                            "mname" : "<?php echo $recruitment_all["mname"][$r] ?>",   
                            "age" : "<?php echo $recruitment_all["age"][$r] ?>",
                            "sex" : "<?php echo $recruitment_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $recruitment_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $recruitment_all["address"][$r] ?>", 
                            "contact" : "<?php echo $recruitment_all["contact"][$r] ?>",
                            "email" : "<?php echo $recruitment_all["email"][$r] ?>", 
                            "code" : "<?php echo $recruitment_all["code"][$r] ?>", 
                            "pass" : "<?php echo $recruitment_all["pass"][$r] ?>", 
                            "status" : "<?php echo $recruitment_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i></button>
                            </td>
                            <td>
                            <button class="btn btn-info recruitment-record-table-row-view" data-toggle="modal" data-target="#recruitment2-<?php echo $recruitment_all["recruitment_id"][$r]; ?>">
                                      <i class="fas fa-eye"></i> </button></td>
                            <td>
                                 <?php
                                    if ($recruitment_all["status"][$r]) echo '<span class="badge badge-success"style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger"style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
        <td>
        <?php echo $recruitment_all["recruitment_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="recruitment2-<?php echo $recruitment_all["recruitment_id"][$r];?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-users"></i> Recruitment View <i class="fa fa-eye"></i></h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Recruitment code is always unique.</small>
                    </div>
                      <table class="table">
                            <tr><th># Recruitment ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["recruitment_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                              <?php
                                    if ($recruitment_all["status"][$r]) echo '<span class="badge badge-success"style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger"style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
      </td>
                        </tr>
                        <?php
                    }
                }
            ?> 
                </tbody id="controlrecruitmentmainoutput2">
                <tfoot class="table-light">
                <tr>
                  <th># Recruitment ID</th>
                  <th>Lastname</th>
                  <th>Firstname</th>
                  <th>Middlename</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Recruitment ID</th>
                </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
    
        <div class="modal fade" id="createrecruitmentmodal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-users"></i> Recruitment Create </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Recruitment code is always unique.</small>
                    </div>

                <div class="form-group">
                    <div class="row">
                       <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                       <label class="text-sm">Lastname</label>
                     <input type="text" class="form-control form-control-sm" id="createrecruitmentmodal_lname" placeholder="Enter Lastname">
                     </div>

                     <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Firstname</label>
                        <input type="text" class="form-control form-control-sm" id="createrecruitmentmodal_fname" placeholder="Enter Firstname">
                    </div>

                   <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Middlename</label>
                        <input type="text" class="form-control form-control-sm" id="createrecruitmentmodal_mname" placeholder="Enter Middlename">
                    </div>
                  </div>
                </div>

            <div class="form-group">
                <div class="row">
                <div class="col-md-6">
                        <i class="fa fa-calendar"></i>
                        <label class="text-sm">Birthdate</label>
                        <input type="date" class="form-control form-control-sm" id="createrecruitmentmodal_birthdate" placeholder="Enter Birthday">
                        <span id="birthdate" style="color:red;display:none;"> * Your birthdate is invalid</span>
                    </div>
                    <div class="col-md-3">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Age</label>
                        <input type="text" class="form-control form-control-sm" id="createrecruitmentmodal_age" placeholder="Enter Age" maxlength="2">
                    </div>
                    <div class="col-md-3">
                          <i class="fa fa-intersex"></i>
                        <label class="text-sm">Sex</label>
                        <select class="custom-select form-control-sm" id="createrecruitmentmodal_sex">
                            <option value="M">Male</option>
                            <option value="F">Female</option>
                        </select>
                    </div>
                </div>
            </div>
                    <div class="form-group">
                         <i class="fa fa-address-card"></i>
                            <label class="text-sm">Address</label>
                        <textarea type="text" class="form-control form-control-sm" id="createrecruitmentmodal_address" 
                        placeholder="Enter Address"></textarea>
                    </div>
            <div class="form-group">
                 <div class="row">
                    <div class="col-md-4">
                            <i class="fa fa-phone-square"></i>
                            <label class="text-sm">Contact</label>
                        <input type="text" class="form-control form-control-sm" id="createrecruitmentmodal_contact" placeholder="Enter Contact" maxlength="11">
                    </div>

                    <div class="col-md-5">
                            <i class="fa fa-envelope-square"></i>
                            <label class="text-sm">Email</label>
                        <input type="text" class="form-control form-control-sm" id="createrecruitmentmodal_email" placeholder="Enter Email">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-md-6">
                      <i class="fa fa-id-card"></i>
                        <label class="text-sm">Username</label>
                        <input type="text" class="form-control form-control-sm" id="createrecruitmentmodal_code" placeholder="Enter Code">
                    </div>

                    <div class="col-md-6">
                        <i class="fa fa-eye-slash"></i>
                        <label class="text-sm">Password</label>
                        <input type="text" class="form-control form-control-sm" id="createrecruitmentmodal_pass" placeholder="Password">
                    </div>
                </div>
            </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-success" id="createrecruitmentmodalbutton">
                    <i class="fa fa-save"></i> Save Changes </button>
                </div>
            </div>
        </div>
    </div>
      <div class="modal fade" id="updaterecruitmentmodal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-users"></i> Recruitment Update </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Recruitment code is always unique.</small>
                        <input type="hidden" id="updaterecruitmentmodal_recruitment_id">
                    </div>

                <div class="form-group">
                    <div class="row">
                       <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                       <label class="text-sm">Lastname</label>
                     <input type="text" class="form-control form-control-sm" id="updaterecruitmentmodal_lname" placeholder="Enter Lastname">
                     </div>

                     <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Firstname</label>
                        <input type="text" class="form-control form-control-sm" id="updaterecruitmentmodal_fname" placeholder="Enter Firstname">
                    </div>

                   <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Middlename</label>
                        <input type="text" class="form-control form-control-sm" id="updaterecruitmentmodal_mname" placeholder="Enter Middlename">
                    </div>
                  </div>
                </div>

            <div class="form-group">
                <div class="row">
                <div class="col-md-6">
                        <i class="fa fa-calendar"></i>
                        <label class="text-sm">Birthdate</label>
                        <input type="date" class="form-control form-control-sm" id="updaterecruitmentmodal_birthdate" placeholder="Enter Birthday">
                        <span id="birthdate" style="color:red;display:none;"> * Your birthdate is invalid</span>
                    </div>
                    <div class="col-md-3">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Age</label>
                        <input type="text" class="form-control form-control-sm" id="updaterecruitmentmodal_age" placeholder="Enter Age" maxlength="2">
                    </div>
                    <div class="col-md-3">
                          <i class="fa fa-intersex"></i>
                        <label class="text-sm">Sex</label>
                        <select class="custom-select form-control-sm" id="updaterecruitmentmodal_sex">
                            <option value="M">Male</option>
                            <option value="F">Female</option>
                        </select>
                    </div>
                </div>
            </div>
                    <div class="form-group">
                         <i class="fa fa-address-card"></i>
                            <label class="text-sm">Address</label>
                        <textarea type="text" class="form-control form-control-sm" id="updaterecruitmentmodal_address" 
                        placeholder="Enter Address"></textarea>
                    </div>
            <div class="form-group">
                 <div class="row">
                    <div class="col-md-4">
                            <i class="fa fa-phone-square"></i>
                            <label class="text-sm">Contact</label>
                        <input type="text" class="form-control form-control-sm" id="updaterecruitmentmodal_contact" placeholder="Enter Contact" maxlength="11">
                    </div>

                    <div class="col-md-5">
                            <i class="fa fa-envelope-square"></i>
                            <label class="text-sm">Email</label>
                        <input type="text" class="form-control form-control-sm" id="updaterecruitmentmodal_email" placeholder="Enter Email">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-md-6">
                      <i class="fa fa-id-card"></i>
                        <label class="text-sm">Username</label>
                        <input type="text" class="form-control form-control-sm" id="updaterecruitmentmodal_code" placeholder="Enter Code">
                    </div>

                    <div class="col-md-6">
                        <i class="fa fa-eye-slash"></i>
                        <label class="text-sm">Password</label>
                        <input type="text" class="form-control form-control-sm" id="updaterecruitmentmodal_pass" placeholder="Password">
                    </div>
                </div>
            </div>
             <div class="form-group">
                <div class="row">
                    <div class="col-md-3">
                        <i class="fa fa-star-half-o"></i>
                        <label class="text-sm"><i class="fa fa-check-circle"></i> Status</label>
                        <select class="custom-select form-control-sm" id="updaterecruitmentmodal_status">
                            <option value="1">Activated</option>
                            <option value="0">Deactivated</option>
                        </select>
                    </div>
                </div>
            </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-success" id="updaterecruitmentmodalbutton">
                    <i class="fa fa-save"></i> Save Changes </button>
                </div>
            </div>
        </div>
    </div>
  </div>
  <!-- /.content-wrapper -->
<?php 
    include 'themepart/bottom.php';
?>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function() {
    $("#datatablerecruitment1").DataTable();
    $('#datatablerecruitment2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>
</body>
</html>
