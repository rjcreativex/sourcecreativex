<?php 
    include '../sourcefile/functions.php';
?>
<?php 
  include 'themepart/mylinkcss.php';
?>
<?php 
  include 'themepart/admin.php';
?>
<?php 
  include 'themepart/top_menu.php';
?><br>
  <div class="content-wrapper">
     <form class="form-group">
          <div class="col-md-12"> 
              <div class="card bg-light text-dark"> 
        <div class="card-body">
         <h4 class="card-title" style="font-size:20px;">  Module  <i class="fas fa-tractor" style="font-size:24px"></i></h4>
         <p class="card-text">Control everything here. Create, Find, Activate and Deactivate Module.</p>
         <button type="button" class="btn btn-light "style="background-color:#73C6B6; color:white;" data-toggle="modal"  data-target="#createmodulemodal"><i class="far fa-plus-square"></i> Add New Module </button>
          </div>
          </div>
      </div>
        </form>

        <form class="form-control-lg">
          <div class="input-group mb-3">
            <div class="input-group-prepend"  >
              <button class="btn btn-info"><i class="fa fa-search"></i></button>
            </div>
            <input type="text" id="controlmodulemaininput" class="form-control form-control-lg" placeholder="Type anything you search.." style="font-size:14px;">
          </div>
        </form><br>

 <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
            </div>
            <div class="card-body">
              <table id="datatablemodule2" class="table table-hover">
                <thead class="table-light">
                <tr>
                  <th># Module ID</th>
                  <th>Module</th>
                  <th>Description</th>
                  <th>Remarks</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Module ID </th>
                </tr> 
                </thead>
                <tbody id="controlmodulemainoutput">
                <?php
                $module = new Module();
                $module->startreadmodule();
                $module_all = $module->get_module_credential("all");

                if($module_all !== null) {
                    for( $r=0; $r < count($module_all["module_id"]); $r++ ) {
                        ?>
                        <tr>
                            <th scope="row"><?php echo $module_all["module_id"][$r] ?></th>
                            <td><?php echo $module_all["module"][$r];?></td>
                            <td><?php echo $module_all["description"][$r];?></td>
                            <td><?php echo $module_all["remarks"][$r];?></td>
                            <td>
                            <button class="btn btn-success module-record-table-row" data-toggle="modal" data-target="#updatemodulemodal" data-moduledata ='{ 
                            "module_id" : "<?php echo $module_all["module_id"][$r] ?>",
                            "module" : "<?php echo $module_all["module"][$r] ?>",
                            "description" : "<?php echo $module_all["description"][$r] ?>",
                            "remarks" : "<?php echo $module_all["remarks"][$r] ?>", 
                            "date_added" : "<?php echo $module_all["date_added"][$r] ?>",
                            "status" : "<?php echo $module_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                              <button class="btn btn-info module-record-table-row-views" data-toggle="modal" data-target="#module1-<?php echo $module_all["module_id"][$r]; ?>"><i class="fa fa-eye"></i> View 
                              </button>
                           </td>
                            <td>
                                <?php
                                    if ($module_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
        <td>
        <?php echo $module_all["module_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="module1-<?php echo $module_all["module_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fas fa-tractor"></i> Module View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Module ID </th>
                            <th><i class="fas fa-pen-alt"></i>  Module </th>
                            <th><i class="fas fa-pen-alt"></i> Description </th></tr>
                            <td style="border:0px;"><?php echo $module_all["module_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $module_all["module"][$r];?></td>
                            <td style="border:0px;"><?php echo $module_all["description"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i>  Remarks </th>
                            <th><i class="far fa-calendar-alt"></i> Date Added </th></tr>
                            <td style="border:0px;"><?php echo $module_all["remarks"][$r];?></td>
                            <td style="border:0px;"><?php echo $module_all["date_added"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"> 
                             <?php
                                    if ($module_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;"><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
                        </tr>
                        <?php
                    }
                }
            ?> 
                </tbody id="controlmodulemainoutput">
                <tfoot class="table-light">
                <tr>
                  <th># Module ID</th>
                  <th>Module</th>
                  <th>Description</th>
                  <th>Remarks</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Module ID</th>
                </tr>
                </tfoot>
              </table>
            </div>
          </div>

        </div>
      </div>
    </section>

 <div class="modal_container">
    <div class="modal fade" id="createmodulemodal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fas fa-tractor"></i> Module </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>

                    <div class="form-group">
                         <i class="fas fa-pen-alt"></i>
                            <label class="text-sm">Module</label>
                        <input type="text" class="form-control form-control-sm" id="createmodulemodal_module" 
                        placeholder="Enter Module">
                    </div>
                    <div class="form-group">
                         <i class="fas fa-pen-alt"></i>
                            <label class="text-sm">Description</label>
                        <textarea type="text" class="form-control form-control-sm" id="createmodulemodal_description" 
                        placeholder="Enter Description"></textarea>
                    </div>
               
                 <div class="form-group">
                  <div class="row">
                     <div class="col-md-8">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Remarks</label>
                        <textarea type="text" class="form-control form-control-sm" id="createmodulemodal_remarks" placeholder="Enter Remarks"></textarea>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <div class="row">
                     <div class="col-md-8">
                        <i class="far fa-calendar-alt"></i>
                        <label class="text-sm">Date Create</label>
                        <input type="date" class="form-control form-control-sm" id="createmodulemodal_date_added" placeholder="Enter Date Create">
                    </div>
                  </div>
                </div>

                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-success" id="createmodulemodalbutton">
                    <i class="fa fa-save"></i> Save Changes </button>
                </div>
            </div>
        </div>
    </div>
</div>

    
<div class="modal_container">
    <div class="modal fade" id="updatemodulemodal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fas fa-tractor"></i> Module Update </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                        <input type="hidden" id="updatemodulemodal_module_id">
                    </div>

                    <div class="form-group">
                         <i class="fas fa-pen-alt"></i>
                            <label class="text-sm">Module</label>
                        <input type="text" class="form-control form-control-sm" id="updatemodulemodal_module" 
                        placeholder="Enter Module">
                    </div>
                    <div class="form-group">
                         <i class="fas fa-pen-alt"></i>
                            <label class="text-sm">Description</label>
                        <textarea type="text" class="form-control form-control-sm" id="updatemodulemodal_description" 
                        placeholder="Enter Description"></textarea>
                    </div>
               
                 <div class="form-group">
                  <div class="row">
                     <div class="col-md-8">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Remarks</label>
                        <textarea type="text" class="form-control form-control-sm" id="updatemodulemodal_remarks" placeholder="Enter Remarks"></textarea>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <div class="row">
                     <div class="col-md-8">
                        <i class="far fa-calendar-alt"></i>
                        <label class="text-sm">Date Create</label>
                        <input type="date" class="form-control form-control-sm" id="updatemodulemodal_date_added" placeholder="Enter Date Create">
                    </div>
                  </div>
                </div>

            <div class="form-group">
                <div class="row">
                    <div class="col-md-3">
                        <i class="fa fa-star-half-o"></i>
                        <label class="text-sm"><i class="fa fa-check-circle"></i> Status</label>
                        <select class="custom-select form-control-sm" id="updatemodulemodal_status">
                            <option value="1">Open</option>
                            <option value="0">Close</option>
                        </select>
                    </div>
                </div>
            </div>

                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-success" id="updatemodulemodalbutton">
                    <i class="fa fa-save"></i> Save Changes </button>
                </div>
            </div>
        </div>
    </div>
</div>


  </div>
<?php 
  include 'themepart/bottom.php';
?>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function() {
    $("#datatablemodule1").DataTable();
    $('#datatablemodule2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>
</body>
</html>