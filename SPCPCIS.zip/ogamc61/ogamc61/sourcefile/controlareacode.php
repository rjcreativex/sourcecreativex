<?php 
    include '../sourcefile/functions.php';
?>
<?php 
  include 'themepart/mylinkcss.php';
?>
<?php 
  include 'themepart/admin.php';
?>
<?php 
  include 'themepart/top_menu.php';
?><br>
  <div class="content-wrapper">
     <form class="form-group">
          <div class="col-md-12">
              <div class="card bg-light text-dark"> 
        <div class="card-body">
         <h4 class="card-title" style="font-size:20px;">  Area Code <i class="fab fa-linode" style="font-size:24px"></i></h4>
         <p class="card-text">Control everything here. Create, Find, Activate and Deactivate Area Code.</p>
         <button type="button" class="btn btn-info" data-toggle="modal"  data-target="#createareacodemodal"><i class="far fa-plus-square"></i> Add New Area Code </button>
          </div>
          </div>
      </div>
        </form>

        <form class="form-control-lg">
          <div class="input-group mb-3">
            <div class="input-group-prepend">
              <button class="btn btn-primary"><i class="fa fa-search"></i></button>
            </div>
            <input type="text" id="controlareacodemaininput" class="form-control form-control-lg" placeholder="Type anything you search.." style="font-size:14px;">
          </div>
        </form><br>

 <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
            </div>
            <div class="card-body">
              <table id="datatableareacode2" class="table table-hover">
                <thead class="table-light">
                <tr>
                  <th># Area Code ID</th>
                  <th>Area Code</th>
                  <th>Description</th>
                  <th>Remarks</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Area Code ID </th>
                </tr> 
                </thead>
                <tbody id="controlareacodemainoutput">
                <?php
                $areacode = new Areacode();
                $areacode->startreadareacode();
                $areacode_all = $areacode->get_areacode_credential("all");

                if($areacode_all !== null) {
                    for( $r=0; $r < count($areacode_all["areacode_id"]); $r++ ) {
                        ?>
                        <tr>
                            <th scope="row"><?php echo $areacode_all["areacode_id"][$r] ?></th>
                            <td><?php echo $areacode_all["areacode"][$r];?></td>
                            <td><?php echo $areacode_all["description"][$r];?></td>
                            <td><?php echo $areacode_all["remarks"][$r];?></td>
                            <td>
                            <button class="btn btn-success areacode-record-table-roww" data-toggle="modal" data-target="#updateareacodemodal" data-areacodedata ='{ 
                            "areacode_id" : "<?php echo $areacode_all["areacode_id"][$r] ?>",
                            "areacode" : "<?php echo $areacode_all["areacode"][$r] ?>",
                            "description" : "<?php echo $areacode_all["description"][$r] ?>",
                            "remarks" : "<?php echo $areacode_all["remarks"][$r] ?>", 
                            "date_added" : "<?php echo $areacode_all["date_added"][$r] ?>",
                            "status" : "<?php echo $areacode_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                              <button class="btn btn-info areacode-record-table-row-views" data-toggle="modal" data-target="#areacode1-<?php echo $areacode_all["areacode_id"][$r]; ?>"><i class="fa fa-eye"></i> View 
                              </button>
                           </td>
                            <td>
                                <?php
                                    if ($areacode_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
        <td>
        <?php echo $areacode_all["areacode_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="areacode1-<?php echo $areacode_all["areacode_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fab fa-linode"></i> Area Code View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Area Code ID </th>
                            <th><i class="fas fa-pen-alt"></i>  Area Code </th>
                            <th><i class="fas fa-pen-alt"></i> Description </th></tr>
                            <td style="border:0px;"><?php echo $areacode_all["areacode_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $areacode_all["areacode"][$r];?></td>
                            <td style="border:0px;"><?php echo $areacode_all["description"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i>  Remarks </th>
                            <th><i class="far fa-calendar-alt"></i> Date Added </th></tr>
                            <td style="border:0px;"><?php echo $areacode_all["remarks"][$r];?></td>
                            <td style="border:0px;"><?php echo $areacode_all["date_added"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"> 
                             <?php
                                    if ($areacode_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;"><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
                        </tr>
                        <?php
                    }
                }
            ?> 
                </tbody id="controlareacodemainoutput">
                <tfoot class="table-light">
                <tr>
                  <th># Area Code ID</th>
                  <th>Area Code</th>
                  <th>Description</th>
                  <th>Remarks</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Area Code ID</th>
                </tr>
                </tfoot>
              </table>
            </div>
          </div>

        </div>
      </div>
    </section>

 <div class="modal_container">
    <div class="modal fade" id="createareacodemodal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fab fa-linode"></i> Area Code </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>

                    <div class="form-group">
                         <i class="fas fa-pen-alt"></i>
                            <label class="text-sm">Area Code</label>
                        <input type="text" class="form-control form-control-sm" id="createareacodemodal_areacode" 
                        placeholder="Enter Course Code">
                    </div>
                    <div class="form-group">
                         <i class="fas fa-pen-alt"></i>
                            <label class="text-sm">Description</label>
                        <textarea type="text" class="form-control form-control-sm" id="createareacodemodal_description" 
                        placeholder="Enter Description"></textarea>
                    </div>
               
                 <div class="form-group">
                  <div class="row">
                     <div class="col-md-8">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Remarks</label>
                        <textarea type="text" class="form-control form-control-sm" id="createareacodemodal_remarks" placeholder="Enter Remarks"></textarea>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <div class="row">
                     <div class="col-md-8">
                        <i class="far fa-calendar-alt"></i>
                        <label class="text-sm">Date Create</label>
                        <input type="date" class="form-control form-control-sm" id="createareacodemodal_date_added" placeholder="Enter Date Create">
                    </div>
                  </div>
                </div>

                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-success" id="createareacodemodalbutton">
                    <i class="fa fa-save"></i> Save Changes </button>
                </div>
            </div>
        </div>
    </div>
</div>

    


<div class="modal_container">
    <div class="modal fade" id="updateareacodemodal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fab fa-linode"></i> Area Code Update </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                        <input type="hidden" id="updateareacodemodal_areacode_id">
                    </div>

                    <div class="form-group">
                         <i class="fas fa-pen-alt"></i>
                            <label class="text-sm">Area Code</label>
                        <input type="text" class="form-control form-control-sm" id="updateareacodemodal_areacode" 
                        placeholder="Enter Course Code">
                    </div>
                    <div class="form-group">
                         <i class="fas fa-pen-alt"></i>
                            <label class="text-sm">Description</label>
                        <textarea type="text" class="form-control form-control-sm" id="updateareacodemodal_description" 
                        placeholder="Enter Description"></textarea>
                    </div>
               
                 <div class="form-group">
                  <div class="row">
                     <div class="col-md-8">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Remarks</label>
                        <textarea type="text" class="form-control form-control-sm" id="updateareacodemodal_remarks" placeholder="Enter Remarks"></textarea>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <div class="row">
                     <div class="col-md-8">
                        <i class="far fa-calendar-alt"></i>
                        <label class="text-sm">Date Create</label>
                        <input type="date" class="form-control form-control-sm" id="updateareacodemodal_date_added" placeholder="Enter Date Create">
                    </div>
                  </div>
                </div>

            <div class="form-group">
                <div class="row">
                    <div class="col-md-3">
                        <i class="fa fa-star-half-o"></i>
                        <label class="text-sm"><i class="fa fa-check-circle"></i> Status</label>
                        <select class="custom-select form-control-sm" id="updateareacodemodal_status">
                            <option value="1">Open</option>
                            <option value="0">Close</option>
                        </select>
                    </div>
                </div>
            </div>

                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-success" id="updateareacodemodalbutton">
                    <i class="fa fa-save"></i> Save Changes </button>
                </div>
            </div>
        </div>
    </div>
</div>


  </div>
<?php 
  include 'themepart/bottom.php';
?>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function() {
    $("#datatableareacode1").DataTable();
    $('#datatableareacode2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>
</body>
</html>