<?php 
    include '../sourcefile/functions.php';
?>
<?php 
    include 'themepart/mylinkcss.php';
?>
<?php 
    include 'themepart/admin.php';
?>
<?php 
    include 'themepart/top_menu.php';
?><br>
  <div class="content-wrapper">
    <form class="form-group">
        <div class="col-md-12">
            <div class="card bg-white text-secondary"> 
        <div class="card-body">
             <h4 class="card-title" style="font-size:20px;"> Statistics <i class="fab fa-audible" style="font-size:24px"></i></h4>
             <p class="card-text text-secondary">Control everything here. Create, Find, Activate and Deactivate Statistics.</p>
        </div>
        </div>
    </div>
  </form>

  <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header bg-white">
            </div>
            <div class="card-body">

              <div class="form-group">
                <div class="row">
                  <div class="col-md-3">
                    <h1 class="card-title text-secondary">Users Total</h1>
                  </div>
                </div>
              </div>

              <div class="form-group">
                <div class="row">
                  <!-- admin --> 
                   <div class="col-md-3">
                      <div class="card w-15">
                        <div class="card-body bg-white">
                      <p class="card-text" style="font-size:37px; color:#48C9B0;">
                                    <?php
                                    $count=0;
                                    $opps=false;
                                    $counter=[];

                                     $admin = new Admin();
                                     $admin->startreadadmin();

                                     $admin_all = $admin->get_admin_credential("all");

                                     if($admin_all !== null) {
                                        for( $j=0; $j < count($admin_all["admin_id"]); $j++ ) {
                                            if($count < $admin_all["admin_id"][$j]) {
                                                  $count++;
                                              $opps=true; 
                                          }
                                    
                                    }
                                     $counter[$j]=$count;
                                     $count=0;
                                             if($opps==true) {
                                                   echo $counter[$j];
                                                     $opps=false;
                                                }
                                            }?>
                                           </p>
                         <h5 class="card-title"  style="font-size:17px; color:#48C9B0;"><i class="fa fa-user-secret nav-icon" style="font-size:24px; color:#48C9B0;"></i> Administrator</h5>
                            
                        </div>
                      </div>
                    </div>
                    <!-- admin -->

                     <!-- hrstaff -->
                   <div class="col-md-3">
                      <div class="card w-15">
                        <div class="card-body bg-white">
                      <p class="card-text" style="font-size:37px; color:#5DADE2;">
                                    <?php
                                    $count=0;
                                    $opps=false;
                                    $counter=[];

                                     $hrstaff = new Hrstaff();
                                     $hrstaff->startreadhrstaff();

                                     $hrstaff_all = $hrstaff->get_hrstaff_credential("all");

                                     if($hrstaff_all !== null) {
                                        for( $j=0; $j < count($hrstaff_all["hrstaff_id"]); $j++ ) {
                                            if($count < $hrstaff_all["hrstaff_id"][$j]) {
                                                  $count++;
                                              $opps=true; 
                                          }
                                    
                                    }
                                     $counter[$j]=$count;
                                     $count=0;
                                             if($opps==true) {
                                                   echo $counter[$j];
                                                     $opps=false;
                                                }
                                            }?>
                                           </p>
                         <h5 class="card-title"  style="font-size:17px; color:#5DADE2;"><i class="fa fa-user nav-icon" style="font-size:24px; color:#5DADE2;"></i> Hrstaff </h5>
                            
                        </div>
                      </div>
                    </div>
                    <!-- hrstaff -->

                     <!-- recruitment -->
                   <div class="col-md-3">
                      <div class="card w-15">
                        <div class="card-body bg-white">
                      <p class="card-text" style="font-size:37px; color:#AF7AC5;">
                                    <?php
                                    $count=0;
                                    $opps=false;
                                    $counter=[];

                                     $recruitment = new Recruitment();
                                     $recruitment->startreadrecruitment();

                                     $recruitment_all = $recruitment->get_recruitment_credential("all");

                                     if($recruitment_all !== null) {
                                        for( $j=0; $j < count($recruitment_all["recruitment_id"]); $j++ ) {
                                            if($count < $recruitment_all["recruitment_id"][$j]) {
                                                  $count++;
                                              $opps=true; 
                                          }
                                    
                                    }
                                     $counter[$j]=$count;
                                     $count=0;
                                             if($opps==true) {
                                                   echo $counter[$j];
                                                     $opps=false;
                                                }
                                            }?>
                                           </p>
                         <h5 class="card-title"  style="font-size:17px; color:#AF7AC5;"><i class="fa fa-users nav-icon" style="font-size:24px; color:#AF7AC5;"></i> Recruitment </h5>
                            
                        </div>
                      </div>
                    </div>
                    <!-- recruitment -->

                    <!-- coordinator -->
                   <div class="col-md-3">
                      <div class="card w-15">
                        <div class="card-body bg-white">
                      <p class="card-text" style="font-size:37px; color:#EB984E;">
                                    <?php
                                    $count=0;
                                    $opps=false;
                                    $counter=[];

                                     $coordinator = new Coordinator();
                                     $coordinator->startreadcoordinator();

                                     $coordinator_all = $coordinator->get_coordinator_credential("all");

                                     if($coordinator_all !== null) {
                                        for( $j=0; $j < count($coordinator_all["coordinator_id"]); $j++ ) {
                                            if($count < $coordinator_all["coordinator_id"][$j]) {
                                                  $count++;
                                              $opps=true; 
                                          }
                                    
                                    }
                                     $counter[$j]=$count;
                                     $count=0;
                                             if($opps==true) {
                                                   echo $counter[$j];
                                                     $opps=false;
                                                }
                                            }?>
                                           </p>
                         <h5 class="card-title"  style="font-size:17px; color:#EB984E;"><i class="fa fa-users nav-icon" style="font-size:24px; color:#EB984E;"></i> Coordinator </h5>
                            
                        </div>
                      </div>
                    </div>
                    <!-- coordinator -->

                </div>
              </div>

              <div class="form-group">
                <div class="row">
                  <div class="col-md-3">
                    <h1 class="card-title text-secondary">Course Total</h1>
                  </div>
                </div>
              </div>

              <div class="form-group">
                <div class="row">
          <!-- coursecode -->
                   <div class="col-md-3">
                      <div class="card w-15">
                        <div class="card-body bg-white">
                      <p class="card-text" style="font-size:37px; color:#48C9B0;">
                                    <?php
                                    $count=0;
                                    $opps=false;
                                    $counter=[];

                                     $coursecode = new Coursecode();
                                     $coursecode->startreadcoursecode();

                                     $coursecode_all = $coursecode->get_coursecode_credential("all");

                                     if($coursecode_all !== null) {
                                        for( $j=0; $j < count($coursecode_all["coursecode_id"]); $j++ ) {
                                            if($count < $coursecode_all["coursecode_id"][$j]) {
                                                  $count++;
                                              $opps=true; 
                                          }
                                    
                                    }
                                     $counter[$j]=$count;
                                     $count=0;
                                             if($opps==true) {
                                                   echo $counter[$j];
                                                     $opps=false;
                                                }
                                            }?>
                                           </p>
                         <h5 class="card-title"  style="font-size:17px; color:#48C9B0;"><i class="fab fa-keycdn nav-icon" style="font-size:24px; color:#48C9B0;"></i> Coursecode </h5>
                            
                        </div>
                      </div>
                    </div>
                    <!-- coursecode -->


                    <!-- areacode -->
                   <div class="col-md-3">
                      <div class="card w-15">
                        <div class="card-body">
                      <p class="card-text" style="font-size:37px; color:#5DADE2;">
                                    <?php
                                    $count=0;
                                    $opps=false;
                                    $counter=[];

                                     $areacode = new Areacode();
                                     $areacode->startreadareacode();

                                     $areacode_all = $areacode->get_areacode_credential("all");

                                     if($areacode_all !== null) {
                                        for( $j=0; $j < count($areacode_all["areacode_id"]); $j++ ) {
                                            if($count < $areacode_all["areacode_id"][$j]) {
                                                  $count++;
                                              $opps=true; 
                                          }
                                    
                                    }
                                     $counter[$j]=$count;
                                     $count=0;
                                             if($opps==true) {
                                                   echo $counter[$j];
                                                     $opps=false;
                                                }
                                            }?>
                                           </p>
                         <h5 class="card-title"  style="font-size:17px; color:#5DADE2;"><i class="fab fa-linode nav-icon" style="font-size:24px; color:#5DADE2;"></i> Areacode </h5>
                            
                        </div>
                      </div>
                    </div>
                    <!-- areacode -->


                <!-- coursetitle -->
                   <div class="col-md-3">
                      <div class="card w-15">
                        <div class="card-body">
                      <p class="card-text" style="font-size:37px; color:#AF7AC5;">
                                    <?php
                                    $count=0;
                                    $opps=false;
                                    $counter=[];

                                     $coursetitle = new Coursetitle();
                                     $coursetitle->startreadcoursetitle();

                                     $coursetitle_all = $coursetitle->get_coursetitle_credential("all");

                                     if($coursetitle_all !== null) {
                                        for( $j=0; $j < count($coursetitle_all["coursetitle_id"]); $j++ ) {
                                            if($count < $coursetitle_all["coursetitle_id"][$j]) {
                                                  $count++;
                                              $opps=true; 
                                          }
                                    
                                    }
                                     $counter[$j]=$count;
                                     $count=0;
                                             if($opps==true) {
                                                   echo $counter[$j];
                                                     $opps=false;
                                                }
                                            }?>
                                           </p>
                         <h5 class="card-title"  style="font-size:17px; color:#AF7AC5;"><i class="fab fa-magento nav-icon" style="font-size:24px; color:#AF7AC5;"></i> Coursetitle
                    </h5>
                            
                        </div>
                      </div>
                    </div>
                    <!-- coursetitle -->


          <!-- unit -->
                   <div class="col-md-3">
                      <div class="card w-15">
                        <div class="card-body">
                      <p class="card-text" style="font-size:37px; color:#EB984E;">
                                    <?php
                                    $count=0;
                                    $opps=false;
                                    $counter=[];

                                     $unit = new Unit();
                                     $unit->startreadunit();

                                     $unit_all = $unit->get_unit_credential("all");

                                     if($unit_all !== null) {
                                        for( $j=0; $j < count($unit_all["unit_id"]); $j++ ) {
                                            if($count < $unit_all["unit_id"][$j]) {
                                                  $count++;
                                              $opps=true; 
                                          }
                                    
                                    }
                                     $counter[$j]=$count;
                                     $count=0;
                                             if($opps==true) {
                                                   echo $counter[$j];
                                                     $opps=false;
                                                }
                                            }?>
                                           </p>
                         <h5 class="card-title"  style="font-size:17px; color:#EB984E;"><i class="fab fa-react nav-icon" style="font-size:24px; color:#EB984E;"></i> Unit
                        </h5>
                            
                        </div>
                      </div>
                    </div>
                    <!-- unit -->
                </div>
              </div>

              <div class="form-group">
                <div class="row">
                  <div class="col-md-3">
                    <h1 class="card-title text-secondary">Syllabus Total</h1>
                  </div>
                </div>
              </div>

              <div class="form-group">
                <div class="row">
          <!-- learn -->
                   <div class="col-md-3">
                      <div class="card w-15">
                        <div class="card-body">
                      <p class="card-text" style="font-size:37px; color:#48C9B0;">
                                    <?php
                                    $count=0;
                                    $opps=false;
                                    $counter=[];

                                     $learn = new Learn();
                                     $learn->startreadlearn();

                                     $learn_all = $learn->get_learn_credential("all");

                                     if($learn_all !== null) {
                                        for( $j=0; $j < count($learn_all["learn_id"]); $j++ ) {
                                            if($count < $learn_all["learn_id"][$j]) {
                                                  $count++;
                                              $opps=true; 
                                          }
                                    
                                    }
                                     $counter[$j]=$count;
                                     $count=0;
                                             if($opps==true) {
                                                   echo $counter[$j];
                                                     $opps=false;
                                                }
                                            }?>
                                           </p>
                         <h5 class="card-title"  style="font-size:17px; color:#48C9B0;"><i class="fab fa-apple nav-icon" style="font-size:24px; color:#48C9B0;"></i> Class
                    </h5>
                            
                        </div>
                      </div>
                    </div>
                    <!-- learn -->

              <!-- module -->
                   <div class="col-md-3">
                      <div class="card w-15">
                        <div class="card-body">
                      <p class="card-text" style="font-size:37px; color:#5DADE2;">
                                    <?php
                                    $count=0;
                                    $opps=false;
                                    $counter=[];

                                     $module = new Module();
                                     $module->startreadmodule();

                                     $module_all = $module->get_module_credential("all");

                                     if($module_all !== null) {
                                        for( $j=0; $j < count($module_all["module_id"]); $j++ ) {
                                            if($count < $module_all["module_id"][$j]) {
                                                  $count++;
                                              $opps=true; 
                                          }
                                    
                                    }
                                     $counter[$j]=$count;
                                     $count=0;
                                             if($opps==true) {
                                                   echo $counter[$j];
                                                     $opps=false;
                                                }
                                            }?>
                                           </p>
                         <h5 class="card-title"  style="font-size:17px; color:#5DADE2;"><i class="fas fa-tractor nav-icon" style="font-size:24px; color:#5DADE2;"></i> Module
                    </h5>
                            
                        </div>
                      </div>
                    </div>
                    <!-- module -->


          <!-- format -->
                   <div class="col-md-3">
                      <div class="card w-15">
                        <div class="card-body">
                      <p class="card-text" style="font-size:37px; color:#AF7AC5;">
                                    <?php
                                    $count=0;
                                    $opps=false;
                                    $counter=[];

                                     $format = new Format();
                                     $format->startreadformat();

                                     $format_all = $format->get_format_credential("all");

                                     if($format_all !== null) {
                                        for( $j=0; $j < count($format_all["format_id"]); $j++ ) {
                                            if($count < $format_all["format_id"][$j]) {
                                                  $count++;
                                              $opps=true; 
                                          }
                                    
                                    }
                                     $counter[$j]=$count;
                                     $count=0;
                                             if($opps==true) {
                                                   echo $counter[$j];
                                                     $opps=false;
                                                }
                                            }?>
                                           </p>
                         <h5 class="card-title"  style="font-size:17px; color:#AF7AC5;"><i class="fas fa-glasses nav-icon" style="font-size:24px; color:#AF7AC5;"></i> Class Format
                    </h5>
                            
                        </div>
                      </div>
                    </div>
                    <!-- format -->

              <!-- topic -->
                   <div class="col-md-3">
                      <div class="card w-15">
                        <div class="card-body">
                      <p class="card-text" style="font-size:37px; color:#EB984E;">
                                    <?php
                                    $count=0;
                                    $opps=false;
                                    $counter=[];

                                     $topic = new Topic();
                                     $topic->startreadtopic();

                                     $topic_all = $topic->get_topic_credential("all");

                                     if($topic_all !== null) {
                                        for( $j=0; $j < count($topic_all["topic_id"]); $j++ ) {
                                            if($count < $topic_all["topic_id"][$j]) {
                                                  $count++;
                                              $opps=true; 
                                          }
                                    
                                    }
                                     $counter[$j]=$count;
                                     $count=0;
                                             if($opps==true) {
                                                   echo $counter[$j];
                                                     $opps=false;
                                                }
                                            }?>
                                           </p>
                         <h5 class="card-title"  style="font-size:17px; color:#EB984E;"><i class="fab fa-cloudversify nav-icon" style="font-size:24px; color:#EB984E;"></i> Topic
                    </h5>
                            
                        </div>
                      </div>
                    </div>
                    <!-- topic -->


                </div>
              </div>


            </div>
          </div>

        </div>
      </div>
    </section>

   

</div>
  </div>
<?php 
    include 'themepart/bottom.php';
?>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function() {
    $("#datatablestatistic1").DataTable();
    $('#datatablestatistic2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

</body>
</html>


