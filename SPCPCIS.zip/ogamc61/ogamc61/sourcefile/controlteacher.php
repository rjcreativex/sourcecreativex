<?php 
    include '../sourcefile/functions.php';
?>
<?php 
    include 'themepart/mylinkcss.php';
?>
<?php 
    include 'themepart/admin.php';
?>
<?php 
    include 'themepart/top_menu.php';
?><br>
  <div class="content-wrapper">
    <form class="form-group">
        <div class="col-md-12">
            <div class="card bg-light text-dark"> 
        <div class="card-body">
             <h4 class="card-title" style="font-size:20px;"> Teacher <i class="fa fa-user-tie" style="font-size:24px"></i></h4>
             <p class="card-text">Control everything here. Create, Find, Activate and Deactivate Teacher.</p>
             <button type="button" class="btn btn-success" data-toggle="modal"  data-target="#createteachermodal"><i class="far fa-plus-square"></i> Add New Teacher </button>
        </div>
        </div>
    </div>
  </form>
<form class="form-control-lg">
  <div class="input-group mb-3">
    <div class="input-group-prepend">
      <button class="btn btn-primary"><i class="fa fa-search"></i></button>
    </div>
    <input type="text" id="controlteachermaininput1" class="form-control form-control-lg" placeholder="Type anything you search.." style="font-size:14px;">
  </div>
</form><br>

  <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
            </div>
            <div class="card-body">
              <table id="datatableteacher2" class="table table-hover">
                <thead class="table-light">
                <tr>
                  <th># Teacher ID</th>
                  <th>Lastname</th>
                  <th>Firstname</th>
                  <th>Middlename</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Teacher ID</th>
                </tr>
                </thead>
                <tbody id="controlteachermainoutput1">
                <?php
                $teacher = new Teacher();
                $teacher->startreadteacher();
                $teacher_all = $teacher->get_teacher_credential("all");

                if($teacher_all !== null) {
                    for( $r=0; $r < count($teacher_all["teacher_id"]); $r++ ) {
                        ?>
                        <tr>
                            <th scope="row"><?php echo $teacher_all["teacher_id"][$r] ?></th>
                            <td><?php echo $teacher_all["lname"][$r];?></td>
                            <td><?php echo $teacher_all["fname"][$r];?></td>
                            <td><?php echo $teacher_all["mname"][$r];?></td>
                            <td><?php echo $teacher_all["contact"][$r]; ?></td>
                            <td><?php echo $teacher_all["email"][$r]; ?></td>
                            <td>
                            <button class="btn btn-success teacher-record-table-row" data-toggle="modal" data-target="#updateteachermodal" data-teacherdata ='{ 
                            "teacher_id" : "<?php echo $teacher_all["teacher_id"][$r] ?>",
                            "lname" : "<?php echo $teacher_all["lname"][$r] ?>",
                            "fname" : "<?php echo $teacher_all["fname"][$r] ?>",
                            "mname" : "<?php echo $teacher_all["mname"][$r] ?>",   
                            "age" : "<?php echo $teacher_all["age"][$r] ?>",
                            "sex" : "<?php echo $teacher_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $teacher_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $teacher_all["address"][$r] ?>", 
                            "contact" : "<?php echo $teacher_all["contact"][$r] ?>",
                            "email" : "<?php echo $teacher_all["email"][$r] ?>", 
                            "code" : "<?php echo $teacher_all["code"][$r] ?>", 
                            "pass" : "<?php echo $teacher_all["pass"][$r] ?>", 
                            "status" : "<?php echo $teacher_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update</button>
                            </td>
                              <td>
                            <button class="btn btn-info teacher-record-table-row-view" data-target="#teacher1-<?php echo $teacher_all["teacher_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View </button>
                          </td>
                            <td>
                                <?php
                                    if ($teacher_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
        <td>
        <?php echo $teacher_all["teacher_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="teacher1-<?php echo $teacher_all["teacher_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-user-tie"></i> Teacher View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Teacher code is always unique.</small>
                    </div>
                     <table class="table" border="0">
                            <tr><th># Teacher ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["teacher_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                            <?php
                                    if ($teacher_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
                        </tr>
                        <?php
                    }
                }
            ?> 
                </tbody id="controlteachermainoutput1">
                <tfoot class="table">
                <tr>
                  <th># Teacher ID</th>
                  <th>Lastname</th>
                  <th>Firstname</th>
                  <th>Middlename</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Teacher ID</th>
                </tr>
                </tfoot>
              </table>
            </div>
          </div>
          
          <br>

          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Teacher List <i class="fa fa-user-tie" style="font-size:25px"></i></h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="datatableteacher1" class="table">
                <thead class="table">
                <tr>
                  <th># Teacher ID</th>
                  <th>Lastname</th>
                  <th>Firstname</th>
                  <th>Middlename</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Teacher ID</th>
                </tr>
                </thead>
                <tbody id="controlteachermainoutput2">
                 <?php
                $teacher = new Teacher();
                $teacher->startreadteacher();
                $teacher_all = $teacher->get_teacher_credential("all");

                if($teacher_all !== null) {
                    for( $r=0; $r < count($teacher_all["teacher_id"]); $r++ ) {
                        ?>
                        <tr>
                            <th scope="row"><?php echo $teacher_all["teacher_id"][$r] ?></th>
                            <td><?php echo $teacher_all["lname"][$r];?></td>
                            <td><?php echo $teacher_all["fname"][$r];?></td>
                            <td><?php echo $teacher_all["mname"][$r];?></td>
                            <td><?php echo $teacher_all["contact"][$r]; ?></td>
                            <td><?php echo $teacher_all["email"][$r]; ?></td>
                            <td>
                            <button class="btn btn-success teacher-record-table-row" data-toggle="modal" data-target="#updateteachermodal" data-teacherdata ='{ 
                            "teacher_id" : "<?php echo $teacher_all["teacher_id"][$r] ?>",
                            "lname" : "<?php echo $teacher_all["lname"][$r] ?>",
                            "fname" : "<?php echo $teacher_all["fname"][$r] ?>",
                            "mname" : "<?php echo $teacher_all["mname"][$r] ?>",   
                            "age" : "<?php echo $teacher_all["age"][$r] ?>",
                            "sex" : "<?php echo $teacher_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $teacher_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $teacher_all["address"][$r] ?>", 
                            "contact" : "<?php echo $teacher_all["contact"][$r] ?>",
                            "email" : "<?php echo $teacher_all["email"][$r] ?>", 
                            "code" : "<?php echo $teacher_all["code"][$r] ?>", 
                            "pass" : "<?php echo $teacher_all["pass"][$r] ?>", 
                            "status" : "<?php echo $teacher_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                            <button class="btn btn-info teacher-record-table-row-view" data-toggle="modal" data-target="#teacher2-<?php echo $teacher_all["teacher_id"][$r]; ?>">
                                      <i class="fas fa-eye"></i> View </button></td>
                            <td>
                                <?php
                                    if ($teacher_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
        <td>
        <?php echo $teacher_all["teacher_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="teacher2-<?php echo $teacher_all["teacher_id"][$r];?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-user-tie"></i> Teacher View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Teacher code is always unique.</small>
                    </div>
                      <table class="table" style="border:none;">
                            <tr><th># Teacher ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["teacher_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                             <?php
                                    if ($teacher_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
      </td>
                        </tr>
                        <?php
                    }
                }
            ?> 
                </tbody id="controlteachermainoutput2">
                <tfoot class="table">
                <tr>
                  <th># Teacher ID</th>
                  <th>Lastname</th>
                  <th>Firstname</th>
                  <th>Middlename</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Teacher ID</th>
                </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="modal_container">
    <div class="modal fade" id="createteachermodal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-user-tie"></i> Teacher Create </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Teacher code is always unique.</small>
                    </div>
                <div class="form-group">
                    <div class="row">
                       <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                       <label class="text-sm">Lastname</label>
                     <input type="text" class="form-control form-control-sm" id="createteachermodal_lname" placeholder="Enter Lastname">
                     </div>

                     <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Firstname</label>
                        <input type="text" class="form-control form-control-sm" id="createteachermodal_fname" placeholder="Enter Firstname">
                    </div>

                   <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Middlename</label>
                        <input type="text" class="form-control form-control-sm" id="createteachermodal_mname" placeholder="Enter Middlename">
                    </div>
                  </div>
                </div>

            <div class="form-group">
                <div class="row">
                <div class="col-md-6">
                        <i class="fa fa-calendar"></i>
                        <label class="text-sm">Birthdate</label>
                        <input type="date" class="form-control form-control-sm" id="createteachermodal_birthdate" placeholder="Enter Birthdate">
                    </div>
                    <div class="col-md-3">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Age</label>
                        <input type="text" class="form-control form-control-sm" id="createteachermodal_age" placeholder="Enter Age" maxlength="2">
                    </div>
                    <div class="col-md-3">
                          <i class="fa fa-intersex"></i>
                        <label class="text-sm"><i class="fa fa-venus-double"></i> Sex</label>
                        <select class="custom-select form-control-sm" id="createteachermodal_sex">
                            <option value="M">Male</option>
                            <option value="F">Female</option>
                        </select>
                    </div>
                </div>
            </div>
                    <div class="form-group">
                         <i class="fa fa-address-card"></i>
                            <label class="text-sm">Address</label>
                        <textarea type="text" class="form-control form-control-sm" id="createteachermodal_address" 
                        placeholder="Enter Address"></textarea>
                    </div>
            <div class="form-group">
                 <div class="row">
                    <div class="col-md-4">
                            <i class="fa fa-phone-square"></i>
                            <label class="text-sm">Contact</label>
                        <input type="text" class="form-control form-control-sm" maxlength="11" id="createteachermodal_contact" placeholder="Enter Contact">
                    </div>

                    <div class="col-md-5">
                            <i class="fa fa-envelope-square"></i>
                            <label class="text-sm">Email</label>
                        <input type="text" class="form-control form-control-sm" id="createteachermodal_email" placeholder="Enter Email">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-md-6">
                      <i class="fa fa-id-card"></i>
                        <label class="text-sm">Username</label>
                        <input type="text" class="form-control form-control-sm" id="createteachermodal_code" placeholder="Enter Code">
                    </div>

                    <div class="col-md-6">
                        <i class="fa fa-eye-slash"></i>
                        <label class="text-sm">Password</label>
                        <input type="text" class="form-control form-control-sm" id="createteachermodal_pass" placeholder="Password">
                    </div>
                </div>
            </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-success" id="createteachermodalbutton">
                    <i class="fa fa-save"></i> Save Changes </button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="updateteachermodal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-user-tie"></i> Teacher Update </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Teacher code is always unique.</small>
                        <input type="hidden" id="updateteachermodal_teacher_id">
                    </div>
                <div class="form-group">
                    <div class="row">
                       <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                       <label class="text-sm">Lastname</label>
                     <input type="text" class="form-control form-control-sm" id="updateteachermodal_lname" placeholder="Enter Lastname">
                     </div>

                     <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Firstname</label>
                        <input type="text" class="form-control form-control-sm" id="updateteachermodal_fname" placeholder="Enter Firstname">
                    </div>

                   <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Middlename</label>
                        <input type="text" class="form-control form-control-sm" id="updateteachermodal_mname" placeholder="Enter Middlename">
                    </div>
                  </div>
                </div>

            <div class="form-group">
                <div class="row">
                <div class="col-md-6">
                        <i class="fa fa-calendar"></i>
                        <label class="text-sm">Birthdate</label>
                        <input type="date" class="form-control form-control-sm" id="updateteachermodal_birthdate" placeholder="Enter Birthday">
                    </div>
                    <div class="col-md-3">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Age</label>
                        <input type="text" class="form-control form-control-sm" id="updateteachermodal_age" placeholder="Enter Age" maxlength="2">
                    </div>
                    <div class="col-md-3">
                          <i class="fa fa-intersex"></i>
                        <label class="text-sm"><i class="fa fa-venus-double"></i>Sex</label>
                        <select class="custom-select form-control-sm" id="updateteachermodal_sex">
                            <option value="M">Male</option>
                            <option value="F">Female</option>
                        </select>
                    </div>
                </div>
            </div>
                    <div class="form-group">
                         <i class="fa fa-address-card"></i>
                            <label class="text-sm">Address</label>
                        <textarea type="text" class="form-control form-control-sm" id="updateteachermodal_address" 
                        placeholder="Enter Address"></textarea>
                    </div>
            <div class="form-group">
                 <div class="row">
                    <div class="col-md-4">
                            <i class="fa fa-phone-square"></i>
                            <label class="text-sm">Contact</label>
                        <input type="text" class="form-control form-control-sm" id="updateteachermodal_contact" placeholder="Enter Contact" maxlength="11">
                    </div>

                    <div class="col-md-5">
                            <i class="fa fa-envelope-square"></i>
                            <label class="text-sm">Email</label>
                        <input type="text" class="form-control form-control-sm" id="updateteachermodal_email" placeholder="Enter Email">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-md-6">
                      <i class="fa fa-id-card"></i>
                        <label class="text-sm">Username</label>
                        <input type="text" class="form-control form-control-sm" id="updateteachermodal_code" placeholder="Enter Code">
                    </div>

                    <div class="col-md-6">
                        <i class="fa fa-eye-slash"></i>
                        <label class="text-sm">Password</label>
                        <input type="text" class="form-control form-control-sm" id="updateteachermodal_pass" placeholder="Password">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-md-3">
                        <i class="fa fa-star-half-o"></i>
                        <label class="text-sm"><i class="fa fa-check-circle"></i> Status</label>
                        <select class="custom-select form-control-sm" id="updateteachermodal_status">
                            <option value="1">Activated</option>
                            <option value="0">Deactivated</option>
                        </select>
                    </div>
                </div>
            </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-success" id="updateteachermodalbutton">
                    <i class="fa fa-save"></i> Save Changes </button>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
  </div>
<?php 
    include 'themepart/bottom.php';
?>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/teacherlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function() {
    $("#datatableteacher1").DataTable();
    $('#datatableteacher2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

</body>
</html>


