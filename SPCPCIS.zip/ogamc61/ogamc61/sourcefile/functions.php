<?php
class Main{
 private $page_assigned, $alert_level, $page_title;

    public function __construct() {
        $this->page_assigned = "loginall";
        $this->page_title = "SPCPC";
    }

     public function getthewebaddresstitle() {
        return $this->page_title;
    }

    public function activepagestate() {
        switch($this->page_assigned) {
            case "loginall":
                include 'loginall.php';
            break;
            case "admin":
                include 'admin.php';
            break;
            case "hrstaff":
                include 'hrstaff.php';
            break;
            case "recruitment":
                include 'recruitment.php';
            break;
            case "coordinator":
                include 'coordinator.php';
            break;
            default :
                include 'loginall.php';
        } 
    }

    public function getalertstate() {
        $alert_context = "";
        switch( $this->alert_level ) {
            case 1: // for wrong login credentials
                $alert_context = '
                    <div class="container">
                    <div class="row">
                        <div class="col">
                            <br> <!-- alert portion -->
                        </div>
                        <div class="col-12">
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong>Warning!</strong> Invalid code or pass.
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    </div>
                ';
            break;
            case 2: // for success login credentials
                $alert_context = '
                    <div class="container">
                    <div class="row">
                        <div class="col">
                            <br> <!-- alert portion -->
                        </div>
                        <div class="col-12">
                            <div class="alert alert-info alert-dismissible fade show" role="alert">
                                <strong>HELLO!</strong> Thank you for passing by.
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        </div>
                    </div>
                    </div>
                ';
            break;
        }
        return $alert_context;
    }

     public function getwebsitestyle() {
        return '
         <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- summernote -->
  <link rel="stylesheet" href="plugins/summernote/summernote-bs4.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">

        ';
    }

    public function getwebsitescript() {
        return '
        
        <!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge("uibutton", $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- ChartJS -->
<script src="plugins/chart.js/Chart.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparklines/sparkline.js"></script>
<!-- JQVMap -->
<script src="plugins/jqvmap/jquery.vmap.min.js"></script>
<script src="plugins/jqvmap/maps/jquery.vmap.usa.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/jquery-knob/jquery.knob.min.js"></script>
<!-- daterangepicker -->
<script src="plugins/moment/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Summernote -->
<script src="plugins/summernote/summernote-bs4.min.js"></script>
<!-- overlayScrollbars -->
<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script src="dist/js/custom.js"></script>
        ';
    }

    

      public function main_program() {
        if (session_status() === PHP_SESSION_NONE ) {
             session_start();
        }
        if (isset($_POST['login_button'])) {
            $check = false;
            $check_id = "";
            $check_type = "";
            $check_name = "";
            
            if(!$check) { // for admin check
                $admin = new Admin();
                $admin->startreadadmin();
                $admin_all = $admin->get_admin_credential("all");

                if($admin_all !== null) {
                    for( $r=0; $r < count($admin_all["admin_id"]); $r++ ) {
                        if($admin_all["status"][$r] && $admin_all["code"][$r] == $_POST['login_code'] && $admin_all["pass"][$r] == $_POST['login_pass']) {
                            $check = true;
                            $check_id = $admin_all["admin_id"][$r];
                            $check_type = "admin";
                            $check_name = $admin_all["lname"][$r] . ', ' . $admin_all["fname"][$r] . ' ' . $admin_all["mname"][$r];
                        }
                    }
                }

                $hrstaff = new Hrstaff();
                $hrstaff->startreadhrstaff();
                $hrstaff_all = $hrstaff->get_hrstaff_credential("all");

                if($hrstaff_all !== null) {
                    for( $r=0; $r < count($hrstaff_all["hrstaff_id"]); $r++ ) {
                        if($hrstaff_all["status"][$r] && $hrstaff_all["code"][$r] == $_POST['login_code'] && $hrstaff_all["pass"][$r] == $_POST['login_pass']) {
                            $check = true;
                            $check_id = $hrstaff_all["hrstaff_id"][$r];
                            $check_type = "hrstaff";
                            $check_name = $hrstaff_all["lname"][$r] . ', ' . $hrstaff_all["fname"][$r] . ' ' . $hrstaff_all["mname"][$r];
                        }
                    }
                }

                $recruitment = new Recruitment();
                $recruitment->startreadrecruitment();
                $recruitment_all = $recruitment->get_recruitment_credential("all");

                if($recruitment_all !== null) {
                    for( $r=0; $r < count($recruitment_all["recruitment_id"]); $r++ ) {
                        if($recruitment_all["status"][$r] && $recruitment_all["code"][$r] == $_POST['login_code'] && $recruitment_all["pass"][$r] == $_POST['login_pass']) {
                            $check = true;
                            $check_id = $recruitment_all["recruitment_id"][$r];
                            $check_type = "recruitment";
                        $check_name = $recruitment_all["lname"][$r] . ', ' . $recruitment_all["fname"][$r] . ' ' . $recruitment_all["mname"][$r];
                        }
                    }
                }


                $coordinator = new Coordinator();
                $coordinator->startreadcoordinator();
                $coordinator_all = $coordinator->get_coordinator_credential("all");

                if($coordinator_all !== null) {
                    for( $r=0; $r < count($coordinator_all["coordinator_id"]); $r++ ) {
                        if($coordinator_all["status"][$r] && $coordinator_all["code"][$r] == $_POST['login_code'] && $coordinator_all["pass"][$r] == $_POST['login_pass']) {
                            $check = true;
                            $check_id = $coordinator_all["coordinator_id"][$r];
                            $check_type = "coordinator";
                        $check_name = $coordinator_all["lname"][$r] . ', ' . $coordinator_all["fname"][$r] . ' ' . $coordinator_all["mname"][$r];
                        }
                    }
                }


                $teacher = new Teacher();
                $teacher->startreadteacher();
                $teacher_all = $teacher->get_teacher_credential("all");

                if($teacher_all !== null) {
                    for( $r=0; $r < count($teacher_all["teacher_id"]); $r++ ) {
                        if($teacher_all["status"][$r] && $teacher_all["code"][$r] == $_POST['login_code'] && $teacher_all["pass"][$r] == $_POST['login_pass']) {
                            $check = true;
                            $check_id = $teacher_all["teacher_id"][$r];
                            $check_type = "teacher";
                        $check_name = $teacher_all["lname"][$r] . ', ' . $teacher_all["fname"][$r] . ' ' . $teacher_all["mname"][$r];
                        }
                    }
                }
            }

            if($check) {
                $this->alert_level = 0;
                $_SESSION['login'] = true;
                $_SESSION['user_id'] = $check_id;
                $_SESSION['user_type'] = $check_type;
                $_SESSION['user_name'] = $check_name;
                $this->page_assigned = $check_type;
            } else {
                $this->alert_level = 1;
            }
                header("location:dashboard.php");
                return;
        }

        if (isset($_POST['logout_button'])) {
            session_unset();
            $check = true;
            $check_id = "";
            $check_type = "";
            $check_name = "";
           
            if($check) {
                $_SESSION['login'] = false;
                $_SESSION['user_id'] = $check_id;
                $_SESSION['user_type'] = $check_type;
                $_SESSION['user_name'] = $check_name;
                header("location:loginall.php");
            }
        }

        if (isset($_POST['logout_button'])) {
                echo "<script>window.location.href='../sourcefile/loginall.php'</script>";
            }

        if (!isset($_SESSION['login'])) {
            $this->page_assigned = "loginall";
        } else {
            $this->page_assigned = $_SESSION['user_type'];
        }
    }

}

class Admin {
    private  $db, $admin_id, $lname, $fname, $mname, $birthdate, $age, $sex, $address, 
    $contact, $email, $code, $pass, $date_added, $status;

    public function get_admin_credential($type) {
        $admin_credential;
        switch($type) {
            case "admin_id";
                $admin_credential = [$type => $this->admin_id];
            break;
            case "lname";
                $admin_credential = [$type => $this->lname];
            break;
            case "fname";
                $admin_credential = [$type => $this->fname];
            break;
            case "mname";
                $admin_credential = [$type => $this->mname];
            break;
            case "birthdate";
                $admin_credential = [$type => $this->birthdate];
            break;
            case "age";
                $admin_credential = [$type => $this->age];
            break;
            case "sex";
                $admin_credential = [$type => $this->sex];
            break;
            case "address";
                $admin_credential = [$type => $this->address];
            break;
            case "contact";
                $admin_credential = [$type => $this->contact];
            break;
            case "email";
                $admin_credential = [$type => $this->email];
            break;
            case "code";
                $admin_credential = [$type => $this->code];
            break;
            case "pass";
                $admin_credential = [$type => $this->pass];
            break;
            case "date_added";
                $admin_credential = [$type => $this->date_added];
            break;
            case "status";
                $admin_credential = [$type => $this->status];
            break;
            case "all";
                $admin_credential = ["admin_id" => $this->admin_id, "lname" => $this->lname, "fname" => $this->fname, "mname" => $this->mname, "birthdate" => $this->birthdate, "age" => $this->age,  "sex" => $this->sex, 
                "address" => $this->address, "contact" => $this->contact, "email" => $this->email, "code" => $this->code, 
                "pass" => $this->pass, "date_added" => $this->date_added, "status" => $this->status];
            break;
            default:
                $admin_credential = null;
        }
        return $admin_credential;
    }

    public function set_admin_credential($type,$value) {
        switch($type) {
            case "admin_id";
                $this->admin_id = $value;
            break;
            case "lname";
                $this->lname = $value;
            break;
            case "fname";
                $this->fname = $value;
            break;
            case "mname";
                $this->mname = $value;
            break;
            case "birthdate";
                $this->birthdate = $value;
            break;
            case "age";
                $this->age = $value;
            break;
            case "sex";
                $this->sex = $value;
            break;
            case "address";
                $this->address = $value;
            break;
            case "contact";
                $this->contact = $value;
            break;
            case "email";
                $this->email = $value;
            break;
            case "code";
                $this->code = $value;
            break;
            case "pass";
                $this->pass = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->admin_id = $value["admin_id"];
                $this->lname = $value["lname"];
                $this->fname = $value["fname"];
                $this->mname = $value["mname"];
                $this->birthdate = $value["birthdate"];
                $this->age = $value["age"];
                $this->sex = $value["sex"];
                $this->address = $value["address"];
                $this->contact = $value["contact"];
                $this->email = $value["email"];
                $this->code = $value["code"];
                $this->pass = $value["pass"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreateadmin() {
        $status = true;
        if ($this->lname == null) $status = false;
        else if ($this->fname == null) $status = false;
        else if ($this->mname == null) $status = false;
        else if ($this->birthdate == null) $status = false;
        else if ($this->age == null) $status = false;
        else if ($this->sex == null) $status = false;
        else if ($this->address == null) $status = false;
        else if ($this->contact == null) $status = false;
        else if ($this->email == null) $status = false;
        else if ($this->code == null) $status = false;
        else if ($this->pass == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createadmin();
        return $status;
    }

    public function startreadadmin() {
        $this->admin_id = [];
        $this->lname = [];
        $this->fname = [];
        $this->mname = [];
        $this->birthdate = [];
        $this->age = [];
        $this->sex = [];
        $this->address = [];
        $this->contact = [];
        $this->email = [];
        $this->code = [];
        $this->pass = [];
        $this->date_added = [];
        $this->status = [];
        $this->readadmin();
    }

    public function startfindadmin($like) {
        $this->admin_id = [];
        $this->lname = [];
        $this->fname = [];
        $this->mname = [];
        $this->birthdate = [];
        $this->age = [];
        $this->sex = [];
        $this->address = [];
        $this->contact = [];
        $this->email = [];
        $this->code = [];
        $this->pass = [];
        $this->date_added = [];
        $this->status = [];
        $this->findadmin($like);
    }

    public function startupdateadmin() {
        $status = true;
        if ($this->admin_id == null) $status = false;
        else if ($this->lname == null) $status = false;
        else if ($this->fname == null) $status = false;
        else if ($this->mname == null) $status = false;
        else if ($this->birthdate == null) $status = false;
        else if ($this->age == null) $status = false;
        else if ($this->sex == null) $status = false;
        else if ($this->address == null) $status = false;
        else if ($this->contact == null) $status = false;
        else if ($this->email == null) $status = false;
        else if ($this->code == null) $status = false;
        else if ($this->pass == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updateadmin();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createadmin() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO admin ( admin_id,  lname, fname, mname, birthdate, age, sex, address, contact, email, code, pass, date_added, status) VALUES ( null, :lname, :fname, :mname,  :birthdate, :age, :sex, :address, :contact, :email, :code, :pass, :date_added, :status)");

            $stmt->execute(array(
                "lname" => $this->lname, 
                "fname" => $this->fname,
                "mname" => $this->mname, 
                "birthdate" => $this->birthdate,
                "age" => $this->age,
                "sex" => $this->sex,
                "address" => $this->address,
                "contact" => $this->contact,
                "email" => $this->email,
                "code" => $this->code,
                "pass" => $this->pass,
                "date_added" => $this->date_added,
                "status" => $this->status
                ));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readadmin() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM admin") as $row) {
                array_push($this->admin_id,$row["admin_id"]);
                array_push($this->lname,$row["lname"]);
                array_push($this->fname,$row["fname"]);
                array_push($this->mname,$row["mname"]);
                array_push($this->birthdate,$row["birthdate"]);
                array_push($this->age,$row["age"]);
                array_push($this->sex,$row["sex"]);
                array_push($this->address,$row["address"]);
                array_push($this->contact,$row["contact"]);
                array_push($this->email,$row["email"]);
                array_push($this->code,$row["code"]);
                array_push($this->pass,$row["pass"]);
                array_push($this->date_added,$row["date_added"]);
                array_push($this->status,$row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function findadmin($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM admin WHERE  admin_id LIKE '%" . $like . "%'  OR  lname LIKE '%" . $like . "%'   OR  fname LIKE '%" . $like . "%'   OR  mname LIKE '%" . $like . "%'  OR  birthdate LIKE '%" . $like . "%'
                OR  age LIKE '%" . $like . "%' 
                OR  sex LIKE '%" . $like . "%'
                OR  address LIKE '%" . $like . "%'
                OR  contact LIKE '%" . $like . "%'
                OR  email LIKE '%" . $like . "%'
                OR  code LIKE '%" . $like . "%'
                OR  pass LIKE '%" . $like . "%'
                OR  date_added LIKE '%" . $like . "%'
                OR  status LIKE '%" . $like . "%'
                 ") as $row) {
                array_push($this->admin_id,$row["admin_id"]);
                array_push($this->lname,$row["lname"]);
                array_push($this->fname,$row["fname"]);
                array_push($this->mname,$row["mname"]);
                array_push($this->birthdate,$row["birthdate"]);
                array_push($this->age,$row["age"]);
                array_push($this->sex,$row["sex"]);
                array_push($this->address,$row["address"]);
                array_push($this->contact,$row["contact"]);
                array_push($this->email,$row["email"]);
                array_push($this->code,$row["code"]);
                array_push($this->pass,$row["pass"]);
                array_push($this->date_added,$row["date_added"]);
                array_push($this->status,$row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function updateadmin() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE admin SET 
                lname = :lname, 
                fname = :fname,
                mname = :mname, 
                birthdate = :birthdate, 
                age = :age, 
                sex = :sex, 
                address = :address, 
                contact = :contact, 
                email = :email, 
                code = :code, 
                pass = :pass, 
                date_added = :date_added, 
                status = :status
                WHERE admin_id = :admin_id");

            $stmt->execute(array("admin_id" => $this->admin_id, "lname" => $this->lname,"fname" => $this->fname, "mname" => $this->mname, "birthdate" => $this->birthdate, "age" => $this->age, "sex" => $this->sex,
                "address" => $this->address, "contact" => $this->contact, "email" => $this->email, 
                "code" => $this->code, "pass" => $this->pass, "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
 }

  class HrStaff {
    private  $db, $hrstaff_id, $lname, $fname, $mname, $birthdate, $age, $sex, $address, 
    $contact, $email, $code, $pass, $date_added, $status;

    public function get_hrstaff_credential($type) {
        $hrstaff_credential;
        switch($type) {
            case "hrstaff_id";
                $hrstaff_credential = [$type => $this->hrstaff_id];
            break;
            case "lname";
                $hrstaff_credential = [$type => $this->lname];
            break;
            case "fname";
                $hrstaff_credential = [$type => $this->fname];
            break;
            case "mname";
                $hrstaff_credential = [$type => $this->mname];
            break;
            case "birthdate";
                $hrstaff_credential = [$type => $this->birthdate];
            break;
            case "age";
                $hrstaff_credential = [$type => $this->age];
            break;
            case "sex";
                $hrstaff_credential = [$type => $this->sex];
            break;
            case "address";
                $hrstaff_credential = [$type => $this->address];
            break;
            case "contact";
                $hrstaff_credential = [$type => $this->contact];
            break;
            case "email";
                $hrstaff_credential = [$type => $this->email];
            break;
            case "code";
                $hrstaff_credential = [$type => $this->code];
            break;
            case "pass";
                $hrstaff_credential = [$type => $this->pass];
            break;
            case "date_added";
                $hrstaff_credential = [$type => $this->date_added];
            break;
            case "status";
                $hrstaff_credential = [$type => $this->status];
            break;
            case "all";
                $hrstaff_credential = ["hrstaff_id" => $this->hrstaff_id, "lname" => $this->lname, "fname" => $this->fname, "mname" => $this->mname, "birthdate" => $this->birthdate, "age" => $this->age,  "sex" => $this->sex, 
                "address" => $this->address, "contact" => $this->contact, "email" => $this->email, "code" => $this->code, 
                "pass" => $this->pass, "date_added" => $this->date_added, "status" => $this->status];
            break;
            default:
                $hrstaff_credential = null;
        }
        return $hrstaff_credential;
    }

    public function set_hrstaff_credential($type,$value) {
        switch($type) {
            case "hrstaff_id";
                $this->hrstaff_id = $value;
            break;
            case "lname";
                $this->lname = $value;
            break;
            case "fname";
                $this->fname = $value;
            break;
            case "mname";
                $this->mname = $value;
            break;
            case "birthdate";
                $this->birthdate = $value;
            break;
            case "age";
                $this->age = $value;
            break;
            case "sex";
                $this->sex = $value;
            break;
            case "address";
                $this->address = $value;
            break;
            case "contact";
                $this->contact = $value;
            break;
            case "email";
                $this->email = $value;
            break;
            case "code";
                $this->code = $value;
            break;
            case "pass";
                $this->pass = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->hrstaff_id = $value["hrstaff_id"];
                $this->lname = $value["lname"];
                $this->fname = $value["fname"];
                $this->mname = $value["mname"];
                $this->birthdate = $value["birthdate"];
                $this->age = $value["age"];
                $this->sex = $value["sex"];
                $this->address = $value["address"];
                $this->contact = $value["contact"];
                $this->email = $value["email"];
                $this->code = $value["code"];
                $this->pass = $value["pass"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreatehrstaff() {
        $status = true;
        if ($this->lname == null) $status = false;
        else if ($this->fname == null) $status = false;
        else if ($this->mname == null) $status = false;
        else if ($this->birthdate == null) $status = false;
        else if ($this->age == null) $status = false;
        else if ($this->sex == null) $status = false;
        else if ($this->address == null) $status = false;
        else if ($this->contact == null) $status = false;
        else if ($this->email == null) $status = false;
        else if ($this->code == null) $status = false;
        else if ($this->pass == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createhrstaff();
        return $status;
    }

    public function startreadhrstaff() {
        $this->hrstaff_id = [];
        $this->lname = [];
        $this->fname = [];
        $this->mname = [];
        $this->birthdate = [];
        $this->age = [];
        $this->sex = [];
        $this->address = [];
        $this->contact = [];
        $this->email = [];
        $this->code = [];
        $this->pass = [];
        $this->date_added = [];
        $this->status = [];
        $this->readhrstaff();
    }

    public function startfindhrstaff($like) {
        $this->hrstaff_id = [];
        $this->lname = [];
        $this->fname = [];
        $this->mname = [];
        $this->birthdate = [];
        $this->age = [];
        $this->sex = [];
        $this->address = [];
        $this->contact = [];
        $this->email = [];
        $this->code = [];
        $this->pass = [];
        $this->date_added = [];
        $this->status = [];
        $this->findhrstaff($like);
    }

    public function startupdatehrstaff() {
        $status = true;
        if ($this->hrstaff_id == null) $status = false;
        else if ($this->lname == null) $status = false;
        else if ($this->fname == null) $status = false;
        else if ($this->mname == null) $status = false;
        else if ($this->birthdate == null) $status = false;
        else if ($this->age == null) $status = false;
        else if ($this->sex == null) $status = false;
        else if ($this->address == null) $status = false;
        else if ($this->contact == null) $status = false;
        else if ($this->email == null) $status = false;
        else if ($this->code == null) $status = false;
        else if ($this->pass == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updatehrstaff();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createhrstaff() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO hrstaff ( hrstaff_id,  lname, fname, mname, birthdate, age, sex, address, contact, email, code, pass, date_added, status) VALUES ( null, :lname, :fname, :mname,  :birthdate, :age, :sex, :address, :contact, :email, :code, :pass, :date_added, :status)");

            $stmt->execute(array(
                "lname" => $this->lname, 
                "fname" => $this->fname,
                "mname" => $this->mname, 
                "birthdate" => $this->birthdate,
                "age" => $this->age,
                "sex" => $this->sex,
                "address" => $this->address,
                "contact" => $this->contact,
                "email" => $this->email,
                "code" => $this->code,
                "pass" => $this->pass,
                "date_added" => $this->date_added,
                "status" => $this->status
                ));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex){
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readhrstaff() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM hrstaff") as $row) {
                array_push($this->hrstaff_id,$row["hrstaff_id"]);
                array_push($this->lname,$row["lname"]);
                array_push($this->fname,$row["fname"]);
                array_push($this->mname,$row["mname"]);
                array_push($this->birthdate,$row["birthdate"]);
                array_push($this->age,$row["age"]);
                array_push($this->sex,$row["sex"]);
                array_push($this->address,$row["address"]);
                array_push($this->contact,$row["contact"]);
                array_push($this->email,$row["email"]);
                array_push($this->code,$row["code"]);
                array_push($this->pass,$row["pass"]);
                array_push($this->date_added,$row["date_added"]);
                array_push($this->status,$row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function findhrstaff($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM hrstaff WHERE  hrstaff_id LIKE '%" . $like . "%'  OR  lname LIKE '%" . $like . "%'   OR  fname LIKE '%" . $like . "%'   OR  mname LIKE '%" . $like . "%'  OR  birthdate LIKE '%" . $like . "%'
                OR  age LIKE '%" . $like . "%' 
                OR  sex LIKE '%" . $like . "%'
                OR  address LIKE '%" . $like . "%'
                OR  contact LIKE '%" . $like . "%'
                OR  email LIKE '%" . $like . "%'
                OR  code LIKE '%" . $like . "%'
                OR  pass LIKE '%" . $like . "%'
                OR  date_added LIKE '%" . $like . "%'
                OR  status LIKE '%" . $like . "%'
                 ") as $row) {
                array_push($this->hrstaff_id,$row["hrstaff_id"]);
                array_push($this->lname,$row["lname"]);
                array_push($this->fname,$row["fname"]);
                array_push($this->mname,$row["mname"]);
                array_push($this->birthdate,$row["birthdate"]);
                array_push($this->age,$row["age"]);
                array_push($this->sex,$row["sex"]);
                array_push($this->address,$row["address"]);
                array_push($this->contact,$row["contact"]);
                array_push($this->email,$row["email"]);
                array_push($this->code,$row["code"]);
                array_push($this->pass,$row["pass"]);
                array_push($this->date_added,$row["date_added"]);
                array_push($this->status,$row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function updatehrstaff() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE hrstaff SET 
                lname = :lname, 
                fname = :fname,
                mname = :mname, 
                birthdate = :birthdate, 
                age = :age, 
                sex = :sex, 
                address = :address, 
                contact = :contact, 
                email = :email, 
                code = :code, 
                pass = :pass, 
                date_added = :date_added, 
                status = :status
                WHERE hrstaff_id = :hrstaff_id");

            $stmt->execute(array("hrstaff_id" => $this->hrstaff_id, "lname" => $this->lname,"fname" => $this->fname, "mname" => $this->mname, "birthdate" => $this->birthdate, "age" => $this->age, "sex" => $this->sex,
                "address" => $this->address, "contact" => $this->contact, "email" => $this->email, 
                "code" => $this->code, "pass" => $this->pass, "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
 }

 class Recruitment {
    private  $db, $recruitment_id, $lname, $fname, $mname, $birthdate, $age, $sex, $address, 
    $contact, $email, $code, $pass, $date_added, $status;

    public function get_recruitment_credential($type) {
        $recruitment_credential;
        switch($type) {
            case "recruitment_id";
                $recruitment_credential = [$type => $this->recruitment_id];
            break;
            case "lname";
                $recruitment_credential = [$type => $this->lname];
            break;
            case "fname";
                $recruitment_credential = [$type => $this->fname];
            break;
            case "mname";
                $recruitment_credential = [$type => $this->mname];
            break;
            case "birthdate";
                $recruitment_credential = [$type => $this->birthdate];
            break;
            case "age";
                $recruitment_credential = [$type => $this->age];
            break;
            case "sex";
                $recruitment_credential = [$type => $this->sex];
            break;
            case "address";
                $recruitment_credential = [$type => $this->address];
            break;
            case "contact";
                $recruitment_credential = [$type => $this->contact];
            break;
            case "email";
                $recruitment_credential = [$type => $this->email];
            break;
            case "code";
                $recruitment_credential = [$type => $this->code];
            break;
            case "pass";
                $recruitment_credential = [$type => $this->pass];
            break;
            case "date_added";
                $recruitment_credential = [$type => $this->date_added];
            break;
            case "status";
                $recruitment_credential = [$type => $this->status];
            break;
            case "all";
                $recruitment_credential = ["recruitment_id" => $this->recruitment_id, "lname" => $this->lname, "fname" => $this->fname, "mname" => $this->mname, "birthdate" => $this->birthdate, "age" => $this->age,  "sex" => $this->sex, 
                "address" => $this->address, "contact" => $this->contact, "email" => $this->email, "code" => $this->code, 
                "pass" => $this->pass, "date_added" => $this->date_added, "status" => $this->status];
            break;
            default:
                $recruitment_credential = null;
        }
        return $recruitment_credential;
    }

    public function set_recruitment_credential($type,$value) {
        switch($type) {
            case "recruitment_id";
                $this->recruitment_id = $value;
            break;
            case "lname";
                $this->lname = $value;
            break;
            case "fname";
                $this->fname = $value;
            break;
            case "mname";
                $this->mname = $value;
            break;
            case "birthdate";
                $this->birthdate = $value;
            break;
            case "age";
                $this->age = $value;
            break;
            case "sex";
                $this->sex = $value;
            break;
            case "address";
                $this->address = $value;
            break;
            case "contact";
                $this->contact = $value;
            break;
            case "email";
                $this->email = $value;
            break;
            case "code";
                $this->code = $value;
            break;
            case "pass";
                $this->pass = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->recruitment_id = $value["recruitment_id"];
                $this->lname = $value["lname"];
                $this->fname = $value["fname"];
                $this->mname = $value["mname"];
                $this->birthdate = $value["birthdate"];
                $this->age = $value["age"];
                $this->sex = $value["sex"];
                $this->address = $value["address"];
                $this->contact = $value["contact"];
                $this->email = $value["email"];
                $this->code = $value["code"];
                $this->pass = $value["pass"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreaterecruitment() {
        $status = true;
        if ($this->lname == null) $status = false;
        else if ($this->fname == null) $status = false;
        else if ($this->mname == null) $status = false;
        else if ($this->birthdate == null) $status = false;
        else if ($this->age == null) $status = false;
        else if ($this->sex == null) $status = false;
        else if ($this->address == null) $status = false;
        else if ($this->contact == null) $status = false;
        else if ($this->email == null) $status = false;
        else if ($this->code == null) $status = false;
        else if ($this->pass == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createrecruitment();
        return $status;
    }

    public function startreadrecruitment() {
        $this->recruitment_id = [];
        $this->lname = [];
        $this->fname = [];
        $this->mname = [];
        $this->birthdate = [];
        $this->age = [];
        $this->sex = [];
        $this->address = [];
        $this->contact = [];
        $this->email = [];
        $this->code = [];
        $this->pass = [];
        $this->date_added = [];
        $this->status = [];
        $this->readrecruitment();
    }

    public function startfindrecruitment($like) {
        $this->recruitment_id = [];
        $this->lname = [];
        $this->fname = [];
        $this->mname = [];
        $this->birthdate = [];
        $this->age = [];
        $this->sex = [];
        $this->address = [];
        $this->contact = [];
        $this->email = [];
        $this->code = [];
        $this->pass = [];
        $this->date_added = [];
        $this->status = [];
        $this->findrecruitment($like);
    }

    public function startupdaterecruitment() {
        $status = true;
        if ($this->recruitment_id == null) $status = false;
        else if ($this->lname == null) $status = false;
        else if ($this->fname == null) $status = false;
        else if ($this->mname == null) $status = false;
        else if ($this->birthdate == null) $status = false;
        else if ($this->age == null) $status = false;
        else if ($this->sex == null) $status = false;
        else if ($this->address == null) $status = false;
        else if ($this->contact == null) $status = false;
        else if ($this->email == null) $status = false;
        else if ($this->code == null) $status = false;
        else if ($this->pass == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updaterecruitment();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createrecruitment() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO recruitment ( recruitment_id,  lname, fname, mname, birthdate, age, sex, address, contact, email, code, pass, date_added, status) VALUES ( null, :lname, :fname, :mname,  :birthdate, :age, :sex, :address, :contact, :email, :code, :pass, :date_added, :status)");

            $stmt->execute(array(
                "lname" => $this->lname, 
                "fname" => $this->fname,
                "mname" => $this->mname, 
                "birthdate" => $this->birthdate,
                "age" => $this->age,
                "sex" => $this->sex,
                "address" => $this->address,
                "contact" => $this->contact,
                "email" => $this->email,
                "code" => $this->code,
                "pass" => $this->pass,
                "date_added" => $this->date_added,
                "status" => $this->status
                ));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readrecruitment() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM recruitment") as $row) {
                array_push($this->recruitment_id,$row["recruitment_id"]);
                array_push($this->lname,$row["lname"]);
                array_push($this->fname,$row["fname"]);
                array_push($this->mname,$row["mname"]);
                array_push($this->birthdate,$row["birthdate"]);
                array_push($this->age,$row["age"]);
                array_push($this->sex,$row["sex"]);
                array_push($this->address,$row["address"]);
                array_push($this->contact,$row["contact"]);
                array_push($this->email,$row["email"]);
                array_push($this->code,$row["code"]);
                array_push($this->pass,$row["pass"]);
                array_push($this->date_added,$row["date_added"]);
                array_push($this->status,$row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function findrecruitment($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM recruitment WHERE  recruitment_id LIKE '%" . $like . "%'  OR  lname LIKE '%" . $like . "%'   OR  fname LIKE '%" . $like . "%'   OR  mname LIKE '%" . $like . "%'  OR  birthdate LIKE '%" . $like . "%'
                OR  age LIKE '%" . $like . "%' 
                OR  sex LIKE '%" . $like . "%'
                OR  address LIKE '%" . $like . "%'
                OR  contact LIKE '%" . $like . "%'
                OR  email LIKE '%" . $like . "%'
                OR  code LIKE '%" . $like . "%'
                OR  pass LIKE '%" . $like . "%'
                OR  date_added LIKE '%" . $like . "%'
                OR  status LIKE '%" . $like . "%'
                 ") as $row) {
                array_push($this->recruitment_id,$row["recruitment_id"]);
                array_push($this->lname,$row["lname"]);
                array_push($this->fname,$row["fname"]);
                array_push($this->mname,$row["mname"]);
                array_push($this->birthdate,$row["birthdate"]);
                array_push($this->age,$row["age"]);
                array_push($this->sex,$row["sex"]);
                array_push($this->address,$row["address"]);
                array_push($this->contact,$row["contact"]);
                array_push($this->email,$row["email"]);
                array_push($this->code,$row["code"]);
                array_push($this->pass,$row["pass"]);
                array_push($this->date_added,$row["date_added"]);
                array_push($this->status,$row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function updaterecruitment() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE recruitment SET 
                lname = :lname, 
                fname = :fname,
                mname = :mname, 
                birthdate = :birthdate, 
                age = :age, 
                sex = :sex, 
                address = :address, 
                contact = :contact, 
                email = :email, 
                code = :code, 
                pass = :pass, 
                date_added = :date_added, 
                status = :status
                WHERE recruitment_id = :recruitment_id");

            $stmt->execute(array("recruitment_id" => $this->recruitment_id, "lname" => $this->lname,"fname" => $this->fname, "mname" => $this->mname, "birthdate" => $this->birthdate, "age" => $this->age, "sex" => $this->sex,
                "address" => $this->address, "contact" => $this->contact, "email" => $this->email, 
                "code" => $this->code, "pass" => $this->pass, "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
 }

  class Coordinator {
    private  $db, $coordinator_id, $lname, $fname, $mname, $birthdate, $age, $sex, $address, 
    $contact, $email, $code, $pass, $date_added, $status;

    public function get_coordinator_credential($type) {
        $coordinator_credential;
        switch($type) {
            case "coordinator_id";
                $coordinator_credential = [$type => $this->coordinator_id];
            break;
            case "lname";
                $coordinator_credential = [$type => $this->lname];
            break;
            case "fname";
                $coordinator_credential = [$type => $this->fname];
            break;
            case "mname";
                $coordinator_credential = [$type => $this->mname];
            break;
            case "birthdate";
                $coordinator_credential = [$type => $this->birthdate];
            break;
            case "age";
                $coordinator_credential = [$type => $this->age];
            break;
            case "sex";
                $coordinator_credential = [$type => $this->sex];
            break;
            case "address";
                $coordinator_credential = [$type => $this->address];
            break;
            case "contact";
                $coordinator_credential = [$type => $this->contact];
            break;
            case "email";
                $coordinator_credential = [$type => $this->email];
            break;
            case "code";
                $coordinator_credential = [$type => $this->code];
            break;
            case "pass";
                $coordinator_credential = [$type => $this->pass];
            break;
            case "date_added";
                $coordinator_credential = [$type => $this->date_added];
            break;
            case "status";
                $coordinator_credential = [$type => $this->status];
            break;
            case "all";
                $coordinator_credential = ["coordinator_id" => $this->coordinator_id, "lname" => $this->lname, "fname" => $this->fname, "mname" => $this->mname, "birthdate" => $this->birthdate, "age" => $this->age,  "sex" => $this->sex, 
                "address" => $this->address, "contact" => $this->contact, "email" => $this->email, "code" => $this->code, 
                "pass" => $this->pass, "date_added" => $this->date_added, "status" => $this->status];
            break;
            default:
                $coordinator_credential = null;
        }
        return $coordinator_credential;
    }

    public function set_coordinator_credential($type,$value) {
        switch($type) {
            case "coordinator_id";
                $this->coordinator_id = $value;
            break;
            case "lname";
                $this->lname = $value;
            break;
            case "fname";
                $this->fname = $value;
            break;
            case "mname";
                $this->mname = $value;
            break;
            case "birthdate";
                $this->birthdate = $value;
            break;
            case "age";
                $this->age = $value;
            break;
            case "sex";
                $this->sex = $value;
            break;
            case "address";
                $this->address = $value;
            break;
            case "contact";
                $this->contact = $value;
            break;
            case "email";
                $this->email = $value;
            break;
            case "code";
                $this->code = $value;
            break;
            case "pass";
                $this->pass = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->coordinator_id = $value["coordinator_id"];
                $this->lname = $value["lname"];
                $this->fname = $value["fname"];
                $this->mname = $value["mname"];
                $this->birthdate = $value["birthdate"];
                $this->age = $value["age"];
                $this->sex = $value["sex"];
                $this->address = $value["address"];
                $this->contact = $value["contact"];
                $this->email = $value["email"];
                $this->code = $value["code"];
                $this->pass = $value["pass"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreatecoordinator() {
        $status = true;
        if ($this->lname == null) $status = false;
        else if ($this->fname == null) $status = false;
        else if ($this->mname == null) $status = false;
        else if ($this->birthdate == null) $status = false;
        else if ($this->age == null) $status = false;
        else if ($this->sex == null) $status = false;
        else if ($this->address == null) $status = false;
        else if ($this->contact == null) $status = false;
        else if ($this->email == null) $status = false;
        else if ($this->code == null) $status = false;
        else if ($this->pass == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createcoordinator();
        return $status;
    }

    public function startreadcoordinator() {
        $this->coordinator_id = [];
        $this->lname = [];
        $this->fname = [];
        $this->mname = [];
        $this->birthdate = [];
        $this->age = [];
        $this->sex = [];
        $this->address = [];
        $this->contact = [];
        $this->email = [];
        $this->code = [];
        $this->pass = [];
        $this->date_added = [];
        $this->status = [];
        $this->readcoordinator();
    }

    public function startfindcoordinator($like) {
        $this->coordinator_id = [];
        $this->lname = [];
        $this->fname = [];
        $this->mname = [];
        $this->birthdate = [];
        $this->age = [];
        $this->sex = [];
        $this->address = [];
        $this->contact = [];
        $this->email = [];
        $this->code = [];
        $this->pass = [];
        $this->date_added = [];
        $this->status = [];
        $this->findcoordinator($like);
    }

    public function startupdatecoordinator() {
        $status = true;
        if ($this->coordinator_id == null) $status = false;
        else if ($this->lname == null) $status = false;
        else if ($this->fname == null) $status = false;
        else if ($this->mname == null) $status = false;
        else if ($this->birthdate == null) $status = false;
        else if ($this->age == null) $status = false;
        else if ($this->sex == null) $status = false;
        else if ($this->address == null) $status = false;
        else if ($this->contact == null) $status = false;
        else if ($this->email == null) $status = false;
        else if ($this->code == null) $status = false;
        else if ($this->pass == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updatecoordinator();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createcoordinator() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO coordinator ( coordinator_id,  lname, fname, mname, birthdate, age, sex, address, contact, email, code, pass, date_added, status) VALUES ( null, :lname, :fname, :mname,  :birthdate, :age, :sex, :address, :contact, :email, :code, :pass, :date_added, :status)");

            $stmt->execute(array(
                "lname" => $this->lname, 
                "fname" => $this->fname,
                "mname" => $this->mname, 
                "birthdate" => $this->birthdate,
                "age" => $this->age,
                "sex" => $this->sex,
                "address" => $this->address,
                "contact" => $this->contact,
                "email" => $this->email,
                "code" => $this->code,
                "pass" => $this->pass,
                "date_added" => $this->date_added,
                "status" => $this->status
                ));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readcoordinator() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM coordinator") as $row) {
                array_push($this->coordinator_id,$row["coordinator_id"]);
                array_push($this->lname,$row["lname"]);
                array_push($this->fname,$row["fname"]);
                array_push($this->mname,$row["mname"]);
                array_push($this->birthdate,$row["birthdate"]);
                array_push($this->age,$row["age"]);
                array_push($this->sex,$row["sex"]);
                array_push($this->address,$row["address"]);
                array_push($this->contact,$row["contact"]);
                array_push($this->email,$row["email"]);
                array_push($this->code,$row["code"]);
                array_push($this->pass,$row["pass"]);
                array_push($this->date_added,$row["date_added"]);
                array_push($this->status,$row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function findcoordinator($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM coordinator WHERE  coordinator_id LIKE '%" . $like . "%'  OR  lname LIKE '%" . $like . "%'   OR  fname LIKE '%" . $like . "%'   OR  mname LIKE '%" . $like . "%'  OR  birthdate LIKE '%" . $like . "%'
                OR  age LIKE '%" . $like . "%' 
                OR  sex LIKE '%" . $like . "%'
                OR  address LIKE '%" . $like . "%'
                OR  contact LIKE '%" . $like . "%'
                OR  email LIKE '%" . $like . "%'
                OR  code LIKE '%" . $like . "%'
                OR  pass LIKE '%" . $like . "%'
                OR  date_added LIKE '%" . $like . "%'
                OR  status LIKE '%" . $like . "%'
                 ") as $row) {
                array_push($this->coordinator_id,$row["coordinator_id"]);
                array_push($this->lname,$row["lname"]);
                array_push($this->fname,$row["fname"]);
                array_push($this->mname,$row["mname"]);
                array_push($this->birthdate,$row["birthdate"]);
                array_push($this->age,$row["age"]);
                array_push($this->sex,$row["sex"]);
                array_push($this->address,$row["address"]);
                array_push($this->contact,$row["contact"]);
                array_push($this->email,$row["email"]);
                array_push($this->code,$row["code"]);
                array_push($this->pass,$row["pass"]);
                array_push($this->date_added,$row["date_added"]);
                array_push($this->status,$row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function updatecoordinator() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE coordinator SET 
                lname = :lname, 
                fname = :fname,
                mname = :mname, 
                birthdate = :birthdate, 
                age = :age, 
                sex = :sex, 
                address = :address, 
                contact = :contact, 
                email = :email, 
                code = :code, 
                pass = :pass, 
                date_added = :date_added, 
                status = :status
                WHERE coordinator_id = :coordinator_id");

            $stmt->execute(array("coordinator_id" => $this->coordinator_id, "lname" => $this->lname,"fname" => $this->fname, "mname" => $this->mname, "birthdate" => $this->birthdate, "age" => $this->age, "sex" => $this->sex,
                "address" => $this->address, "contact" => $this->contact, "email" => $this->email, 
                "code" => $this->code, "pass" => $this->pass, "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
 }

class Company {
    private  $db, $company_id, $company_name, $description, $contact, $email, $address, $date_added, $status;

    public function get_company_credential($type) {
        $company_credential;
        switch($type) {
            case "company_id";
                $company_credential = [$type => $this->company_id];
            break;
            case "company_name";
                $company_credential = [$type => $this->company_name];
            break;
            case "description";
                $company_credential = [$type => $this->description];
            break;
            case "contact";
                $company_credential = [$type => $this->contact];
            break;
            case "email";
                $company_credential = [$type => $this->email];
            break;
            case "address";
                $company_credential = [$type => $this->address];
            break;
            case "date_added";
                $company_credential = [$type => $this->date_added];
            break;
            case "status";
                $company_credential = [$type => $this->status];
            break;
            case "all";
                $company_credential = ["company_id" => $this->company_id, "company_name" => $this->company_name, 
                "description" => $this->description, "contact" => $this->contact, "email" => $this->email, "address" => $this->address,  "date_added" => $this->date_added, 
                    "status" => $this->status];
            break;
            default:
                $company_credential = null;
        }
        return $company_credential;
    }

    public function set_company_credential($type,$value) {
        switch($type) {
            case "company_id";
                $this->company_id = $value;
            break;
            case "company_name";
                $this->company_name = $value;
            break;
            case "description";
                $this->description = $value;
            break;
            case "contact";
                $this->contact = $value;
            break;
            case "email";
                $this->email = $value;
            break;
            case "address";
                $this->address = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->company_id = $value["company_id"];
                $this->company_name = $value["company_name"];
                $this->description = $value["description"];
                $this->contact = $value["contact"];
                $this->email = $value["email"];
                $this->address = $value["address"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreatecompany() {
        $status = true;
        if ($this->company_name == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->contact == null) $status = false;
        else if ($this->email == null) $status = false;
        else if ($this->address == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createcompany();
        return $status;
    }

    public function startreadcompany() {
        $this->company_id = [];
        $this->company_name = [];
        $this->description = [];
        $this->contact = [];
        $this->email = [];
        $this->address = [];
        $this->date_added = [];
        $this->status = [];
        $this->readcompany();
    }

    public function startfindcompany($like) {
        $this->company_id = [];
        $this->company_name = [];
        $this->description = [];
        $this->contact = [];
        $this->email = [];
        $this->address = [];
        $this->date_added = [];
        $this->status = [];
        $this->findcompany($like);
    }

    public function startupdatecompany() {
        $status = true;
        if ($this->company_id == null) $status = false;
        else if ($this->company_name == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->contact == null) $status = false;
        else if ($this->email == null) $status = false;
        else if ($this->address == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updatecompany();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createcompany() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO company ( company_id,  company_name, description, contact, email, address, date_added,  status) VALUES ( null, :company_name, :description, :contact,  :email, :address, :date_added,:status)");

            $stmt->execute(array(
                "company_name" => $this->company_name, 
                "description" => $this->description,
                "contact" => $this->contact, 
                "email" => $this->email,
                "address" => $this->address,
                "date_added" => $this->date_added,
                "status" => $this->status
                ));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readcompany() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM company") as $row) {
                array_push($this->company_id,$row["company_id"]);
                array_push($this->company_name,$row["company_name"]);
                array_push($this->description,$row["description"]);
                array_push($this->contact,$row["contact"]);
                array_push($this->email,$row["email"]);
                array_push($this->address,$row["address"]);
                array_push($this->date_added,$row["date_added"]);
                array_push($this->status,$row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function findcompany($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM company WHERE  company_id LIKE '%" . $like . "%'  OR  company_name LIKE '%" . $like . "%'   OR  description LIKE '%" . $like . "%'   OR  contact LIKE '%" . $like . "%'  OR  email LIKE '%" . $like . "%'
                OR  address LIKE '%" . $like . "%' 
                OR  date_added LIKE '%" . $like . "%'
                OR  status LIKE '%" . $like . "%'
                 ") as $row) {
                array_push($this->company_id,$row["company_id"]);
                array_push($this->company_name,$row["company_name"]);
                array_push($this->description,$row["description"]);
                array_push($this->contact,$row["contact"]);
                array_push($this->email,$row["email"]);
                array_push($this->address,$row["address"]);
                array_push($this->date_added,$row["date_added"]);
                array_push($this->status,$row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function updatecompany() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE company SET 
                company_name = :company_name, 
                description = :description,
                contact = :contact, 
                email = :email, 
                address = :address, 
                date_added = :date_added,
                status = :status
                WHERE company_id = :company_id");

            $stmt->execute(array("company_id" => $this->company_id, "company_name" => $this->company_name,"description" => $this->description, "contact" => $this->contact, "email" => $this->email, "address" => $this->address, "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
 }

 class Coursecode {
    private $db, $coursecode_id, $coursecode, $description, $remarks, $date_added, $status;
    
    public function get_coursecode_credential($type) {
        $coursecode_credential;
        switch($type) {
            case "coursecode_id";
                $coursecode_credential = [$type => $this->coursecode_id];
            break;
            case "coursecode";
                $coursecode_credential = [$type => $this->coursecode];
            break;
            case "description";
                $coursecode_credential = [$type => $this->description];
            break;
            case "remarks";
                $coursecode_credential = [$type => $this->remarks];
            break;
            case "date_added";
                $coursecode_credential = [$type => $this->date_added];
            break;
            case "status";
                $coursecode_credential = [$type => $this->status];
            break;
            case "all";
                $coursecode_credential = ["coursecode_id" => $this->coursecode_id, "coursecode" => $this->coursecode, "description" => $this->description, "remarks" => $this->remarks, "date_added" => $this->date_added, "status" => $this->status];
            break;
            default:
                $coursecode_credential = null;
        }
        return $coursecode_credential;
    }

    public function set_coursecode_credential($type,$value) {
        switch($type) {
            case "coursecode_id";
                $this->coursecode_id = $value;
            break;
            case "coursecode";
                $this->coursecode = $value;
            break;
            case "description";
                $this->description = $value;
            break;
            case "remarks";
                $this->remarks = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->coursecode_id = $value["coursecode_id"];
                $this->coursecode = $value["coursecode"];
                $this->description = $value["description"];
                $this->remarks = $value["remarks"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreatecoursecode() {
        $status = true;
        if ($this->coursecode == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createcoursecode();
        return $status;
    }

    public function startreadcoursecode() {
        $this->coursecode_id = [];
        $this->coursecode = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->readcoursecode();
    }
    public function startfindcoursecode($like) {
        $this->coursecode_id = [];
        $this->coursecode = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->findcoursecode($like);
    }

    public function startupdatecoursecode() {
        $status = true;
        if ($this->coursecode_id == null) $status = false;
        else if ($this->coursecode == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updatecoursecode();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createcoursecode() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO coursecode ( coursecode_id,  coursecode, description, remarks,  date_added, status) VALUES ( null,  :coursecode, :description, :remarks,  :date_added, :status)");
            $stmt->execute(array("coursecode" => $this->coursecode, "description" => $this->description,  "remarks" => $this->remarks,  
                "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readcoursecode() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM coursecode") as $row) {
                array_push($this->coursecode_id, $row["coursecode_id"]);
                array_push($this->coursecode, $row["coursecode"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function findcoursecode($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM coursecode WHERE  coursecode_id LIKE '%" . $like . "%'  
                OR  coursecode LIKE '%" . $like . "%'
                OR  description LIKE '%" . $like . "%'  
                OR  remarks LIKE '%" . $like . "%'    
                OR  date_added LIKE '%" . $like . "%' 
                OR  status LIKE '%" . $like . "%'") as $row) {
                array_push($this->coursecode_id, $row["coursecode_id"]);
                array_push($this->coursecode, $row["coursecode"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
    
    protected function updatecoursecode() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE coursecode SET 
                coursecode = :coursecode, 
                description = :description, 
                remarks = :remarks,  
                date_added = :date_added, 
                status = :status 
                WHERE coursecode_id = :coursecode_id");
            $stmt->execute(array("coursecode_id" => $this->coursecode_id, 
                "coursecode" => $this->coursecode, 
                "description" => $this->description, 
                "remarks" => $this->remarks, 
                "date_added" => $this->date_added, 
                "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
}


 class Areacode {
    private $db, $areacode_id, $areacode, $description, $remarks, $date_added, $status;
    
    public function get_areacode_credential($type) {
        $areacode_credential;
        switch($type) {
            case "areacode_id";
                $areacode_credential = [$type => $this->areacode_id];
            break;
            case "areacode";
                $areacode_credential = [$type => $this->areacode];
            break;
            case "description";
                $areacode_credential = [$type => $this->description];
            break;
            case "remarks";
                $areacode_credential = [$type => $this->remarks];
            break;
            case "date_added";
                $areacode_credential = [$type => $this->date_added];
            break;
            case "status";
                $areacode_credential = [$type => $this->status];
            break;
            case "all";
                $areacode_credential = ["areacode_id" => $this->areacode_id, "areacode" => $this->areacode, "description" => $this->description, "remarks" => $this->remarks, "date_added" => $this->date_added, "status" => $this->status];
            break;
            default:
                $areacode_credential = null;
        }
        return $areacode_credential;
    }

    public function set_areacode_credential($type,$value) {
        switch($type) {
            case "areacode_id";
                $this->areacode_id = $value;
            break;
            case "areacode";
                $this->areacode = $value;
            break;
            case "description";
                $this->description = $value;
            break;
            case "remarks";
                $this->remarks = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->areacode_id = $value["areacode_id"];
                $this->areacode = $value["areacode"];
                $this->description = $value["description"];
                $this->remarks = $value["remarks"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreateareacode() {
        $status = true;
        if ($this->areacode == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createareacode();
        return $status;
    }

    public function startreadareacode() {
        $this->areacode_id = [];
        $this->areacode = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->readareacode();
    }
    public function startfindareacode($like) {
        $this->areacode_id = [];
        $this->areacode = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->findareacode($like);
    }

    public function startupdateareacode() {
        $status = true;
        if ($this->areacode_id == null) $status = false;
        else if ($this->areacode == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updateareacode();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createareacode() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO areacode ( areacode_id,  areacode, description, remarks,  date_added, status) VALUES ( null,  :areacode, :description, :remarks,  :date_added, :status)");
            $stmt->execute(array("areacode" => $this->areacode, "description" => $this->description,  "remarks" => $this->remarks,  
                "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readareacode() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM areacode") as $row) {
                array_push($this->areacode_id, $row["areacode_id"]);
                array_push($this->areacode, $row["areacode"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function findareacode($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM areacode WHERE  areacode_id LIKE '%" . $like . "%'  
                OR  areacode LIKE '%" . $like . "%'
                OR  description LIKE '%" . $like . "%'  
                OR  remarks LIKE '%" . $like . "%'    
                OR  date_added LIKE '%" . $like . "%' 
                OR  status LIKE '%" . $like . "%'") as $row) {
                array_push($this->areacode_id, $row["areacode_id"]);
                array_push($this->areacode, $row["areacode"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
    
    protected function updateareacode() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE areacode SET 
                areacode = :areacode, 
                description = :description, 
                remarks = :remarks,  
                date_added = :date_added, 
                status = :status 
                WHERE areacode_id = :areacode_id");
            $stmt->execute(array("areacode_id" => $this->areacode_id, 
                "areacode" => $this->areacode, 
                "description" => $this->description, 
                "remarks" => $this->remarks, 
                "date_added" => $this->date_added, 
                "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
}

class Coursetitle {
    private $db, $coursetitle_id, $coursetitle, $description, $remarks, $date_added, $status;
    
    public function get_coursetitle_credential($type) {
        $coursetitle_credential;
        switch($type) {
            case "coursetitle_id";
                $coursetitle_credential = [$type => $this->coursetitle_id];
            break;
            case "coursetitle";
                $coursetitle_credential = [$type => $this->coursetitle];
            break;
            case "description";
                $coursetitle_credential = [$type => $this->description];
            break;
            case "remarks";
                $coursetitle_credential = [$type => $this->remarks];
            break;
            case "date_added";
                $coursetitle_credential = [$type => $this->date_added];
            break;
            case "status";
                $coursetitle_credential = [$type => $this->status];
            break;
            case "all";
                $coursetitle_credential = ["coursetitle_id" => $this->coursetitle_id, "coursetitle" => $this->coursetitle, "description" => $this->description, "remarks" => $this->remarks, "date_added" => $this->date_added, "status" => $this->status];
            break;
            default:
                $coursetitle_credential = null;
        }
        return $coursetitle_credential;
    }

    public function set_coursetitle_credential($type,$value) {
        switch($type) {
            case "coursetitle_id";
                $this->coursetitle_id = $value;
            break;
            case "coursetitle";
                $this->coursetitle = $value;
            break;
            case "description";
                $this->description = $value;
            break;
            case "remarks";
                $this->remarks = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->coursetitle_id = $value["coursetitle_id"];
                $this->coursetitle = $value["coursetitle"];
                $this->description = $value["description"];
                $this->remarks = $value["remarks"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreatecoursetitle() {
        $status = true;
        if ($this->coursetitle == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createcoursetitle();
        return $status;
    }

    public function startreadcoursetitle() {
        $this->coursetitle_id = [];
        $this->coursetitle = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->readcoursetitle();
    }
    public function startfindcoursetitle($like) {
        $this->coursetitle_id = [];
        $this->coursetitle = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->findcoursetitle($like);
    }

    public function startupdatecoursetitle() {
        $status = true;
        if ($this->coursetitle_id == null) $status = false;
        else if ($this->coursetitle == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updatecoursetitle();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createcoursetitle() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO coursetitle ( coursetitle_id,  coursetitle, description, remarks,  date_added, status) VALUES ( null,  :coursetitle, :description, :remarks,  :date_added, :status)");
            $stmt->execute(array("coursetitle" => $this->coursetitle, "description" => $this->description,  "remarks" => $this->remarks,  
                "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readcoursetitle() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM coursetitle") as $row) {
                array_push($this->coursetitle_id, $row["coursetitle_id"]);
                array_push($this->coursetitle, $row["coursetitle"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function findcoursetitle($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM coursetitle WHERE  coursetitle_id LIKE '%" . $like . "%'  
                OR  coursetitle LIKE '%" . $like . "%'
                OR  description LIKE '%" . $like . "%'  
                OR  remarks LIKE '%" . $like . "%'    
                OR  date_added LIKE '%" . $like . "%' 
                OR  status LIKE '%" . $like . "%'") as $row) {
                array_push($this->coursetitle_id, $row["coursetitle_id"]);
                array_push($this->coursetitle, $row["coursetitle"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
    
    protected function updatecoursetitle() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE coursetitle SET 
                coursetitle = :coursetitle, 
                description = :description, 
                remarks = :remarks,  
                date_added = :date_added, 
                status = :status 
                WHERE coursetitle_id = :coursetitle_id");
            $stmt->execute(array("coursetitle_id" => $this->coursetitle_id, 
                "coursetitle" => $this->coursetitle, 
                "description" => $this->description, 
                "remarks" => $this->remarks, 
                "date_added" => $this->date_added, 
                "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
}


 class Unit {
    private $db, $unit_id, $unit, $description, $remarks, $date_added, $status;
    
    public function get_unit_credential($type) {
        $unit_credential;
        switch($type) {
            case "unit_id";
                $unit_credential = [$type => $this->unit_id];
            break;
            case "unit";
                $unit_credential = [$type => $this->unit];
            break;
            case "description";
                $unit_credential = [$type => $this->description];
            break;
            case "remarks";
                $unit_credential = [$type => $this->remarks];
            break;
            case "date_added";
                $unit_credential = [$type => $this->date_added];
            break;
            case "status";
                $unit_credential = [$type => $this->status];
            break;
            case "all";
                $unit_credential = ["unit_id" => $this->unit_id, "unit" => $this->unit, "description" => $this->description, "remarks" => $this->remarks, "date_added" => $this->date_added, "status" => $this->status];
            break;
            default:
                $unit_credential = null;
        }
        return $unit_credential;
    }

    public function set_unit_credential($type,$value) {
        switch($type) {
            case "unit_id";
                $this->unit_id = $value;
            break;
            case "unit";
                $this->unit = $value;
            break;
            case "description";
                $this->description = $value;
            break;
            case "remarks";
                $this->remarks = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->unit_id = $value["unit_id"];
                $this->unit = $value["unit"];
                $this->description = $value["description"];
                $this->remarks = $value["remarks"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreateunit() {
        $status = true;
        if ($this->unit == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createunit();
        return $status;
    }

    public function startreadunit() {
        $this->unit_id = [];
        $this->unit = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->readunit();
    }
    public function startfindunit($like) {
        $this->unit_id = [];
        $this->unit = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->findunit($like);
    }

    public function startupdateunit() {
        $status = true;
        if ($this->unit_id == null) $status = false;
        else if ($this->unit == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updateunit();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createunit() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO unit ( unit_id,  unit, description, remarks,  date_added, status) VALUES ( null,  :unit, :description, :remarks,  :date_added, :status)");
            $stmt->execute(array("unit" => $this->unit, "description" => $this->description,  "remarks" => $this->remarks,  
                "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readunit() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM unit") as $row) {
                array_push($this->unit_id, $row["unit_id"]);
                array_push($this->unit, $row["unit"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function findunit($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM unit WHERE  unit_id LIKE '%" . $like . "%'  
                OR  unit LIKE '%" . $like . "%'
                OR  description LIKE '%" . $like . "%'  
                OR  remarks LIKE '%" . $like . "%'    
                OR  date_added LIKE '%" . $like . "%' 
                OR  status LIKE '%" . $like . "%'") as $row) {
                array_push($this->unit_id, $row["unit_id"]);
                array_push($this->unit, $row["unit"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
    
    protected function updateunit() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE unit SET 
                unit = :unit, 
                description = :description, 
                remarks = :remarks,  
                date_added = :date_added, 
                status = :status 
                WHERE unit_id = :unit_id");
            $stmt->execute(array("unit_id" => $this->unit_id, 
                "unit" => $this->unit, 
                "description" => $this->description, 
                "remarks" => $this->remarks, 
                "date_added" => $this->date_added, 
                "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
}

class Teacher {
    private  $db, $teacher_id, $lname, $fname, $mname, $birthdate, $age, $sex, $address, 
    $contact, $email, $code, $pass, $date_added, $status;

    public function get_teacher_credential($type) {
        $teacher_credential;
        switch($type) {
            case "teacher_id";
                $teacher_credential = [$type => $this->teacher_id];
            break;
            case "lname";
                $teacher_credential = [$type => $this->lname];
            break;
            case "fname";
                $teacher_credential = [$type => $this->fname];
            break;
            case "mname";
                $teacher_credential = [$type => $this->mname];
            break;
            case "birthdate";
                $teacher_credential = [$type => $this->birthdate];
            break;
            case "age";
                $teacher_credential = [$type => $this->age];
            break;
            case "sex";
                $teacher_credential = [$type => $this->sex];
            break;
            case "address";
                $teacher_credential = [$type => $this->address];
            break;
            case "contact";
                $teacher_credential = [$type => $this->contact];
            break;
            case "email";
                $teacher_credential = [$type => $this->email];
            break;
            case "code";
                $teacher_credential = [$type => $this->code];
            break;
            case "pass";
                $teacher_credential = [$type => $this->pass];
            break;
            case "date_added";
                $teacher_credential = [$type => $this->date_added];
            break;
            case "status";
                $teacher_credential = [$type => $this->status];
            break;
            case "all";
                $teacher_credential = ["teacher_id" => $this->teacher_id, "lname" => $this->lname, "fname" => $this->fname, "mname" => $this->mname, "birthdate" => $this->birthdate, "age" => $this->age,  "sex" => $this->sex, 
                "address" => $this->address, "contact" => $this->contact, "email" => $this->email, "code" => $this->code, 
                "pass" => $this->pass, "date_added" => $this->date_added, "status" => $this->status];
            break;
            default:
                $teacher_credential = null;
        }
        return $teacher_credential;
    }

    public function set_teacher_credential($type,$value) {
        switch($type) {
            case "teacher_id";
                $this->teacher_id = $value;
            break;
            case "lname";
                $this->lname = $value;
            break;
            case "fname";
                $this->fname = $value;
            break;
            case "mname";
                $this->mname = $value;
            break;
            case "birthdate";
                $this->birthdate = $value;
            break;
            case "age";
                $this->age = $value;
            break;
            case "sex";
                $this->sex = $value;
            break;
            case "address";
                $this->address = $value;
            break;
            case "contact";
                $this->contact = $value;
            break;
            case "email";
                $this->email = $value;
            break;
            case "code";
                $this->code = $value;
            break;
            case "pass";
                $this->pass = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->teacher_id = $value["teacher_id"];
                $this->lname = $value["lname"];
                $this->fname = $value["fname"];
                $this->mname = $value["mname"];
                $this->birthdate = $value["birthdate"];
                $this->age = $value["age"];
                $this->sex = $value["sex"];
                $this->address = $value["address"];
                $this->contact = $value["contact"];
                $this->email = $value["email"];
                $this->code = $value["code"];
                $this->pass = $value["pass"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreateteacher() {
        $status = true;
        if ($this->lname == null) $status = false;
        else if ($this->fname == null) $status = false;
        else if ($this->mname == null) $status = false;
        else if ($this->birthdate == null) $status = false;
        else if ($this->age == null) $status = false;
        else if ($this->sex == null) $status = false;
        else if ($this->address == null) $status = false;
        else if ($this->contact == null) $status = false;
        else if ($this->email == null) $status = false;
        else if ($this->code == null) $status = false;
        else if ($this->pass == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createteacher();
        return $status;
    }

    public function startreadteacher() {
        $this->teacher_id = [];
        $this->lname = [];
        $this->fname = [];
        $this->mname = [];
        $this->birthdate = [];
        $this->age = [];
        $this->sex = [];
        $this->address = [];
        $this->contact = [];
        $this->email = [];
        $this->code = [];
        $this->pass = [];
        $this->date_added = [];
        $this->status = [];
        $this->readteacher();
    }

    public function startfindteacher($like) {
        $this->teacher_id = [];
        $this->lname = [];
        $this->fname = [];
        $this->mname = [];
        $this->birthdate = [];
        $this->age = [];
        $this->sex = [];
        $this->address = [];
        $this->contact = [];
        $this->email = [];
        $this->code = [];
        $this->pass = [];
        $this->date_added = [];
        $this->status = [];
        $this->findteacher($like);
    }

    public function startupdateteacher() {
        $status = true;
        if ($this->teacher_id == null) $status = false;
        else if ($this->lname == null) $status = false;
        else if ($this->fname == null) $status = false;
        else if ($this->mname == null) $status = false;
        else if ($this->birthdate == null) $status = false;
        else if ($this->age == null) $status = false;
        else if ($this->sex == null) $status = false;
        else if ($this->address == null) $status = false;
        else if ($this->contact == null) $status = false;
        else if ($this->email == null) $status = false;
        else if ($this->code == null) $status = false;
        else if ($this->pass == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updateteacher();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createteacher() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO teacher ( teacher_id,  lname, fname, mname, birthdate, age, sex, address, contact, email, code, pass, date_added, status) VALUES ( null, :lname, :fname, :mname,  :birthdate, :age, :sex, :address, :contact, :email, :code, :pass, :date_added, :status)");

            $stmt->execute(array(
                "lname" => $this->lname, 
                "fname" => $this->fname,
                "mname" => $this->mname, 
                "birthdate" => $this->birthdate,
                "age" => $this->age,
                "sex" => $this->sex,
                "address" => $this->address,
                "contact" => $this->contact,
                "email" => $this->email,
                "code" => $this->code,
                "pass" => $this->pass,
                "date_added" => $this->date_added,
                "status" => $this->status
                ));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readteacher() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM teacher") as $row) {
                array_push($this->teacher_id,$row["teacher_id"]);
                array_push($this->lname,$row["lname"]);
                array_push($this->fname,$row["fname"]);
                array_push($this->mname,$row["mname"]);
                array_push($this->birthdate,$row["birthdate"]);
                array_push($this->age,$row["age"]);
                array_push($this->sex,$row["sex"]);
                array_push($this->address,$row["address"]);
                array_push($this->contact,$row["contact"]);
                array_push($this->email,$row["email"]);
                array_push($this->code,$row["code"]);
                array_push($this->pass,$row["pass"]);
                array_push($this->date_added,$row["date_added"]);
                array_push($this->status,$row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function findteacher($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM teacher WHERE  teacher_id LIKE '%" . $like . "%'  OR  lname LIKE '%" . $like . "%'   OR  fname LIKE '%" . $like . "%'   OR  mname LIKE '%" . $like . "%'  OR  birthdate LIKE '%" . $like . "%'
                OR  age LIKE '%" . $like . "%' 
                OR  sex LIKE '%" . $like . "%'
                OR  address LIKE '%" . $like . "%'
                OR  contact LIKE '%" . $like . "%'
                OR  email LIKE '%" . $like . "%'
                OR  code LIKE '%" . $like . "%'
                OR  pass LIKE '%" . $like . "%'
                OR  date_added LIKE '%" . $like . "%'
                OR  status LIKE '%" . $like . "%'
                 ") as $row) {
                array_push($this->teacher_id,$row["teacher_id"]);
                array_push($this->lname,$row["lname"]);
                array_push($this->fname,$row["fname"]);
                array_push($this->mname,$row["mname"]);
                array_push($this->birthdate,$row["birthdate"]);
                array_push($this->age,$row["age"]);
                array_push($this->sex,$row["sex"]);
                array_push($this->address,$row["address"]);
                array_push($this->contact,$row["contact"]);
                array_push($this->email,$row["email"]);
                array_push($this->code,$row["code"]);
                array_push($this->pass,$row["pass"]);
                array_push($this->date_added,$row["date_added"]);
                array_push($this->status,$row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function updateteacher() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE teacher SET 
                lname = :lname, 
                fname = :fname,
                mname = :mname, 
                birthdate = :birthdate, 
                age = :age, 
                sex = :sex, 
                address = :address, 
                contact = :contact, 
                email = :email, 
                code = :code, 
                pass = :pass, 
                date_added = :date_added, 
                status = :status
                WHERE teacher_id = :teacher_id");

            $stmt->execute(array("teacher_id" => $this->teacher_id, "lname" => $this->lname,"fname" => $this->fname, "mname" => $this->mname, "birthdate" => $this->birthdate, "age" => $this->age, "sex" => $this->sex,
                "address" => $this->address, "contact" => $this->contact, "email" => $this->email, 
                "code" => $this->code, "pass" => $this->pass, "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
 }

   class Learn {
    private $db, $learn_id, $learn, $description, $remarks, $date_added, $status;
    
    public function get_learn_credential($type) {
        $learn_credential;
        switch($type) {
            case "learn_id";
                $learn_credential = [$type => $this->learn_id];
            break;
            case "learn";
                $learn_credential = [$type => $this->learn];
            break;
            case "description";
                $learn_credential = [$type => $this->description];
            break;
            case "remarks";
                $learn_credential = [$type => $this->remarks];
            break;
            case "date_added";
                $learn_credential = [$type => $this->date_added];
            break;
            case "status";
                $learn_credential = [$type => $this->status];
            break;
            case "all";
                $learn_credential = ["learn_id" => $this->learn_id, "learn" => $this->learn, "description" => $this->description, "remarks" => $this->remarks, "date_added" => $this->date_added, "status" => $this->status];
            break;
            default:
                $learn_credential = null;
        }
        return $learn_credential;
    }

    public function set_learn_credential($type,$value) {
        switch($type) {
            case "learn_id";
                $this->learn_id = $value;
            break;
            case "learn";
                $this->learn = $value;
            break;
            case "description";
                $this->description = $value;
            break;
            case "remarks";
                $this->remarks = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->learn_id = $value["learn_id"];
                $this->learn = $value["learn"];
                $this->description = $value["description"];
                $this->remarks = $value["remarks"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreatelearn() {
        $status = true;
        if ($this->learn == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createlearn();
        return $status;
    }

    public function startreadlearn() {
        $this->learn_id = [];
        $this->learn = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->readlearn();
    }
    public function startfindlearn($like) {
        $this->learn_id = [];
        $this->learn = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->findlearn($like);
    }

    public function startupdatelearn() {
        $status = true;
        if ($this->learn_id == null) $status = false;
        else if ($this->learn == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updatelearn();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createlearn() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO learn ( learn_id,  learn, description, remarks,  date_added, status) VALUES ( null,  :learn, :description, :remarks,  :date_added, :status)");
            $stmt->execute(array("learn" => $this->learn, "description" => $this->description,  "remarks" => $this->remarks,  
                "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readlearn() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM learn") as $row) {
                array_push($this->learn_id, $row["learn_id"]);
                array_push($this->learn, $row["learn"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function findlearn($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM learn WHERE  learn_id LIKE '%" . $like . "%'  
                OR  learn LIKE '%" . $like . "%'
                OR  description LIKE '%" . $like . "%'  
                OR  remarks LIKE '%" . $like . "%'    
                OR  date_added LIKE '%" . $like . "%' 
                OR  status LIKE '%" . $like . "%'") as $row) {
                array_push($this->learn_id, $row["learn_id"]);
                array_push($this->learn, $row["learn"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
    
    protected function updatelearn() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE learn SET 
                learn = :learn, 
                description = :description, 
                remarks = :remarks,  
                date_added = :date_added, 
                status = :status 
                WHERE learn_id = :learn_id");
            $stmt->execute(array("learn_id" => $this->learn_id, 
                "learn" => $this->learn, 
                "description" => $this->description, 
                "remarks" => $this->remarks, 
                "date_added" => $this->date_added, 
                "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
}

 class Module {
    private $db, $module_id, $module, $description, $remarks, $date_added, $status;
    
    public function get_module_credential($type) {
        $module_credential;
        switch($type) {
            case "module_id";
                $module_credential = [$type => $this->module_id];
            break;
            case "module";
                $module_credential = [$type => $this->module];
            break;
            case "description";
                $module_credential = [$type => $this->description];
            break;
            case "remarks";
                $module_credential = [$type => $this->remarks];
            break;
            case "date_added";
                $module_credential = [$type => $this->date_added];
            break;
            case "status";
                $module_credential = [$type => $this->status];
            break;
            case "all";
                $module_credential = ["module_id" => $this->module_id, "module" => $this->module, "description" => $this->description, "remarks" => $this->remarks, "date_added" => $this->date_added, "status" => $this->status];
            break;
            default:
                $module_credential = null;
        }
        return $module_credential;
    }

    public function set_module_credential($type,$value) {
        switch($type) {
            case "module_id";
                $this->module_id = $value;
            break;
            case "module";
                $this->module = $value;
            break;
            case "description";
                $this->description = $value;
            break;
            case "remarks";
                $this->remarks = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->module_id = $value["module_id"];
                $this->module = $value["module"];
                $this->description = $value["description"];
                $this->remarks = $value["remarks"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreatemodule() {
        $status = true;
        if ($this->module == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createmodule();
        return $status;
    }

    public function startreadmodule() {
        $this->module_id = [];
        $this->module = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->readmodule();
    }
    public function startfindmodule($like) {
        $this->module_id = [];
        $this->module = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->findmodule($like);
    }

    public function startupdatemodule() {
        $status = true;
        if ($this->module_id == null) $status = false;
        else if ($this->module == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updatemodule();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createmodule() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO module ( module_id,  module, description, remarks,  date_added, status) VALUES ( null,  :module, :description, :remarks,  :date_added, :status)");
            $stmt->execute(array("module" => $this->module, "description" => $this->description,  "remarks" => $this->remarks,  
                "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readmodule() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM module") as $row) {
                array_push($this->module_id, $row["module_id"]);
                array_push($this->module, $row["module"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function findmodule($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM module WHERE  module_id LIKE '%" . $like . "%'  
                OR  module LIKE '%" . $like . "%'
                OR  description LIKE '%" . $like . "%'  
                OR  remarks LIKE '%" . $like . "%'    
                OR  date_added LIKE '%" . $like . "%' 
                OR  status LIKE '%" . $like . "%'") as $row) {
                array_push($this->module_id, $row["module_id"]);
                array_push($this->module, $row["module"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
    
    protected function updatemodule() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE module SET 
                module = :module, 
                description = :description, 
                remarks = :remarks,  
                date_added = :date_added, 
                status = :status 
                WHERE module_id = :module_id");
            $stmt->execute(array("module_id" => $this->module_id, 
                "module" => $this->module, 
                "description" => $this->description, 
                "remarks" => $this->remarks, 
                "date_added" => $this->date_added, 
                "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
}

  class Format {
    private $db, $format_id, $format, $description, $remarks, $date_added, $status;
    
    public function get_format_credential($type) {
        $format_credential;
        switch($type) {
            case "format_id";
                $format_credential = [$type => $this->format_id];
            break;
            case "format";
                $format_credential = [$type => $this->format];
            break;
            case "description";
                $format_credential = [$type => $this->description];
            break;
            case "remarks";
                $format_credential = [$type => $this->remarks];
            break;
            case "date_added";
                $format_credential = [$type => $this->date_added];
            break;
            case "status";
                $format_credential = [$type => $this->status];
            break;
            case "all";
                $format_credential = ["format_id" => $this->format_id, "format" => $this->format, "description" => $this->description, "remarks" => $this->remarks, "date_added" => $this->date_added, "status" => $this->status];
            break;
            default:
                $format_credential = null;
        }
        return $format_credential;
    }

    public function set_format_credential($type,$value) {
        switch($type) {
            case "format_id";
                $this->format_id = $value;
            break;
            case "format";
                $this->format = $value;
            break;
            case "description";
                $this->description = $value;
            break;
            case "remarks";
                $this->remarks = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->format_id = $value["format_id"];
                $this->format = $value["format"];
                $this->description = $value["description"];
                $this->remarks = $value["remarks"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreateformat() {
        $status = true;
        if ($this->format == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createformat();
        return $status;
    }

    public function startreadformat() {
        $this->format_id = [];
        $this->format = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->readformat();
    }
    public function startfindformat($like) {
        $this->format_id = [];
        $this->format = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->findformat($like);
    }

    public function startupdateformat() {
        $status = true;
        if ($this->format_id == null) $status = false;
        else if ($this->format == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updateformat();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createformat() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO format ( format_id,  format, description, remarks,  date_added, status) VALUES ( null,  :format, :description, :remarks,  :date_added, :status)");
            $stmt->execute(array("format" => $this->format, "description" => $this->description,  "remarks" => $this->remarks,  
                "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readformat() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM format") as $row) {
                array_push($this->format_id, $row["format_id"]);
                array_push($this->format, $row["format"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessdate_added();
        }
    }

    protected function findformat($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM format WHERE  format_id LIKE '%" . $like . "%'  
                OR  format LIKE '%" . $like . "%'
                OR  description LIKE '%" . $like . "%'  
                OR  remarks LIKE '%" . $like . "%'    
                OR  date_added LIKE '%" . $like . "%' 
                OR  status LIKE '%" . $like . "%'") as $row) {
                array_push($this->format_id, $row["format_id"]);
                array_push($this->format, $row["format"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
    
    protected function updateformat() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE format SET 
                format = :format, 
                description = :description, 
                remarks = :remarks,  
                date_added = :date_added, 
                status = :status 
                WHERE format_id = :format_id");
            $stmt->execute(array("format_id" => $this->format_id, 
                "format" => $this->format, 
                "description" => $this->description, 
                "remarks" => $this->remarks, 
                "date_added" => $this->date_added, 
                "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
}

 class Topic {
    private $db, $topic_id, $topic, $description, $remarks, $date_added, $status;
    
    public function get_topic_credential($type) {
        $topic_credential;
        switch($type) {
            case "topic_id";
                $topic_credential = [$type => $this->topic_id];
            break;
            case "topic";
                $topic_credential = [$type => $this->topic];
            break;
            case "description";
                $topic_credential = [$type => $this->description];
            break;
            case "remarks";
                $topic_credential = [$type => $this->remarks];
            break;
            case "date_added";
                $topic_credential = [$type => $this->date_added];
            break;
            case "status";
                $topic_credential = [$type => $this->status];
            break;
            case "all";
                $topic_credential = ["topic_id" => $this->topic_id, "topic" => $this->topic, "description" => $this->description, "remarks" => $this->remarks, "date_added" => $this->date_added, "status" => $this->status];
            break;
            default:
                $topic_credential = null;
        }
        return $topic_credential;
    }

    public function set_topic_credential($type,$value) {
        switch($type) {
            case "topic_id";
                $this->topic_id = $value;
            break;
            case "topic";
                $this->topic = $value;
            break;
            case "description";
                $this->description = $value;
            break;
            case "remarks";
                $this->remarks = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->topic_id = $value["topic_id"];
                $this->topic = $value["topic"];
                $this->description = $value["description"];
                $this->remarks = $value["remarks"];
                $this->date_added = $value["date_added"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreatetopic() {
        $status = true;
        if ($this->topic == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createtopic();
        return $status;
    }

    public function startreadtopic() {
        $this->topic_id = [];
        $this->topic = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->readtopic();
    }
    public function startfindtopic($like) {
        $this->topic_id = [];
        $this->topic = [];
        $this->description = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->status = [];
        $this->findtopic($like);
    }

    public function startupdatetopic() {
        $status = true;
        if ($this->topic_id == null) $status = false;
        else if ($this->topic == null) $status = false;
        else if ($this->description == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->date_added == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updatetopic();
        return $status;
    }

    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createtopic() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO topic ( topic_id,  topic, description, remarks,  date_added, status) VALUES ( null,  :topic, :description, :remarks,  :date_added, :status)");
            $stmt->execute(array("topic" => $this->topic, "description" => $this->description,  "remarks" => $this->remarks,  
                "date_added" => $this->date_added, "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readtopic() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM topic") as $row) {
                array_push($this->topic_id, $row["topic_id"]);
                array_push($this->topic, $row["topic"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function findtopic($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM topic WHERE  topic_id LIKE '%" . $like . "%'  
                OR  topic LIKE '%" . $like . "%'
                OR  description LIKE '%" . $like . "%'  
                OR  remarks LIKE '%" . $like . "%'    
                OR  date_added LIKE '%" . $like . "%' 
                OR  status LIKE '%" . $like . "%'") as $row) {
                array_push($this->topic_id, $row["topic_id"]);
                array_push($this->topic, $row["topic"]);
                array_push($this->description, $row["description"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
    
    protected function updatetopic() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE topic SET 
                topic = :topic, 
                description = :description, 
                remarks = :remarks,  
                date_added = :date_added, 
                status = :status 
                WHERE topic_id = :topic_id");
            $stmt->execute(array("topic_id" => $this->topic_id, 
                "topic" => $this->topic, 
                "description" => $this->description, 
                "remarks" => $this->remarks, 
                "date_added" => $this->date_added, 
                "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
}

 class Course {
    private $db, $course_id, $coursecode_id, $areacode_id, $coursetitle_id, $unit_id, 
    $teacher_id, $remarks, $date_added, $approval, $status;
    
    public function get_course_credential($type) {
        $course_credential;
        switch($type) {
            case "course_id";
                $course_credential = [$type => $this->course_id];
            break;
            case "coursecode_id";
                $course_credential = [$type => $this->coursecode_id];
            break;
            case "areacode_id";
                $course_credential = [$type => $this->areacode_id];
            break;
            case "coursetitle_id";
                $course_credential = [$type => $this->coursetitle_id];
            break;
            case "unit_id";
                $course_credential = [$type => $this->unit_id];
            break;
            case "teacher_id";
                $course_credential = [$type => $this->teacher_id];
            break;
            case "remarks";
                $course_credential = [$type => $this->remarks];
            break;
            case "date_added";
                $course_credential = [$type => $this->date_added];
            break;
            case "approval";
                $course_credential = [$type => $this->approval];
            break;
            case "status";
                $course_credential = [$type => $this->status];
            break;
            case "all";
                $course_credential = [
                    "course_id" => $this->course_id, 
                    "coursecode_id" => $this->coursecode_id, 
                    "areacode_id" => $this->areacode_id,
                    "coursetitle_id" => $this->coursetitle_id,
                    "unit_id" => $this->unit_id, 
                    "teacher_id" => $this->teacher_id, 
                    "remarks" => $this->remarks, 
                    "date_added" => $this->date_added,
                    "approval" => $this->approval,  
                    "status" => $this->status];
            break;
            default:
                $course_credential = null;
        }
        return $course_credential;
    }

    public function set_course_credential($type,$value) {
        switch($type) {
            case "course_id";
                $this->course_id = $value;
            break;
            case "coursecode_id";
                $this->coursecode_id = $value;
            break;
            case "areacode_id";
                $this->areacode_id = $value;
            break;
            case "coursetitle_id";
                $this->coursetitle_id = $value;
            break;
            case "unit_id";
                $this->unit_id = $value;
            break;
            case "teacher_id";
                $this->teacher_id = $value;
            break;
            case "remarks";
                $this->remarks = $value;
            break;
            case "date_added";
                $this->date_added = $value;
            break;
            case "approval";
                $this->approval = $value;
            break;
            case "status";
                $this->status = $value;
            break;
            case "all";
                $this->course_id = $value["course_id"];
                $this->coursecode_id = $value["coursecode_id"];
                $this->areacode_id = $value["areacode_id"];
                $this->coursetitle_id = $value["coursetitle_id"];
                $this->unit_id = $value["unit_id"];
                $this->teacher_id = $value["teacher_id"];
                $this->remarks = $value["remarks"];
                $this->date_added = $value["date_added"];
                $this->approval = $value["approval"];
                $this->status = $value["status"];
            break;
        }
    }

    public function startcreatecourse() {
        $status = true;
        if ($this->coursecode_id == null) $status = false;
        else if ($this->areacode_id == null) $status = false;
        else if ($this->coursetitle_id == null) $status = false;
        else if ($this->unit_id == null) $status = false;
        else if ($this->teacher_id == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->approval == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->createcourse();
        return $status;
    }

    public function startreadcourse() {
        $this->course_id = [];
        $this->coursecode_id = [];
        $this->areacode_id = [];
        $this->coursetitle_id = [];
        $this->unit_id = [];
        $this->teacher_id = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->approval = [];
        $this->status = [];
        $this->readcourse();
    }
    public function startfindcourse($like) {
        $this->course_id = [];
        $this->coursecode_id = [];
        $this->areacode_id = [];
        $this->coursetitle_id = [];
        $this->unit_id = [];
        $this->teacher_id = [];
        $this->remarks = [];
        $this->date_added = [];
        $this->approval = [];
        $this->status = [];
        $this->findcourse($like);
    }

    public function startupdatecourse() {
        $status = true;
        if ($this->course_id == null) $status = false;
        else if ($this->coursecode_id == null) $status = false;
        else if ($this->areacode_id == null) $status = false;
        else if ($this->coursetitle_id == null) $status = false;
        else if ($this->unit_id == null) $status = false;
        else if ($this->teacher_id == null) $status = false;
        else if ($this->remarks == null) $status = false;
        else if ($this->approval == null) $status = false;
        else if ($this->status == null) $status = false;
        else $this->updatecourse();
        return $status;
    }

    public function startupdatecoursebystatus() {
        $status = true;
        $this->updatecoursebystatus();
        return $status;
    }


    public function __construct() {
        $this->db = new PDO("mysql:host=localhost;dbname=ogamc_db;charset=utf8mb4", "root","");
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    }

    protected function createcourse() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("INSERT INTO course (   
                course_id,
                coursecode_id, 
                areacode_id,
                coursetitle_id, 
                unit_id,
                teacher_id,  
                remarks,  
                date_added,
                approval,  
                status) VALUES ( null,   
                :coursecode_id, 
                :areacode_id,
                :coursetitle_id, 
                :unit_id,
                :teacher_id,   
                :remarks,  
                :date_added,
                :approval,   
                :status)");
            $stmt->execute(array(
                "coursecode_id" => $this->coursecode_id,  
                "areacode_id" => $this->areacode_id,
                "coursetitle_id" => $this->coursetitle_id,
                "unit_id" => $this->unit_id,
                "teacher_id" => $this->teacher_id,
                "remarks" => $this->remarks,  
                "date_added" => $this->date_added,
                "approval" => $this->approval, 
                "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

    protected function readcourse() {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT * FROM course") as $row) {
                array_push($this->course_id, $row["course_id"]);
                array_push($this->coursecode_id, $row["coursecode_id"]);
                array_push($this->areacode_id, $row["areacode_id"]);
                array_push($this->coursetitle_id, $row["coursetitle_id"]);
                array_push($this->unit_id, $row["unit_id"]);
                array_push($this->teacher_id, $row["teacher_id"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->approval, $row["approval"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

  protected function findcourse($like) {
        try {
            $this->db->beginTransaction();
            foreach($this->db->query("SELECT
             cs.course_id,
             cs.coursecode_id,
             cs.areacode_id,
             cs.coursetitle_id,
             cs.unit_id,
             cs.teacher_id,
             cs.remarks,
             cs.date_added,
             cs.approval,
             cs.status
             FROM course cs 
                join coursecode cd on cd.coursecode_id = cs.coursecode_id 
                join areacode ad on ad.areacode_id = cs.areacode_id 
                join coursetitle ct on ct.coursetitle_id = cs.coursetitle_id
                join unit u on u.unit_id = cs.unit_id
                join teacher t on t.teacher_id = cs.teacher_id
                WHERE  
                cs.course_id LIKE '%" . $like . "%'  
                OR  cd.coursecode LIKE '%" . $like . "%'  
                OR  ad.areacode LIKE '%" . $like . "%' 
                OR  ct.coursetitle LIKE '%" . $like . "%'
                OR  u.unit LIKE '%" . $like . "%'
                OR  t.lname LIKE '%" . $like . "%'
                OR  t.fname LIKE '%" . $like . "%'
                OR  t.mname LIKE '%" . $like . "%'
                OR  cs.remarks LIKE '%" . $like . "%' 
                OR  cs.date_added LIKE '%" . $like . "%' 
                OR  cs.approval LIKE '%" . $like . "%'
                OR  cs.status LIKE '%" . $like . "%'     
                 ") as $row) {
                array_push($this->course_id, $row["course_id"]);
                array_push($this->coursecode_id, $row["coursecode_id"]);
                array_push($this->areacode_id, $row["areacode_id"]);
                array_push($this->coursetitle_id, $row["coursetitle_id"]);
                array_push($this->unit_id, $row["unit_id"]);
                array_push($this->teacher_id, $row["teacher_id"]);
                array_push($this->remarks, $row["remarks"]);
                array_push($this->date_added, $row["date_added"]);
                array_push($this->approval, $row["approval"]);
                array_push($this->status, $row["status"]);
            }
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }

     protected function updatecoursebystatus() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE course SET 
                coursecode_id = :coursecode_id, 
                teacher_id = :teacher_id,  
                approval = :approval, 
                status = :status 
                WHERE course_id = :course_id");
            $stmt->execute(array("course_id" => $this->course_id, 
                "coursecode_id" => $this->coursecode_id, 
                "teacher_id" => $this->teacher_id,  
                "approval" => $this->approval, 
                "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
    
    protected function updatecourse() {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("UPDATE course SET 
                coursecode_id = :coursecode_id, 
                areacode_id = :areacode_id, coursetitle_id = :coursetitle_id, 
                unit_id = :unit_id, teacher_id = :teacher_id,  
                remarks = :remarks, date_added = :date_added, approval = :approval, 
                status = :status 
                WHERE course_id = :course_id");
            $stmt->execute(array("course_id" => $this->course_id, 
                "coursecode_id" => $this->coursecode_id, 
                "areacode_id" => $this->areacode_id,
                "coursetitle_id" => $this->coursetitle_id,
                "unit_id" => $this->unit_id,
                "teacher_id" => $this->teacher_id,  
                "remarks" => $this->remarks, 
                "date_added" => $this->date_added,
                "approval" => $this->approval, 
                "status" => $this->status));
            $affected_rows = $stmt->rowCount();
            $this->db->commit();
        }
        catch (PDOException $ex) {
            $this->db->rollBack();
            echo $ex->getMessage();
        }
    }
}



$main = new Main();
$main->main_program();

?>