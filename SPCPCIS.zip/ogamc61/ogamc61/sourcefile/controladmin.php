<?php 
    include '../sourcefile/functions.php';
?>
<?php 
	include 'themepart/mylinkcss.php';
?>
<?php 
	include 'themepart/admin.php';
?>
<?php 
	include 'themepart/top_menu.php';
?><br>
  <div class="content-wrapper">
    <form class="form-group">
        <div class="col-md-12">
            <div class="card bg-light text-dark"> 
    	<div class="card-body">
    		 <h4 class="card-title" style="font-size:20px;"> Administrator <i class="fa fa-user-secret" style="font-size:24px"></i></h4>
    		 <p class="card-text">Control everything here. Create, Find, Activate and Deactivate Administrator.</p>
    		 <button type="button" class="btn btn-success" data-toggle="modal"  data-target="#createadminmodal"><i class="far fa-plus-square"></i> Add New Admin </button>
    	</div>
        </div>
  	</div>
  </form>
  
<form class="form-control-lg">
  <div class="input-group mb-3">
    <div class="input-group-prepend">
      <button class="btn btn-primary"><i class="fa fa-search"></i></button>
    </div>
    <input type="text" id="controladminmaininput1" class="form-control form-control-lg" placeholder="Type anything you search.." style="font-size:14px;">
  </div>
</form><br>

  <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
            </div>
            <div class="card-body">
              <table id="datatableadmin2" class="table table-hover">
                <thead class="table-light">
                <tr>
                  <th># Admin ID</th>
                  <th>Lastname</th>
                  <th>Firstname</th>
                  <th>Middlename</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Admin ID</th>
                </tr>
                </thead>
                <tbody id="controladminmainoutput1">
                <?php
                $admin = new Admin();
                $admin->startreadadmin();
                $admin_all = $admin->get_admin_credential("all");

                if($admin_all !== null) {
                    for( $r=0; $r < count($admin_all["admin_id"]); $r++ ) {
                        ?>
                        <tr>
                            <th scope="row"><?php echo $admin_all["admin_id"][$r] ?></th>
                            <td><?php echo $admin_all["lname"][$r];?></td>
                            <td><?php echo $admin_all["fname"][$r];?></td>
                            <td><?php echo $admin_all["mname"][$r];?></td>
                            <td><?php echo $admin_all["contact"][$r]; ?></td>
                            <td><?php echo $admin_all["email"][$r]; ?></td>
                            <td>
                            <button class="btn btn-success admin-record-table-row" data-toggle="modal" data-target="#updateadminmodal" data-admindata ='{ 
                            "admin_id" : "<?php echo $admin_all["admin_id"][$r] ?>",
                            "lname" : "<?php echo $admin_all["lname"][$r] ?>",
                            "fname" : "<?php echo $admin_all["fname"][$r] ?>",
                            "mname" : "<?php echo $admin_all["mname"][$r] ?>",   
                            "age" : "<?php echo $admin_all["age"][$r] ?>",
                            "sex" : "<?php echo $admin_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $admin_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $admin_all["address"][$r] ?>", 
                            "contact" : "<?php echo $admin_all["contact"][$r] ?>",
                            "email" : "<?php echo $admin_all["email"][$r] ?>", 
                            "code" : "<?php echo $admin_all["code"][$r] ?>", 
                            "pass" : "<?php echo $admin_all["pass"][$r] ?>", 
                            "status" : "<?php echo $admin_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update</button>
                            </td>
                              <td>
                            <button class="btn btn-info admin-record-table-row-view" data-target="#admin1-<?php echo $admin_all["admin_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View </button>
                          </td>
                            <td>
                                <?php
                                    if ($admin_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
        <td>
        <?php echo $admin_all["admin_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="admin1-<?php echo $admin_all["admin_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-user-secret"></i> Admin View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Admin code is always unique.</small>
                    </div>
                     <table class="table" border="0">
                            <tr><th># Admin ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["admin_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                              <?php
                                    if ($admin_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
                        </tr>
                        <?php
                    }
                }
            ?> 
                </tbody id="controladminmainoutput1">
                <tfoot class="table">
                <tr>
                  <th># Admin ID</th>
                  <th>Lastname</th>
                  <th>Firstname</th>
                  <th>Middlename</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Admin ID</th>
                </tr>
                </tfoot>
              </table>
            </div>
          </div>

      <form class="form-control-lg">
        <div class="input-group mb-3">
          <div class="input-group-prepend">
            <button class="btn btn-primary"><i class="fa fa-search"></i></button>
            </div>
            <input type="text" id="controladminmaininput2" class="form-control form-control-lg" placeholder="Type anything you search.." style="font-size:14px;">
            </div>
          </form><br>

          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Administrator List <i class="fa fa-user-secret" style="font-size:25px"></i></h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="datatableadmin1" class="table">
                <thead class="table">
                <tr>
                  <th># Admin ID</th>
                  <th>Lastname</th>
                  <th>Firstname</th>
                  <th>Middlename</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Admin ID</th>
                </tr>
                </thead>
                <tbody id="controladminmainoutput2">
                 <?php
                $admin = new Admin();
                $admin->startreadadmin();
                $admin_all = $admin->get_admin_credential("all");

                if($admin_all !== null) {
                    for( $r=0; $r < count($admin_all["admin_id"]); $r++ ) {
                        ?>
                        <tr>
                            <th scope="row"><?php echo $admin_all["admin_id"][$r] ?></th>
                            <td><?php echo $admin_all["lname"][$r];?></td>
                            <td><?php echo $admin_all["fname"][$r];?></td>
                            <td><?php echo $admin_all["mname"][$r];?></td>
                            <td><?php echo $admin_all["contact"][$r]; ?></td>
                            <td><?php echo $admin_all["email"][$r]; ?></td>
                            <td>
                            <button class="btn btn-success admin-record-table-row" data-toggle="modal" data-target="#updateadminmodal" data-admindata ='{ 
                            "admin_id" : "<?php echo $admin_all["admin_id"][$r] ?>",
                            "lname" : "<?php echo $admin_all["lname"][$r] ?>",
                            "fname" : "<?php echo $admin_all["fname"][$r] ?>",
                            "mname" : "<?php echo $admin_all["mname"][$r] ?>",   
                            "age" : "<?php echo $admin_all["age"][$r] ?>",
                            "sex" : "<?php echo $admin_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $admin_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $admin_all["address"][$r] ?>", 
                            "contact" : "<?php echo $admin_all["contact"][$r] ?>",
                            "email" : "<?php echo $admin_all["email"][$r] ?>", 
                            "code" : "<?php echo $admin_all["code"][$r] ?>", 
                            "pass" : "<?php echo $admin_all["pass"][$r] ?>", 
                            "status" : "<?php echo $admin_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                            <button class="btn btn-info admin-record-table-row-view" data-toggle="modal" data-target="#admin2-<?php echo $admin_all["admin_id"][$r]; ?>">
                                      <i class="fas fa-eye"></i> View </button></td>
                            <td>
                                 <?php
                                    if ($admin_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
        <td>
        <?php echo $admin_all["admin_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="admin2-<?php echo $admin_all["admin_id"][$r];?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-user-secret"></i> Admin View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Admin code is always unique.</small>
                    </div>
                      <table class="table" style="border:none;">
                            <tr><th># Admin ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["admin_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                             <?php
                                    if ($admin_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
      </td>
                        </tr>
                        <?php
                    }
                }
            ?> 
                </tbody id="controladminmainoutput2">
                <tfoot class="table">
                <tr>
                  <th># Admin ID</th>
                  <th>Lastname</th>
                  <th>Firstname</th>
                  <th>Middlename</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Admin ID</th>
                </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
    <div class="modal_container">
    <div class="modal fade" id="createadminmodal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-user-secret"></i> Admin Create </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Admin code is always unique.</small>
                    </div>
                <div class="form-group">
                    <div class="row">
                       <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                       <label class="text-sm">Lastname</label>
                     <input type="text" class="form-control form-control-sm" id="createadminmodal_lname" placeholder="Enter Lastname">
                     </div>

                     <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Firstname</label>
                        <input type="text" class="form-control form-control-sm" id="createadminmodal_fname" placeholder="Enter Firstname">
                    </div>

                   <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Middlename</label>
                        <input type="text" class="form-control form-control-sm" id="createadminmodal_mname" placeholder="Enter Middlename">
                    </div>
                  </div>
                </div>

            <div class="form-group">
                <div class="row">
                <div class="col-md-6">
                        <i class="fa fa-calendar"></i>
                        <label class="text-sm">Birthdate</label>
                        <input type="date" class="form-control form-control-sm" id="createadminmodal_birthdate" placeholder="Enter Birthdate">
                    </div>
                    <div class="col-md-3">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Age</label>
                        <input type="text" class="form-control form-control-sm" id="createadminmodal_age" placeholder="Enter Age" maxlength="2">
                    </div>
                    <div class="col-md-3">
                          <i class="fa fa-intersex"></i>
                        <label class="text-sm"><i class="fa fa-venus-double"></i> Sex</label>
                        <select class="custom-select form-control-sm" id="createadminmodal_sex">
                            <option value="M">Male</option>
                            <option value="F">Female</option>
                        </select>
                    </div>
                </div>
            </div>
                    <div class="form-group">
                         <i class="fa fa-address-card"></i>
                            <label class="text-sm">Address</label>
                        <textarea type="text" class="form-control form-control-sm" id="createadminmodal_address" 
                        placeholder="Enter Address"></textarea>
                    </div>
            <div class="form-group">
                 <div class="row">
                    <div class="col-md-4">
                            <i class="fa fa-phone-square"></i>
                            <label class="text-sm">Contact</label>
                        <input type="text" class="form-control form-control-sm" maxlength="11" id="createadminmodal_contact" placeholder="Enter Contact">
                    </div>

                    <div class="col-md-5">
                            <i class="fa fa-envelope-square"></i>
                            <label class="text-sm">Email</label>
                        <input type="text" class="form-control form-control-sm" id="createadminmodal_email" placeholder="Enter Email">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-md-6">
                      <i class="fa fa-id-card"></i>
                        <label class="text-sm">Username</label>
                        <input type="text" class="form-control form-control-sm" id="createadminmodal_code" placeholder="Enter Code">
                    </div>

                    <div class="col-md-6">
                        <i class="fa fa-eye-slash"></i>
                        <label class="text-sm">Password</label>
                        <input type="text" class="form-control form-control-sm" id="createadminmodal_pass" placeholder="Password">
                    </div>
                </div>
            </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-success" id="createadminmodalbutton">
                    <i class="fa fa-save"></i> Save Changes </button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="updateadminmodal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-user-secret"></i> Admin Update </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Admin code is always unique.</small>
                        <input type="hidden" id="updateadminmodal_admin_id">
                    </div>
                <div class="form-group">
                    <div class="row">
                       <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                       <label class="text-sm">Lastname</label>
                     <input type="text" class="form-control form-control-sm" id="updateadminmodal_lname" placeholder="Enter Lastname">
                     </div>

                     <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Firstname</label>
                        <input type="text" class="form-control form-control-sm" id="updateadminmodal_fname" placeholder="Enter Firstname">
                    </div>

                   <div class="col-md-4">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Middlename</label>
                        <input type="text" class="form-control form-control-sm" id="updateadminmodal_mname" placeholder="Enter Middlename">
                    </div>
                  </div>
                </div>

            <div class="form-group">
                <div class="row">
                <div class="col-md-6">
                        <i class="fa fa-calendar"></i>
                        <label class="text-sm">Birthdate</label>
                        <input type="date" class="form-control form-control-sm" id="updateadminmodal_birthdate" placeholder="Enter Birthday">
                    </div>
                    <div class="col-md-3">
                        <i class="fas fa-pen-alt"></i>
                        <label class="text-sm">Age</label>
                        <input type="text" class="form-control form-control-sm" id="updateadminmodal_age" placeholder="Enter Age" maxlength="2">
                    </div>
                    <div class="col-md-3">
                          <i class="fa fa-intersex"></i>
                        <label class="text-sm"><i class="fa fa-venus-double"></i>Sex</label>
                        <select class="custom-select form-control-sm" id="updateadminmodal_sex">
                            <option value="M">Male</option>
                            <option value="F">Female</option>
                        </select>
                    </div>
                </div>
            </div>
                    <div class="form-group">
                         <i class="fa fa-address-card"></i>
                            <label class="text-sm">Address</label>
                        <textarea type="text" class="form-control form-control-sm" id="updateadminmodal_address" 
                        placeholder="Enter Address"></textarea>
                    </div>
            <div class="form-group">
                 <div class="row">
                    <div class="col-md-4">
                            <i class="fa fa-phone-square"></i>
                            <label class="text-sm">Contact</label>
                        <input type="text" class="form-control form-control-sm" id="updateadminmodal_contact" placeholder="Enter Contact" maxlength="11">
                    </div>

                    <div class="col-md-5">
                            <i class="fa fa-envelope-square"></i>
                            <label class="text-sm">Email</label>
                        <input type="text" class="form-control form-control-sm" id="updateadminmodal_email" placeholder="Enter Email">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-md-6">
                      <i class="fa fa-id-card"></i>
                        <label class="text-sm">Username</label>
                        <input type="text" class="form-control form-control-sm" id="updateadminmodal_code" placeholder="Enter Code">
                    </div>

                    <div class="col-md-6">
                        <i class="fa fa-eye-slash"></i>
                        <label class="text-sm">Password</label>
                        <input type="text" class="form-control form-control-sm" id="updateadminmodal_pass" placeholder="Password">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-md-3">
                        <i class="fa fa-star-half-o"></i>
                        <label class="text-sm"><i class="fa fa-check-circle"></i> Status</label>
                        <select class="custom-select form-control-sm" id="updateadminmodal_status">
                            <option value="1">Activated</option>
                            <option value="0">Deactivated</option>
                        </select>
                    </div>
                </div>
            </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-success" id="updateadminmodalbutton">
                    <i class="fa fa-save"></i> Save Changes </button>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
  </div>
<?php 
	include 'themepart/bottom.php';
?>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function() {
    $("#datatableadmin1").DataTable();
    $('#datatableadmin2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

</body>
</html>


