 <?php
    include '../sourcefile/functions.php';
    date_default_timezone_set('Asia/Singapore');
    $date = date('m/d/Y', time());
    $admin = new Admin();
    $hrstaff = new HrStaff();
    $recruitment = new Recruitment();
    $coordinator = new Coordinator();
    $company = new Company();
    $coursecode = new Coursecode();
    $areacode = new Areacode();
    $coursetitle = new Coursetitle();
    $unit = new Unit();
    $teacher = new Teacher();
    $learn = new Learn();
    $module = new Module();
    $format = new Format();
    $topic = new Topic();
    $course= new Course();

    switch($_POST["type_r"]){
        
      case "admin_create":
            $admin->set_admin_credential("lname",$_POST["lname"]);
            $admin->set_admin_credential("fname",$_POST["fname"]);
            $admin->set_admin_credential("mname",$_POST["mname"]);
            $admin->set_admin_credential("birthdate",$_POST["birthdate"]);
            $admin->set_admin_credential("age",$_POST["age"]);
            $admin->set_admin_credential("sex",$_POST["sex"]);
            $admin->set_admin_credential("address",$_POST["address"]);
            $admin->set_admin_credential("contact",$_POST["contact"]);
            $admin->set_admin_credential("email",$_POST["email"]);
            $admin->set_admin_credential("code",$_POST["code"]);
            $admin->set_admin_credential("pass",$_POST["pass"]);
            $admin->set_admin_credential("date_added",$date);
            $admin->set_admin_credential("status",$_POST["status"]);
            
            if($admin->startcreateadmin()) echo "Successfully added a new  Admin";
            else echo "Hey! something went wrong.";
        break;

        case "admin_update": 
            $admin->set_admin_credential("admin_id",$_POST["admin_id"]);
            $admin->set_admin_credential("lname",$_POST["lname"]);
            $admin->set_admin_credential("fname",$_POST["fname"]);
            $admin->set_admin_credential("mname",$_POST["mname"]);
            $admin->set_admin_credential("birthdate",$_POST["birthdate"]);
            $admin->set_admin_credential("age",$_POST["age"]);
            $admin->set_admin_credential("sex",$_POST["sex"]);
            $admin->set_admin_credential("address",$_POST["address"]);
            $admin->set_admin_credential("contact",$_POST["contact"]);
            $admin->set_admin_credential("email",$_POST["email"]);
            $admin->set_admin_credential("code",$_POST["code"]);
            $admin->set_admin_credential("pass",$_POST["pass"]);
            $admin->set_admin_credential("date_added",$date);
            $admin->set_admin_credential("status",$_POST["status"]);
            
            if($admin->startupdateadmin()) echo "Successfully updated the Admin ".$_POST["admin_id"];
            else echo "Hey! something went wrong.";
        break;

         case "admin_find1": 
            ob_start();
            if($_POST["key"]!=""){
            $admin = new Admin();
            $admin->startfindadmin($_POST["key"]);
            $admin_all = $admin->get_admin_credential("all");

            if($admin_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($admin_all["admin_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $admin_all["admin_id"][$r] ?></th>
                        <td><?php echo $admin_all["lname"][$r];?></td>
                        <td><?php echo $admin_all["fname"][$r];?></td>
                        <td><?php echo $admin_all["mname"][$r];?></td>
                        <td><?php echo $admin_all["contact"][$r]; ?></td>
                        <td><?php echo $admin_all["email"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success admin-record-table-row" data-toggle="modal" data-target="#updateadminmodal" data-admindata ='{ 
                            "admin_id" : "<?php echo $admin_all["admin_id"][$r] ?>",
                            "lname" : "<?php echo $admin_all["lname"][$r] ?>",
                            "fname" : "<?php echo $admin_all["fname"][$r] ?>",
                            "mname" : "<?php echo $admin_all["mname"][$r] ?>",   
                            "age" : "<?php echo $admin_all["age"][$r] ?>",
                            "sex" : "<?php echo $admin_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $admin_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $admin_all["address"][$r] ?>", 
                            "contact" : "<?php echo $admin_all["contact"][$r] ?>",
                            "email" : "<?php echo $admin_all["email"][$r] ?>", 
                            "code" : "<?php echo $admin_all["code"][$r] ?>", 
                            "pass" : "<?php echo $admin_all["pass"][$r] ?>", 
                            "status" : "<?php echo $admin_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                            <button class="btn btn-info admin-record-table-row-view" data-target="#admin1-<?php echo $admin_all["admin_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View </button>
                            </td>
                            <td>
                               <?php
                                    if ($admin_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                                <td>
        <?php echo $admin_all["admin_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="admin1-<?php echo $admin_all["admin_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-user-secret"></i> Admin View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Admin code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Admin ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["admin_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                              <?php
                                    if ($admin_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                    </td>
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{
            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';}
            echo ob_get_clean();
        break;

        case "admin_find2":
          ob_start();
             if($_POST["key"]!=""){
            $admin = new Admin();
            $admin->startfindadmin($_POST["key"]);
            $admin_all = $admin->get_admin_credential("all");

            if($admin_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($admin_all["admin_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $admin_all["admin_id"][$r] ?></th>
                        <td><?php echo $admin_all["lname"][$r];?></td>
                        <td><?php echo $admin_all["fname"][$r];?></td>
                        <td><?php echo $admin_all["mname"][$r];?></td>
                        <td><?php echo $admin_all["contact"][$r]; ?></td>
                        <td><?php echo $admin_all["email"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success admin-record-table-row" data-toggle="modal" data-target="#updateadminmodal" data-admindata ='{ 
                            "admin_id" : "<?php echo $admin_all["admin_id"][$r] ?>",
                            "lname" : "<?php echo $admin_all["lname"][$r] ?>",
                            "fname" : "<?php echo $admin_all["fname"][$r] ?>",
                            "mname" : "<?php echo $admin_all["mname"][$r] ?>",   
                            "age" : "<?php echo $admin_all["age"][$r] ?>",
                            "sex" : "<?php echo $admin_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $admin_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $admin_all["address"][$r] ?>", 
                            "contact" : "<?php echo $admin_all["contact"][$r] ?>",
                            "email" : "<?php echo $admin_all["email"][$r] ?>", 
                            "code" : "<?php echo $admin_all["code"][$r] ?>", 
                            "pass" : "<?php echo $admin_all["pass"][$r] ?>", 
                            "status" : "<?php echo $admin_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                            <button class="btn btn-info admin-record-table-row-view" data-target="#admin2-<?php echo $admin_all["admin_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View </button>
                            </td>
                            <td>
                               <?php
                                    if ($admin_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                                <td>
        <?php echo $admin_all["admin_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="admin2-<?php echo $admin_all["admin_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-user-secret"></i> Admin View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Admin code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Admin ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["admin_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                             <?php
                                    if ($admin_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $admin_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $admin_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                    </td>
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{
            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';}
            echo ob_get_clean();
        break;

        case "hrstaff_create":
            $hrstaff->set_hrstaff_credential("lname",$_POST["lname"]);
            $hrstaff->set_hrstaff_credential("fname",$_POST["fname"]);
            $hrstaff->set_hrstaff_credential("mname",$_POST["mname"]);
            $hrstaff->set_hrstaff_credential("birthdate",$_POST["birthdate"]);
            $hrstaff->set_hrstaff_credential("age",$_POST["age"]);
            $hrstaff->set_hrstaff_credential("sex",$_POST["sex"]);
            $hrstaff->set_hrstaff_credential("address",$_POST["address"]);
            $hrstaff->set_hrstaff_credential("contact",$_POST["contact"]);
            $hrstaff->set_hrstaff_credential("email",$_POST["email"]);
            $hrstaff->set_hrstaff_credential("code",$_POST["code"]);
            $hrstaff->set_hrstaff_credential("pass",$_POST["pass"]);
            $hrstaff->set_hrstaff_credential("date_added",$date);
            $hrstaff->set_hrstaff_credential("status",$_POST["status"]);
            
            if($hrstaff->startcreatehrstaff()) echo "Successfully added a new  Hr Staff";
            else echo "Hey! something went wrong.";
        break;

        case "hrstaff_update": 
            $hrstaff->set_hrstaff_credential("hrstaff_id",$_POST["hrstaff_id"]);
            $hrstaff->set_hrstaff_credential("lname",$_POST["lname"]);
            $hrstaff->set_hrstaff_credential("fname",$_POST["fname"]);
            $hrstaff->set_hrstaff_credential("mname",$_POST["mname"]);
            $hrstaff->set_hrstaff_credential("birthdate",$_POST["birthdate"]);
            $hrstaff->set_hrstaff_credential("age",$_POST["age"]);
            $hrstaff->set_hrstaff_credential("sex",$_POST["sex"]);
            $hrstaff->set_hrstaff_credential("address",$_POST["address"]);
            $hrstaff->set_hrstaff_credential("contact",$_POST["contact"]);
            $hrstaff->set_hrstaff_credential("email",$_POST["email"]);
            $hrstaff->set_hrstaff_credential("code",$_POST["code"]);
            $hrstaff->set_hrstaff_credential("pass",$_POST["pass"]);
            $hrstaff->set_hrstaff_credential("date_added",$date);
            $hrstaff->set_hrstaff_credential("status",$_POST["status"]);
            
            if($hrstaff->startupdatehrstaff()) echo "Successfully updated the Hr Staff ".$_POST["hrstaff_id"];
            else echo "Hey! something went wrong.";
        break;

         case "hrstaff_find1": 
            ob_start();
            if($_POST["key"]!=""){
            $hrstaff = new HrStaff();
            $hrstaff->startfindhrstaff($_POST["key"]);
            $hrstaff_all = $hrstaff->get_hrstaff_credential("all");

            if($hrstaff_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($hrstaff_all["hrstaff_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $hrstaff_all["hrstaff_id"][$r] ?></th>
                        <td><?php echo $hrstaff_all["lname"][$r];?></td>
                        <td><?php echo $hrstaff_all["fname"][$r];?></td>
                        <td><?php echo $hrstaff_all["mname"][$r];?></td>
                        <td><?php echo $hrstaff_all["contact"][$r]; ?></td>
                        <td><?php echo $hrstaff_all["email"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success hrstaff-record-table-row" data-toggle="modal" data-target="#updatehrstaffmodal" data-hrstaffdata ='{ 
                            "hrstaff_id" : "<?php echo $hrstaff_all["hrstaff_id"][$r] ?>",
                            "lname" : "<?php echo $hrstaff_all["lname"][$r] ?>",
                            "fname" : "<?php echo $hrstaff_all["fname"][$r] ?>",
                            "mname" : "<?php echo $hrstaff_all["mname"][$r] ?>",   
                            "age" : "<?php echo $hrstaff_all["age"][$r] ?>",
                            "sex" : "<?php echo $hrstaff_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $hrstaff_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $hrstaff_all["address"][$r] ?>", 
                            "contact" : "<?php echo $hrstaff_all["contact"][$r] ?>",
                            "email" : "<?php echo $hrstaff_all["email"][$r] ?>", 
                            "code" : "<?php echo $hrstaff_all["code"][$r] ?>", 
                            "pass" : "<?php echo $hrstaff_all["pass"][$r] ?>", 
                            "status" : "<?php echo $hrstaff_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                            <button class="btn btn-info hrstaff-record-table-row-view" data-target="#hrstaff1-<?php echo $hrstaff_all["hrstaff_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View </button>
                            </td>
                            <td>
                              <?php
                                    if ($hrstaff_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                                <td>
        <?php echo $hrstaff_all["hrstaff_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="hrstaff1-<?php echo $hrstaff_all["hrstaff_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-users"></i> Hr Staff View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: hr staff code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Hr Staff ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $hrstaff_all["hrstaff_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $hrstaff_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $hrstaff_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $hrstaff_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                            <?php
                                    if ($hrstaff_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $hrstaff_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                    </td>
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{
            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';}
            echo ob_get_clean();
        break;

        case "hrstaff_find2":
          ob_start();
             if($_POST["key"]!=""){
            $hrstaff = new hrstaff();
            $hrstaff->startfindhrstaff($_POST["key"]);
            $hrstaff_all = $hrstaff->get_hrstaff_credential("all");

            if($hrstaff_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($hrstaff_all["hrstaff_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $hrstaff_all["hrstaff_id"][$r] ?></th>
                        <td><?php echo $hrstaff_all["lname"][$r];?></td>
                        <td><?php echo $hrstaff_all["fname"][$r];?></td>
                        <td><?php echo $hrstaff_all["mname"][$r];?></td>
                        <td><?php echo $hrstaff_all["contact"][$r]; ?></td>
                        <td><?php echo $hrstaff_all["email"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success hrstaff-record-table-row" data-toggle="modal" data-target="#updatehrstaffmodal" data-hrstaffdata ='{ 
                            "hrstaff_id" : "<?php echo $hrstaff_all["hrstaff_id"][$r] ?>",
                            "lname" : "<?php echo $hrstaff_all["lname"][$r] ?>",
                            "fname" : "<?php echo $hrstaff_all["fname"][$r] ?>",
                            "mname" : "<?php echo $hrstaff_all["mname"][$r] ?>",   
                            "age" : "<?php echo $hrstaff_all["age"][$r] ?>",
                            "sex" : "<?php echo $hrstaff_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $hrstaff_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $hrstaff_all["address"][$r] ?>", 
                            "contact" : "<?php echo $hrstaff_all["contact"][$r] ?>",
                            "email" : "<?php echo $hrstaff_all["email"][$r] ?>", 
                            "code" : "<?php echo $hrstaff_all["code"][$r] ?>", 
                            "pass" : "<?php echo $hrstaff_all["pass"][$r] ?>", 
                            "status" : "<?php echo $hrstaff_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                            <button class="btn btn-info hrstaff-record-table-row-view" data-target="#hrstaff2-<?php echo $hrstaff_all["hrstaff_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View  </button>
                            </td>
                            <td>
                              <?php
                                    if ($hrstaff_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                                <td>
        <?php echo $hrstaff_all["hrstaff_id"][$r];?>
    <div class="modal fade" tabindex="-1" id="hrstaff2-<?php echo $hrstaff_all["hrstaff_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-users"></i> Hr Staff View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: hr staff code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Hr Staff ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $hrstaff_all["hrstaff_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $hrstaff_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $hrstaff_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $hrstaff_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                              <?php
                                    if ($hrstaff_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $hrstaff_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $hrstaff_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                    </td>
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{
            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';}
            echo ob_get_clean();
        break;

         case "recruitment_create":
            $recruitment->set_recruitment_credential("lname",$_POST["lname"]);
            $recruitment->set_recruitment_credential("fname",$_POST["fname"]);
            $recruitment->set_recruitment_credential("mname",$_POST["mname"]);
            $recruitment->set_recruitment_credential("birthdate",$_POST["birthdate"]);
            $recruitment->set_recruitment_credential("age",$_POST["age"]);
            $recruitment->set_recruitment_credential("sex",$_POST["sex"]);
            $recruitment->set_recruitment_credential("address",$_POST["address"]);
            $recruitment->set_recruitment_credential("contact",$_POST["contact"]);
            $recruitment->set_recruitment_credential("email",$_POST["email"]);
            $recruitment->set_recruitment_credential("code",$_POST["code"]);
            $recruitment->set_recruitment_credential("pass",$_POST["pass"]);
            $recruitment->set_recruitment_credential("date_added",$date);
            $recruitment->set_recruitment_credential("status",$_POST["status"]);
            
            if($recruitment->startcreaterecruitment()) echo "Successfully added a new  Recruitment";
            else echo "Hey! something went wrong.";
        break;

        case "recruitment_update": 
            $recruitment->set_recruitment_credential("recruitment_id",$_POST["recruitment_id"]);
            $recruitment->set_recruitment_credential("lname",$_POST["lname"]);
            $recruitment->set_recruitment_credential("fname",$_POST["fname"]);
            $recruitment->set_recruitment_credential("mname",$_POST["mname"]);
            $recruitment->set_recruitment_credential("birthdate",$_POST["birthdate"]);
            $recruitment->set_recruitment_credential("age",$_POST["age"]);
            $recruitment->set_recruitment_credential("sex",$_POST["sex"]);
            $recruitment->set_recruitment_credential("address",$_POST["address"]);
            $recruitment->set_recruitment_credential("contact",$_POST["contact"]);
            $recruitment->set_recruitment_credential("email",$_POST["email"]);
            $recruitment->set_recruitment_credential("code",$_POST["code"]);
            $recruitment->set_recruitment_credential("pass",$_POST["pass"]);
            $recruitment->set_recruitment_credential("date_added",$date);
            $recruitment->set_recruitment_credential("status",$_POST["status"]);
            
            if($recruitment->startupdaterecruitment()) echo "Successfully updated the Recruitment ".$_POST["recruitment_id"];
            else echo "Hey! something went wrong.";
        break;

         case "recruitment_find1": 
            ob_start();
            if($_POST["key"]!=""){
            $recruitment = new Recruitment();
            $recruitment->startfindrecruitment($_POST["key"]);
            $recruitment_all = $recruitment->get_recruitment_credential("all");

            if($recruitment_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($recruitment_all["recruitment_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $recruitment_all["recruitment_id"][$r] ?></th>
                        <td><?php echo $recruitment_all["lname"][$r];?></td>
                        <td><?php echo $recruitment_all["fname"][$r];?></td>
                        <td><?php echo $recruitment_all["mname"][$r];?></td>
                        <td><?php echo $recruitment_all["contact"][$r]; ?></td>
                        <td><?php echo $recruitment_all["email"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success recruitment-record-table-row" data-toggle="modal" data-target="#updaterecruitmentmodal" data-recruitmentdata ='{ 
                            "recruitment_id" : "<?php echo $recruitment_all["recruitment_id"][$r] ?>",
                            "lname" : "<?php echo $recruitment_all["lname"][$r] ?>",
                            "fname" : "<?php echo $recruitment_all["fname"][$r] ?>",
                            "mname" : "<?php echo $recruitment_all["mname"][$r] ?>",   
                            "age" : "<?php echo $recruitment_all["age"][$r] ?>",
                            "sex" : "<?php echo $recruitment_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $recruitment_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $recruitment_all["address"][$r] ?>", 
                            "contact" : "<?php echo $recruitment_all["contact"][$r] ?>",
                            "email" : "<?php echo $recruitment_all["email"][$r] ?>", 
                            "code" : "<?php echo $recruitment_all["code"][$r] ?>", 
                            "pass" : "<?php echo $recruitment_all["pass"][$r] ?>", 
                            "status" : "<?php echo $recruitment_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                            <button class="btn btn-info recruitment-record-table-row-view" data-target="#recruitment1-<?php echo $recruitment_all["recruitment_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View </button>
                            </td>
                            <td>
                                <?php
                                    if ($recruitment_all["status"][$r]) echo '<span class="badge badge-success"style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger"style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                                <td>
        <?php echo $recruitment_all["recruitment_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="recruitment1-<?php echo $recruitment_all["recruitment_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-users"></i> Recruitment View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Recruitment code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># recruitment ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["recruitment_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                              <?php
                                    if ($recruitment_all["status"][$r]) echo '<span class="badge badge-success"style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger"style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                    </td>
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{
            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';}
            echo ob_get_clean();
        break;

        case "recruitment_find2":
          ob_start();
             if($_POST["key"]!=""){
            $recruitment = new Recruitment();
            $recruitment->startfindrecruitment($_POST["key"]);
            $recruitment_all = $recruitment->get_recruitment_credential("all");

            if($recruitment_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($recruitment_all["recruitment_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $recruitment_all["recruitment_id"][$r] ?></th>
                        <td><?php echo $recruitment_all["lname"][$r];?></td>
                        <td><?php echo $recruitment_all["fname"][$r];?></td>
                        <td><?php echo $recruitment_all["mname"][$r];?></td>
                        <td><?php echo $recruitment_all["contact"][$r]; ?></td>
                        <td><?php echo $recruitment_all["email"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success recruitment-record-table-row" data-toggle="modal" data-target="#updaterecruitmentmodal" data-recruitmentdata ='{ 
                            "recruitment_id" : "<?php echo $recruitment_all["recruitment_id"][$r] ?>",
                            "lname" : "<?php echo $recruitment_all["lname"][$r] ?>",
                            "fname" : "<?php echo $recruitment_all["fname"][$r] ?>",
                            "mname" : "<?php echo $recruitment_all["mname"][$r] ?>",   
                            "age" : "<?php echo $recruitment_all["age"][$r] ?>",
                            "sex" : "<?php echo $recruitment_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $recruitment_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $recruitment_all["address"][$r] ?>", 
                            "contact" : "<?php echo $recruitment_all["contact"][$r] ?>",
                            "email" : "<?php echo $recruitment_all["email"][$r] ?>", 
                            "code" : "<?php echo $recruitment_all["code"][$r] ?>", 
                            "pass" : "<?php echo $recruitment_all["pass"][$r] ?>", 
                            "status" : "<?php echo $recruitment_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                            <button class="btn btn-info recruitment-record-table-row-view" data-target="#recruitment2-<?php echo $recruitment_all["recruitment_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View </button>
                            </td>
                            <td>
                               <?php
                                    if ($recruitment_all["status"][$r]) echo '<span class="badge badge-success"style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger"style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                                <td>
        <?php echo $recruitment_all["recruitment_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="recruitment2-<?php echo $recruitment_all["recruitment_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-users"></i> Recruitment View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Recruitment code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># recruitment ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["recruitment_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                              <?php
                                    if ($recruitment_all["status"][$r]) echo '<span class="badge badge-success"style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger"style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $recruitment_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $recruitment_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                    </td>
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{
            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';}
            echo ob_get_clean();
        break;

         case "coordinator_create":
            $coordinator->set_coordinator_credential("lname",$_POST["lname"]);
            $coordinator->set_coordinator_credential("fname",$_POST["fname"]);
            $coordinator->set_coordinator_credential("mname",$_POST["mname"]);
            $coordinator->set_coordinator_credential("birthdate",$_POST["birthdate"]);
            $coordinator->set_coordinator_credential("age",$_POST["age"]);
            $coordinator->set_coordinator_credential("sex",$_POST["sex"]);
            $coordinator->set_coordinator_credential("address",$_POST["address"]);
            $coordinator->set_coordinator_credential("contact",$_POST["contact"]);
            $coordinator->set_coordinator_credential("email",$_POST["email"]);
            $coordinator->set_coordinator_credential("code",$_POST["code"]);
            $coordinator->set_coordinator_credential("pass",$_POST["pass"]);
            $coordinator->set_coordinator_credential("date_added",$date);
            $coordinator->set_coordinator_credential("status",$_POST["status"]);
            
            if($coordinator->startcreatecoordinator()) echo "Successfully added a new  Coordinator";
            else echo "Hey! something went wrong.";
        break;

        case "coordinator_update": 
            $coordinator->set_coordinator_credential("coordinator_id",$_POST["coordinator_id"]);
            $coordinator->set_coordinator_credential("lname",$_POST["lname"]);
            $coordinator->set_coordinator_credential("fname",$_POST["fname"]);
            $coordinator->set_coordinator_credential("mname",$_POST["mname"]);
            $coordinator->set_coordinator_credential("birthdate",$_POST["birthdate"]);
            $coordinator->set_coordinator_credential("age",$_POST["age"]);
            $coordinator->set_coordinator_credential("sex",$_POST["sex"]);
            $coordinator->set_coordinator_credential("address",$_POST["address"]);
            $coordinator->set_coordinator_credential("contact",$_POST["contact"]);
            $coordinator->set_coordinator_credential("email",$_POST["email"]);
            $coordinator->set_coordinator_credential("code",$_POST["code"]);
            $coordinator->set_coordinator_credential("pass",$_POST["pass"]);
            $coordinator->set_coordinator_credential("date_added",$date);
            $coordinator->set_coordinator_credential("status",$_POST["status"]);
            
            if($coordinator->startupdatecoordinator()) echo "Successfully updated the Coordinator ".$_POST["coordinator_id"];
            else echo "Hey! something went wrong.";
        break;

         case "coordinator_find1": 
            ob_start();
            if($_POST["key"]!=""){
            $coordinator = new Coordinator();
            $coordinator->startfindcoordinator($_POST["key"]);
            $coordinator_all = $coordinator->get_coordinator_credential("all");

            if($coordinator_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($coordinator_all["coordinator_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $coordinator_all["coordinator_id"][$r] ?></th>
                        <td><?php echo $coordinator_all["lname"][$r];?></td>
                        <td><?php echo $coordinator_all["fname"][$r];?></td>
                        <td><?php echo $coordinator_all["mname"][$r];?></td>
                        <td><?php echo $coordinator_all["contact"][$r]; ?></td>
                        <td><?php echo $coordinator_all["email"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success coordinator-record-table-row" data-toggle="modal" data-target="#updatecoordinatormodal" data-coordinatordata ='{ 
                            "coordinator_id" : "<?php echo $coordinator_all["coordinator_id"][$r] ?>",
                            "lname" : "<?php echo $coordinator_all["lname"][$r] ?>",
                            "fname" : "<?php echo $coordinator_all["fname"][$r] ?>",
                            "mname" : "<?php echo $coordinator_all["mname"][$r] ?>",   
                            "age" : "<?php echo $coordinator_all["age"][$r] ?>",
                            "sex" : "<?php echo $coordinator_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $coordinator_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $coordinator_all["address"][$r] ?>", 
                            "contact" : "<?php echo $coordinator_all["contact"][$r] ?>",
                            "email" : "<?php echo $coordinator_all["email"][$r] ?>", 
                            "code" : "<?php echo $coordinator_all["code"][$r] ?>", 
                            "pass" : "<?php echo $coordinator_all["pass"][$r] ?>", 
                            "status" : "<?php echo $coordinator_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                            <button class="btn btn-info coordinator-record-table-row-view" data-target="#coordinator1-<?php echo $coordinator_all["coordinator_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View </button>
                            </td>
                            <td>
                                <?php
                                    if ($coordinator_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                                <td>
        <?php echo $coordinator_all["coordinator_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="coordinator1-<?php echo $coordinator_all["coordinator_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-users"></i> Coordinator View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Coordinator code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Coordinator ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $coordinator_all["coordinator_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $coordinator_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $coordinator_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $coordinator_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                               <?php
                                    if ($coordinator_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $coordinator_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                    </td>
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{
            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';}
            echo ob_get_clean();
        break;

        case "coordinator_find2":
          ob_start();
             if($_POST["key"]!=""){
            $coordinator = new Coordinator();
            $coordinator->startfindcoordinator($_POST["key"]);
            $coordinator_all = $coordinator->get_coordinator_credential("all");

            if($coordinator_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($coordinator_all["coordinator_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $coordinator_all["coordinator_id"][$r] ?></th>
                        <td><?php echo $coordinator_all["lname"][$r];?></td>
                        <td><?php echo $coordinator_all["fname"][$r];?></td>
                        <td><?php echo $coordinator_all["mname"][$r];?></td>
                        <td><?php echo $coordinator_all["contact"][$r]; ?></td>
                        <td><?php echo $coordinator_all["email"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success coordinator-record-table-row" data-toggle="modal" data-target="#updatecoordinatormodal" data-coordinatordata ='{ 
                            "coordinator_id" : "<?php echo $coordinator_all["coordinator_id"][$r] ?>",
                            "lname" : "<?php echo $coordinator_all["lname"][$r] ?>",
                            "fname" : "<?php echo $coordinator_all["fname"][$r] ?>",
                            "mname" : "<?php echo $coordinator_all["mname"][$r] ?>",   
                            "age" : "<?php echo $coordinator_all["age"][$r] ?>",
                            "sex" : "<?php echo $coordinator_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $coordinator_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $coordinator_all["address"][$r] ?>", 
                            "contact" : "<?php echo $coordinator_all["contact"][$r] ?>",
                            "email" : "<?php echo $coordinator_all["email"][$r] ?>", 
                            "code" : "<?php echo $coordinator_all["code"][$r] ?>", 
                            "pass" : "<?php echo $coordinator_all["pass"][$r] ?>", 
                            "status" : "<?php echo $coordinator_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                            <button class="btn btn-info coordinator-record-table-row-view" data-target="#coordinator2-<?php echo $coordinator_all["coordinator_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View </button>
                            </td>
                            <td>
                                <?php
                                    if ($coordinator_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                                <td>
        <?php echo $coordinator_all["coordinator_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="coordinator2-<?php echo $coordinator_all["coordinator_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-users"></i> Coordinator View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Coordinator code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Coordinator ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $coordinator_all["coordinator_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $coordinator_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $coordinator_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $coordinator_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                               <?php
                                    if ($coordinator_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $coordinator_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $coordinator_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                    </td>
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{
            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';}
            echo ob_get_clean();
        break;

     case "company_create":
            $company->set_company_credential("company_name",$_POST["company_name"]);
            $company->set_company_credential("description",$_POST["description"]);
            $company->set_company_credential("contact",$_POST["contact"]);
            $company->set_company_credential("email",$_POST["email"]);
            $company->set_company_credential("address",$_POST["address"]);
            $company->set_company_credential("date_added",$date);
            $company->set_company_credential("status",$_POST["status"]);
            
            if($company->startcreatecompany()) echo "Successfully added a new Company";
            else echo "Hey! something went wrong.";
        break;

        case "company_update": 
            $company->set_company_credential("company_id",$_POST["company_id"]);
            $company->set_company_credential("company_name",$_POST["company_name"]);
            $company->set_company_credential("description",$_POST["description"]);
            $company->set_company_credential("contact",$_POST["contact"]);
            $company->set_company_credential("email",$_POST["email"]);
            $company->set_company_credential("address",$_POST["address"]);
            $company->set_company_credential("date_added",$date);
            $company->set_company_credential("status",$_POST["status"]);
            
            if($company->startupdatecompany()) echo "Successfully updated the Company ".$_POST["company_id"];
            else echo "Hey! something went wrong.";
        break;

            case "company_find": 
            ob_start();
            if($_POST["key"]!=""){
            $company = new Company();
            $company->startfindcompany($_POST["key"]);
            $company_all = $company->get_company_credential("all");

            if($company_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($company_all["company_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                            <th scope="row"><?php echo $company_all["company_id"][$r] ?></th>
                            <td><?php echo $company_all["company_name"][$r];?></td>
                            <td><?php echo $company_all["description"][$r];?></td>
                            <td><?php echo $company_all["address"][$r];?></td>
                            <td>
                            <button class="btn btn-success company-record-table-row" data-toggle="modal" data-target="#updatecompanymodal" data-companydata ='{ 
                            "company_id" : "<?php echo $company_all["company_id"][$r] ?>",
                            "company_name" : "<?php echo $company_all["company_name"][$r] ?>",
                            "description" : "<?php echo $company_all["description"][$r] ?>",
                            "contact" : "<?php echo $company_all["contact"][$r] ?>",
                            "email" : "<?php echo $company_all["email"][$r] ?>",
                            "address" : "<?php echo $company_all["address"][$r] ?>", 
                            "status" : "<?php echo $company_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                            <button class="btn btn-info company-record-table-row-view" data-target="#company1-<?php echo $company_all["company_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View </button>
                            </td>
                            <td>
                               <?php
                                    if ($company_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger"  style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                      <td>
        <?php echo $company_all["company_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="company1-<?php echo $company_all["company_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fab fa-houzz"></i> Department View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Department code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Department ID</th>
                            <th><i class="fas fa-pen-alt"></i> Department Name </th>
                            <th><i class="fas fa-pen-alt"></i> Description </th>
                            <th><i class="fa fa-phone"></i> Contact </th></tr>
                            <td style="border:0px;"><?php echo $company_all["company_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $company_all["company_name"][$r];?></td>
                            <td style="border:0px;"><?php echo $company_all["description"][$r];?></td>
                            <td style="border:0px;"><?php echo $company_all["contact"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-envelop"></i> Email </th>
                            <th><i class="fa fa-id-card"></i> Address </th>
                            <th><i class="fa fa-calendar"></i> Date Added </th></tr>
                            <td style="border:0px;"><?php echo $company_all["email"][$r];?></td>
                            <td style="border:0px;"><?php echo $company_all["address"][$r];?></td>
                            <td style="border:0px;"><?php echo $company_all["date_added"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"> 
                              <?php
                                    if ($company_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger"  style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>          
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{
            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';}
            echo ob_get_clean();
        break;
        
        case "coursecode_create": 
            $coursecode->set_coursecode_credential("coursecode",$_POST["coursecode"]);
            $coursecode->set_coursecode_credential("description",$_POST["description"]);
            $coursecode->set_coursecode_credential("remarks",$_POST["remarks"]);
            $coursecode->set_coursecode_credential("date_added",$_POST["date_added"]);
            $coursecode->set_coursecode_credential("status",$_POST["status"]);
            
            if($coursecode->startcreatecoursecode()) echo "Successfully created a new Course Code";
            else echo "Ooops! something went wrong."; 
        break;

        case "coursecode_update": 
            $coursecode->set_coursecode_credential("coursecode_id",$_POST["coursecode_id"]);
            $coursecode->set_coursecode_credential("coursecode",$_POST["coursecode"]);
            $coursecode->set_coursecode_credential("description",$_POST["description"]);
            $coursecode->set_coursecode_credential("remarks",$_POST["remarks"]);
            $coursecode->set_coursecode_credential("date_added",$_POST["date_added"]);
            $coursecode->set_coursecode_credential("status",$_POST["status"]);

            if($coursecode->startupdatecoursecode()) echo "Successfully updated the Course Code number " . $_POST["coursecode_id"];
            else echo "Ooops! something went wrong."; 
        break;

           case "coursecode_find": 
            ob_start();

            if($_POST["key"]!=""){
            $coursecode = new Coursecode();
            $coursecode->startfindcoursecode($_POST["key"]);
            $coursecode_all = $coursecode->get_coursecode_credential("all");

            if($coursecode_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($coursecode_all["coursecode_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $coursecode_all["coursecode_id"][$r] ?></th>
                       
                        <td>
                            <?php echo $coursecode_all["coursecode"][$r];?><br>
                            </td>
                            <td><?php echo $coursecode_all["description"][$r]; ?></td>
                            <td><?php echo $coursecode_all["remarks"][$r]; ?></td>
                            <td><?php echo $coursecode_all["date_added"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success coursecode-record-table-roww" data-toggle="modal" data-target="#updatecoursecodemodal" data-coursecodedata='{ 
                            "coursecode_id" : "<?php echo $coursecode_all["coursecode_id"][$r] ?>",
                            "coursecode" : "<?php echo $coursecode_all["coursecode"][$r] ?>",
                            "description" : "<?php echo $coursecode_all["description"][$r] ?>",    
                            "remarks" : "<?php echo $coursecode_all["remarks"][$r] ?>",
                            "date_added" : "<?php echo $coursecode_all["date_added"][$r]?>" }'><i class="fa fa-edit"></i> UPDATE </button>
                        </td>
                         <td>
                            <button class="btn btn-info coursecode-record-table-row-views" data-toggle="modal" data-target="#coursecode1-<?php echo $coursecode_all["coursecode_id"][$r]; ?>"><i class="fa fa-eye"></i> VIEW 
                          </button>
                      </td>
                            <td>
                                <?php
                                    if ($coursecode_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                            
        <!--View Modal -->
        <td>
        <?php echo $coursecode_all["coursecode_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="coursecode1-<?php echo $coursecode_all["coursecode_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fab fa-hubspot"></i> Course Code View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Course Code ID </th>
                            <th><i class="fas fa-pen-alt"></i>  Course Code </th>
                            <th><i class="fas fa-pen-alt"></i> Description </th></tr>
                            <td style="border:0px;"><?php echo $coursecode_all["coursecode_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $coursecode_all["coursecode"][$r];?></td>
                            <td style="border:0px;"><?php echo $coursecode_all["description"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i>  Remarks </th>
                            <th><i class="far fa-calendar-alt"></i> Date Added </th></tr>
                            <td style="border:0px;"><?php echo $coursecode_all["remarks"][$r];?></td>
                            <td style="border:0px;"><?php echo $coursecode_all["date_added"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"> 
                              <?php
                                    if ($coursecode_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
        <!--View Modal -->
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{

            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';
        }
            echo ob_get_clean();
        break;

        case "areacode_create": 
            $areacode->set_areacode_credential("areacode",$_POST["areacode"]);
            $areacode->set_areacode_credential("description",$_POST["description"]);
            $areacode->set_areacode_credential("remarks",$_POST["remarks"]);
            $areacode->set_areacode_credential("date_added",$_POST["date_added"]);
            $areacode->set_areacode_credential("status",$_POST["status"]);
            
            if($areacode->startcreateareacode()) echo "Successfully created a new Areacode";
            else echo "Ooops! something went wrong."; 
        break;

        case "areacode_update": 
            $areacode->set_areacode_credential("areacode_id",$_POST["areacode_id"]);
            $areacode->set_areacode_credential("areacode",$_POST["areacode"]);
            $areacode->set_areacode_credential("description",$_POST["description"]);
            $areacode->set_areacode_credential("remarks",$_POST["remarks"]);
            $areacode->set_areacode_credential("date_added",$_POST["date_added"]);
            $areacode->set_areacode_credential("status",$_POST["status"]);

            if($areacode->startupdateareacode()) echo "Successfully updated the Areacode number " . $_POST["areacode_id"];
            else echo "Ooops! something went wrong."; 
        break;

        
        case "areacode_find": 
            ob_start();

            if($_POST["key"]!=""){
            $areacode = new Areacode();
            $areacode->startfindareacode($_POST["key"]);
            $areacode_all = $areacode->get_areacode_credential("all");

            if($areacode_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($areacode_all["areacode_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $areacode_all["areacode_id"][$r] ?></th>
                       
                        <td>
                            <?php echo $areacode_all["areacode"][$r];?><br>
                            </td>
                            <td><?php echo $areacode_all["description"][$r]; ?></td>
                            <td><?php echo $areacode_all["remarks"][$r]; ?></td>
                            <td><?php echo $areacode_all["date_added"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success areacode-record-table-roww" data-toggle="modal" data-target="#updateareacodemodal" data-areacodedata='{ 
                            "areacode_id" : "<?php echo $areacode_all["areacode_id"][$r] ?>",
                            "areacode" : "<?php echo $areacode_all["areacode"][$r] ?>",
                            "description" : "<?php echo $areacode_all["description"][$r] ?>",    
                            "remarks" : "<?php echo $areacode_all["remarks"][$r] ?>",
                            "date_added" : "<?php echo $areacode_all["date_added"][$r]?>" }'><i class="fa fa-edit"></i> UPDATE </button>
                        </td>
                         <td>
                            <button class="btn btn-info areacode-record-table-row-views" data-toggle="modal" data-target="#areacode1-<?php echo $areacode_all["areacode_id"][$r]; ?>"><i class="fa fa-eye"></i> VIEW 
                          </button>
                      </td>
                            <td>
                                <?php
                                    if ($areacode_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                            
        <!--View Modal -->
        <td>
        <?php echo $areacode_all["areacode_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="areacode1-<?php echo $areacode_all["areacode_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fab fa-linode"></i> Areacode Code View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Areacode Code ID </th>
                            <th><i class="fas fa-pen-alt"></i>  Areacode Code </th>
                            <th><i class="fas fa-pen-alt"></i> Description </th></tr>
                            <td style="border:0px;"><?php echo $areacode_all["areacode_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $areacode_all["areacode"][$r];?></td>
                            <td style="border:0px;"><?php echo $areacode_all["description"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i>  Remarks </th>
                            <th><i class="far fa-calendar-alt"></i> Date Added </th></tr>
                            <td style="border:0px;"><?php echo $areacode_all["remarks"][$r];?></td>
                            <td style="border:0px;"><?php echo $areacode_all["date_added"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"> 
                              <?php
                                    if ($areacode_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
        <!--View Modal -->
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{

            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';
        }
            echo ob_get_clean();
        break;

         case "coursetitle_create": 
            $coursetitle->set_coursetitle_credential("coursetitle",$_POST["coursetitle"]);
            $coursetitle->set_coursetitle_credential("description",$_POST["description"]);
            $coursetitle->set_coursetitle_credential("remarks",$_POST["remarks"]);
            $coursetitle->set_coursetitle_credential("date_added",$_POST["date_added"]);
            $coursetitle->set_coursetitle_credential("status",$_POST["status"]);
            
            if($coursetitle->startcreatecoursetitle()) echo "Successfully created a new Coursetitle";
            else echo "Ooops! something went wrong."; 
        break;

        case "coursetitle_update": 
            $coursetitle->set_coursetitle_credential("coursetitle_id",$_POST["coursetitle_id"]);
            $coursetitle->set_coursetitle_credential("coursetitle",$_POST["coursetitle"]);
            $coursetitle->set_coursetitle_credential("description",$_POST["description"]);
            $coursetitle->set_coursetitle_credential("remarks",$_POST["remarks"]);
            $coursetitle->set_coursetitle_credential("date_added",$_POST["date_added"]);
            $coursetitle->set_coursetitle_credential("status",$_POST["status"]);

        if($coursetitle->startupdatecoursetitle()) echo "Successfully updated the Coursetitle number " . $_POST["coursetitle_id"];
            else echo "Ooops! something went wrong."; 
        break;

        case "coursetitle_find": 
            ob_start();

            if($_POST["key"]!=""){
            $coursetitle = new Coursetitle();
            $coursetitle->startfindcoursetitle($_POST["key"]);
            $coursetitle_all = $coursetitle->get_coursetitle_credential("all");

            if($coursetitle_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($coursetitle_all["coursetitle_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $coursetitle_all["coursetitle_id"][$r] ?></th>
                       
                        <td>
                            <?php echo $coursetitle_all["coursetitle"][$r];?><br>
                            </td>
                            <td><?php echo $coursetitle_all["description"][$r]; ?></td>
                            <td><?php echo $coursetitle_all["remarks"][$r]; ?></td>
                            <td><?php echo $coursetitle_all["date_added"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success coursetitle-record-table-row" data-toggle="modal" data-target="#updatecoursetitlemodal" data-coursetitledata='{ 
                            "coursetitle_id" : "<?php echo $coursetitle_all["coursetitle_id"][$r] ?>",
                            "coursetitle" : "<?php echo $coursetitle_all["coursetitle"][$r] ?>",
                            "description" : "<?php echo $coursetitle_all["description"][$r] ?>",    
                            "remarks" : "<?php echo $coursetitle_all["remarks"][$r] ?>",
                            "date_added" : "<?php echo $coursetitle_all["date_added"][$r]?>" }'><i class="fa fa-edit"></i> UPDATE </button>
                        </td>
                         <td>
                            <button class="btn btn-info coursetitle-record-table-row-views" data-toggle="modal" data-target="#coursetitle1-<?php echo $coursetitle_all["coursetitle_id"][$r]; ?>"><i class="fa fa-eye"></i> VIEW 
                          </button>
                      </td>
                            <td>
                                <?php
                                    if ($coursetitle_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                            
        <!--View Modal -->
        <td>
        <?php echo $coursetitle_all["coursetitle_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="coursetitle1-<?php echo $coursetitle_all["coursetitle_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fab fa-magento"></i> Coursetitle View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Coursetitle ID </th>
                            <th><i class="fas fa-pen-alt"></i>  Coursetitle  </th>
                            <th><i class="fas fa-pen-alt"></i> Description </th></tr>
                            <td style="border:0px;"><?php echo $coursetitle_all["coursetitle_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $coursetitle_all["coursetitle"][$r];?></td>
                            <td style="border:0px;"><?php echo $coursetitle_all["description"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i>  Remarks </th>
                            <th><i class="far fa-calendar-alt"></i> Date Added </th></tr>
                            <td style="border:0px;"><?php echo $coursetitle_all["remarks"][$r];?></td>
                            <td style="border:0px;"><?php echo $coursetitle_all["date_added"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"> 
                              <?php
                                    if ($coursetitle_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
        <!--View Modal -->
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{

            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';
        }
            echo ob_get_clean();
        break;


      case "unit_create": 
            $unit->set_unit_credential("unit",$_POST["unit"]);
            $unit->set_unit_credential("description",$_POST["description"]);
            $unit->set_unit_credential("remarks",$_POST["remarks"]);
            $unit->set_unit_credential("date_added",$_POST["date_added"]);
            $unit->set_unit_credential("status",$_POST["status"]);
            
            if($unit->startcreateunit()) echo "Successfully created a new Unit";
            else echo "Ooops! something went wrong."; 
        break;

        case "unit_update": 
            $unit->set_unit_credential("unit_id",$_POST["unit_id"]);
            $unit->set_unit_credential("unit",$_POST["unit"]);
            $unit->set_unit_credential("description",$_POST["description"]);
            $unit->set_unit_credential("remarks",$_POST["remarks"]);
            $unit->set_unit_credential("date_added",$_POST["date_added"]);
            $unit->set_unit_credential("status",$_POST["status"]);

            if($unit->startupdateunit()) echo "Successfully updated the Unit number " . $_POST["unit_id"];
            else echo "Ooops! something went wrong."; 
        break;

        case "unit_find": 
            ob_start();

            if($_POST["key"]!=""){
            $unit = new Unit();
            $unit->startfindunit($_POST["key"]);
            $unit_all = $unit->get_unit_credential("all");

            if($unit_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($unit_all["unit_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $unit_all["unit_id"][$r] ?></th>
                       
                        <td>
                            <?php echo $unit_all["unit"][$r];?><br>
                            </td>
                            <td><?php echo $unit_all["description"][$r]; ?></td>
                            <td><?php echo $unit_all["remarks"][$r]; ?></td>
                            <td><?php echo $unit_all["date_added"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success unit-record-table-row" data-toggle="modal" data-target="#updateunitmodal" data-unitdata='{ 
                            "unit_id" : "<?php echo $unit_all["unit_id"][$r] ?>",
                            "unit" : "<?php echo $unit_all["unit"][$r] ?>",
                            "description" : "<?php echo $unit_all["description"][$r] ?>",    
                            "remarks" : "<?php echo $unit_all["remarks"][$r] ?>",
                            "date_added" : "<?php echo $unit_all["date_added"][$r]?>" }'><i class="fa fa-edit"></i> UPDATE </button>
                        </td>
                         <td>
                            <button class="btn btn-info unit-record-table-row-views" data-toggle="modal" data-target="#unit1-<?php echo $unit_all["unit_id"][$r]; ?>"><i class="fa fa-eye"></i> VIEW 
                          </button>
                      </td>
                            <td>
                                <?php
                                    if ($unit_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                            
        <!--View Modal -->
        <td>
        <?php echo $unit_all["unit_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="unit1-<?php echo $unit_all["unit_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fab fa-react"></i> Unit View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Unit ID </th>
                            <th><i class="fas fa-pen-alt"></i>  Unit  </th>
                            <th><i class="fas fa-pen-alt"></i> Description </th></tr>
                            <td style="border:0px;"><?php echo $unit_all["unit_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $unit_all["unit"][$r];?></td>
                            <td style="border:0px;"><?php echo $unit_all["description"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i>  Remarks </th>
                            <th><i class="far fa-calendar-alt"></i> Date Added </th></tr>
                            <td style="border:0px;"><?php echo $unit_all["remarks"][$r];?></td>
                            <td style="border:0px;"><?php echo $unit_all["date_added"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"> 
                              <?php
                                    if ($unit_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
        <!--View Modal -->
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{

            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';
        }
            echo ob_get_clean();
        break;

         case "teacher_create":
            $teacher->set_teacher_credential("lname",$_POST["lname"]);
            $teacher->set_teacher_credential("fname",$_POST["fname"]);
            $teacher->set_teacher_credential("mname",$_POST["mname"]);
            $teacher->set_teacher_credential("birthdate",$_POST["birthdate"]);
            $teacher->set_teacher_credential("age",$_POST["age"]);
            $teacher->set_teacher_credential("sex",$_POST["sex"]);
            $teacher->set_teacher_credential("address",$_POST["address"]);
            $teacher->set_teacher_credential("contact",$_POST["contact"]);
            $teacher->set_teacher_credential("email",$_POST["email"]);
            $teacher->set_teacher_credential("code",$_POST["code"]);
            $teacher->set_teacher_credential("pass",$_POST["pass"]);
            $teacher->set_teacher_credential("date_added",$date);
            $teacher->set_teacher_credential("status",$_POST["status"]);
            
            if($teacher->startcreateteacher()) echo "Successfully added a new  Teacher";
            else echo "Hey! something went wrong.";
        break;

        case "teacher_update": 
            $teacher->set_teacher_credential("teacher_id",$_POST["teacher_id"]);
            $teacher->set_teacher_credential("lname",$_POST["lname"]);
            $teacher->set_teacher_credential("fname",$_POST["fname"]);
            $teacher->set_teacher_credential("mname",$_POST["mname"]);
            $teacher->set_teacher_credential("birthdate",$_POST["birthdate"]);
            $teacher->set_teacher_credential("age",$_POST["age"]);
            $teacher->set_teacher_credential("sex",$_POST["sex"]);
            $teacher->set_teacher_credential("address",$_POST["address"]);
            $teacher->set_teacher_credential("contact",$_POST["contact"]);
            $teacher->set_teacher_credential("email",$_POST["email"]);
            $teacher->set_teacher_credential("code",$_POST["code"]);
            $teacher->set_teacher_credential("pass",$_POST["pass"]);
            $teacher->set_teacher_credential("date_added",$date);
            $teacher->set_teacher_credential("status",$_POST["status"]);
            
            if($teacher->startupdateteacher()) echo "Successfully updated the Teacher ".$_POST["teacher_id"];
            else echo "Hey! something went wrong.";
        break;
        
        case "teacher_find": 
            ob_start();
            if($_POST["key"]!=""){
            $teacher = new Teacher();
            $teacher->startfindteacher($_POST["key"]);
            $teacher_all = $teacher->get_teacher_credential("all");

            if($teacher_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($teacher_all["teacher_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $teacher_all["teacher_id"][$r] ?></th>
                        <td><?php echo $teacher_all["lname"][$r];?></td>
                        <td><?php echo $teacher_all["fname"][$r];?></td>
                        <td><?php echo $teacher_all["mname"][$r];?></td>
                        <td><?php echo $teacher_all["contact"][$r]; ?></td>
                        <td><?php echo $teacher_all["email"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success teacher-record-table-row" data-toggle="modal" data-target="#updateteachermodal" data-teacherdata ='{ 
                            "teacher_id" : "<?php echo $teacher_all["teacher_id"][$r] ?>",
                            "lname" : "<?php echo $teacher_all["lname"][$r] ?>",
                            "fname" : "<?php echo $teacher_all["fname"][$r] ?>",
                            "mname" : "<?php echo $teacher_all["mname"][$r] ?>",   
                            "age" : "<?php echo $teacher_all["age"][$r] ?>",
                            "sex" : "<?php echo $teacher_all["sex"][$r] ?>",
                            "birthdate" : "<?php echo $teacher_all["birthdate"][$r] ?>", 
                            "address" : "<?php echo $teacher_all["address"][$r] ?>", 
                            "contact" : "<?php echo $teacher_all["contact"][$r] ?>",
                            "email" : "<?php echo $teacher_all["email"][$r] ?>", 
                            "code" : "<?php echo $teacher_all["code"][$r] ?>", 
                            "pass" : "<?php echo $teacher_all["pass"][$r] ?>", 
                            "status" : "<?php echo $teacher_all["status"][$r] ?>" }'><i class="fas fa-recycle"></i> Update </button>
                            </td>
                            <td>
                            <button class="btn btn-info teacher-record-table-row-view" data-target="#teacher1-<?php echo $teacher_all["teacher_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View </button>
                            </td>
                            <td>
                             <?php
                                    if ($teacher_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                                <td>
        <?php echo $teacher_all["teacher_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="teacher1-<?php echo $teacher_all["teacher_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-user-tie"></i> Teacher View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Teacher code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Teacher ID</th>
                            <th><i class="fas fa-pen-alt"></i> Lastname</th>
                            <th><i class="fas fa-pen-alt"></i> Firstname</th>
                            <th><i class="fas fa-pen-alt"></i> Middlename</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["teacher_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["lname"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["fname"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["mname"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i> Age</th>
                            <th><i class="fa fa-venus-double"></i> Sex</th>
                            <th><i class="fa fa-calendar"></i> Birthdate</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["age"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["sex"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["birthdate"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-address-card"></i> Address</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["address"][$r];?></td>
                    </table>
                       <table class="table">
                            <tr><th><i class="fa fa-phone-square"></i> Contact</th>
                            <th><i class="fa fa-envelope-square"></i> Email</th>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["email"][$r];?></td>
                            <td style="border:0px;"> 
                             <?php
                                    if ($teacher_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                    </table>
                     <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code</th>
                            <th><i class="fa fa-eye-slash"></i> Pass</th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["pass"][$r];?></td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                    </td>
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{
            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';}
            echo ob_get_clean();
        break;


         case "learn_create": 
            $learn->set_learn_credential("learn",$_POST["learn"]);
            $learn->set_learn_credential("description",$_POST["description"]);
            $learn->set_learn_credential("remarks",$_POST["remarks"]);
            $learn->set_learn_credential("date_added",$_POST["date_added"]);
            $learn->set_learn_credential("status",$_POST["status"]);
            
            if($learn->startcreatelearn()) echo "Successfully created a new Class";
            else echo "Ooops! something went wrong."; 
        break;

        case "learn_update": 
            $learn->set_learn_credential("learn_id",$_POST["learn_id"]);
            $learn->set_learn_credential("learn",$_POST["learn"]);
            $learn->set_learn_credential("description",$_POST["description"]);
            $learn->set_learn_credential("remarks",$_POST["remarks"]);
            $learn->set_learn_credential("date_added",$_POST["date_added"]);
            $learn->set_learn_credential("status",$_POST["status"]);

        if($learn->startupdatelearn()) echo "Successfully updated the Class number " . $_POST["learn_id"];
            else echo "Ooops! something went wrong."; 
        break;


         case "learn_find": 
            ob_start();

            if($_POST["key"]!=""){
            $learn = new Learn();
            $learn->startfindlearn($_POST["key"]);
            $learn_all = $learn->get_learn_credential("all");

            if($learn_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($learn_all["learn_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $learn_all["learn_id"][$r] ?></th>
                       
                        <td>
                            <?php echo $learn_all["learn"][$r];?><br>
                            </td>
                            <td><?php echo $learn_all["description"][$r]; ?></td>
                            <td><?php echo $learn_all["remarks"][$r]; ?></td>
                            <td><?php echo $learn_all["date_added"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success learn-record-table-row" data-toggle="modal" data-target="#updatelearnmodal" data-learndata='{ 
                            "learn_id" : "<?php echo $learn_all["learn_id"][$r] ?>",
                            "learn" : "<?php echo $learn_all["learn"][$r] ?>",
                            "description" : "<?php echo $learn_all["description"][$r] ?>",    
                            "remarks" : "<?php echo $learn_all["remarks"][$r] ?>",
                            "date_added" : "<?php echo $learn_all["date_added"][$r]?>" }'><i class="fa fa-edit"></i> UPDATE </button>
                        </td>
                         <td>
                            <button class="btn btn-info learn-record-table-row-views" data-toggle="modal" data-target="#learn1-<?php echo $learn_all["learn_id"][$r]; ?>"><i class="fa fa-eye"></i> VIEW 
                          </button>
                      </td>
                            <td>
                                <?php
                                    if ($learn_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                            
        <!--View Modal -->
        <td>
        <?php echo $learn_all["learn_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="learn1-<?php echo $learn_all["learn_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fab fa-apple"></i> Class View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Class ID </th>
                            <th><i class="fas fa-pen-alt"></i>  Class  </th>
                            <th><i class="fas fa-pen-alt"></i> Description </th></tr>
                            <td style="border:0px;"><?php echo $learn_all["learn_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $learn_all["learn"][$r];?></td>
                            <td style="border:0px;"><?php echo $learn_all["description"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i>  Remarks </th>
                            <th><i class="far fa-calendar-alt"></i> Date Added </th></tr>
                            <td style="border:0px;"><?php echo $learn_all["remarks"][$r];?></td>
                            <td style="border:0px;"><?php echo $learn_all["date_added"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"> 
                              <?php
                                    if ($learn_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
        <!--View Modal -->
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{

            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';
        }
            echo ob_get_clean();
        break;


        case "module_create": 
            $module->set_module_credential("module",$_POST["module"]);
            $module->set_module_credential("description",$_POST["description"]);
            $module->set_module_credential("remarks",$_POST["remarks"]);
            $module->set_module_credential("date_added",$_POST["date_added"]);
            $module->set_module_credential("status",$_POST["status"]);
            
            if($module->startcreatemodule()) echo "Successfully created a new Module";
            else echo "Ooops! something went wrong."; 
        break;

        case "module_update": 
            $module->set_module_credential("module_id",$_POST["module_id"]);
            $module->set_module_credential("module",$_POST["module"]);
            $module->set_module_credential("description",$_POST["description"]);
            $module->set_module_credential("remarks",$_POST["remarks"]);
            $module->set_module_credential("date_added",$_POST["date_added"]);
            $module->set_module_credential("status",$_POST["status"]);

        if($module->startupdatemodule()) echo "Successfully updated the Module number " . $_POST["module_id"];
            else echo "Ooops! something went wrong."; 
        break;

        case "module_find": 
            ob_start();

            if($_POST["key"]!=""){
            $module = new Module();
            $module->startfindmodule($_POST["key"]);
            $module_all = $module->get_module_credential("all");

            if($module_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($module_all["module_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $module_all["module_id"][$r] ?></th>
                       
                        <td>
                            <?php echo $module_all["module"][$r];?><br>
                            </td>
                            <td><?php echo $module_all["description"][$r]; ?></td>
                            <td><?php echo $module_all["remarks"][$r]; ?></td>
                            <td><?php echo $module_all["date_added"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success module-record-table-row" data-toggle="modal" data-target="#updatemodulemodal" data-moduledata='{ 
                            "module_id" : "<?php echo $module_all["module_id"][$r] ?>",
                            "module" : "<?php echo $module_all["module"][$r] ?>",
                            "description" : "<?php echo $module_all["description"][$r] ?>",    
                            "remarks" : "<?php echo $module_all["remarks"][$r] ?>",
                            "date_added" : "<?php echo $module_all["date_added"][$r]?>" }'><i class="fa fa-edit"></i> UPDATE </button>
                        </td>
                         <td>
                            <button class="btn btn-info module-record-table-row-views" data-toggle="modal" data-target="#module1-<?php echo $module_all["module_id"][$r]; ?>"><i class="fa fa-eye"></i> VIEW 
                          </button>
                      </td>
                            <td>
                                <?php
                                    if ($module_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                            
        <!--View Modal -->
        <td>
        <?php echo $module_all["module_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="module1-<?php echo $module_all["module_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fas fa-tractor"></i> Module View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Module ID </th>
                            <th><i class="fas fa-pen-alt"></i>  Module  </th>
                            <th><i class="fas fa-pen-alt"></i> Description </th></tr>
                            <td style="border:0px;"><?php echo $module_all["module_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $module_all["module"][$r];?></td>
                            <td style="border:0px;"><?php echo $module_all["description"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i>  Remarks </th>
                            <th><i class="far fa-calendar-alt"></i> Date Added </th></tr>
                            <td style="border:0px;"><?php echo $module_all["remarks"][$r];?></td>
                            <td style="border:0px;"><?php echo $module_all["date_added"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"> 
                              <?php
                                    if ($module_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
        <!--View Modal -->
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{

            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';
        }
            echo ob_get_clean();
        break;

         case "format_create": 
            $format->set_format_credential("format",$_POST["format"]);
            $format->set_format_credential("description",$_POST["description"]);
            $format->set_format_credential("remarks",$_POST["remarks"]);
            $format->set_format_credential("date_added",$_POST["date_added"]);
            $format->set_format_credential("status",$_POST["status"]);
            
            if($format->startcreateformat()) echo "Successfully created a new Format";
            else echo "Ooops! something went wrong."; 
        break;

        case "format_update": 
            $format->set_format_credential("format_id",$_POST["format_id"]);
            $format->set_format_credential("format",$_POST["format"]);
            $format->set_format_credential("description",$_POST["description"]);
            $format->set_format_credential("remarks",$_POST["remarks"]);
            $format->set_format_credential("date_added",$_POST["date_added"]);
            $format->set_format_credential("status",$_POST["status"]);

        if($format->startupdateformat()) echo "Successfully updated the Format number " . $_POST["format_id"];
            else echo "Ooops! something went wrong."; 
        break;

        case "format_find": 
            ob_start();

            if($_POST["key"]!=""){
            $format = new Format();
            $format->startfindformat($_POST["key"]);
            $format_all = $format->get_format_credential("all");

            if($format_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($format_all["format_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $format_all["format_id"][$r] ?></th>
                       
                        <td>
                            <?php echo $format_all["format"][$r];?><br>
                            </td>
                            <td><?php echo $format_all["description"][$r]; ?></td>
                            <td><?php echo $format_all["remarks"][$r]; ?></td>
                            <td><?php echo $format_all["date_added"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success format-record-table-row" data-toggle="modal" data-target="#updateformatmodal" data-formatdata='{ 
                            "format_id" : "<?php echo $format_all["format_id"][$r] ?>",
                            "format" : "<?php echo $format_all["format"][$r] ?>",
                            "description" : "<?php echo $format_all["description"][$r] ?>",    
                            "remarks" : "<?php echo $format_all["remarks"][$r] ?>",
                            "date_added" : "<?php echo $format_all["date_added"][$r]?>" }'><i class="fa fa-edit"></i> UPDATE </button>
                        </td>
                         <td>
                            <button class="btn btn-info format-record-table-row-views" data-toggle="modal" data-target="#format1-<?php echo $format_all["format_id"][$r]; ?>"><i class="fa fa-eye"></i> VIEW 
                          </button>
                      </td>
                            <td>
                                <?php
                                    if ($format_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                            
        <!--View Modal -->
        <td>
        <?php echo $format_all["format_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="format1-<?php echo $format_all["format_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fas fa-glasses"></i> Class Format View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Class Format ID </th>
                            <th><i class="fas fa-pen-alt"></i>  Class Format  </th>
                            <th><i class="fas fa-pen-alt"></i> Description </th></tr>
                            <td style="border:0px;"><?php echo $format_all["format_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $format_all["format"][$r];?></td>
                            <td style="border:0px;"><?php echo $format_all["description"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i>  Remarks </th>
                            <th><i class="far fa-calendar-alt"></i> Date Added </th></tr>
                            <td style="border:0px;"><?php echo $format_all["remarks"][$r];?></td>
                            <td style="border:0px;"><?php echo $format_all["date_added"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"> 
                              <?php
                                    if ($format_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
        <!--View Modal -->
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{

            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';
        }
            echo ob_get_clean();
        break;


        case "topic_create": 
            $topic->set_topic_credential("topic",$_POST["topic"]);
            $topic->set_topic_credential("description",$_POST["description"]);
            $topic->set_topic_credential("remarks",$_POST["remarks"]);
            $topic->set_topic_credential("date_added",$_POST["date_added"]);
            $topic->set_topic_credential("status",$_POST["status"]);
            
            if($topic->startcreatetopic()) echo "Successfully created a new Topic";
            else echo "Ooops! something went wrong."; 
        break;

        case "topic_update": 
            $topic->set_topic_credential("topic_id",$_POST["topic_id"]);
            $topic->set_topic_credential("topic",$_POST["topic"]);
            $topic->set_topic_credential("description",$_POST["description"]);
            $topic->set_topic_credential("remarks",$_POST["remarks"]);
            $topic->set_topic_credential("date_added",$_POST["date_added"]);
            $topic->set_topic_credential("status",$_POST["status"]);

        if($topic->startupdatetopic()) echo "Successfully updated the Topic number " . $_POST["topic_id"];
            else echo "Ooops! something went wrong."; 
        break;

        case "topic_find": 
            ob_start();

            if($_POST["key"]!=""){
            $topic = new Topic();
            $topic->startfindtopic($_POST["key"]);
            $topic_all = $topic->get_topic_credential("all");

            if($topic_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($topic_all["topic_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $topic_all["topic_id"][$r] ?></th>
                       
                        <td>
                            <?php echo $topic_all["topic"][$r];?><br>
                            </td>
                            <td><?php echo $topic_all["description"][$r]; ?></td>
                            <td><?php echo $topic_all["remarks"][$r]; ?></td>
                            <td><?php echo $topic_all["date_added"][$r]; ?></td>
                        <td>
                            <button class="btn btn-success topic-record-table-row" data-toggle="modal" data-target="#updatetopicmodal" data-topicdata='{ 
                            "topic_id" : "<?php echo $topic_all["topic_id"][$r] ?>",
                            "topic" : "<?php echo $topic_all["topic"][$r] ?>",
                            "description" : "<?php echo $topic_all["description"][$r] ?>",    
                            "remarks" : "<?php echo $topic_all["remarks"][$r] ?>",
                            "date_added" : "<?php echo $topic_all["date_added"][$r]?>" }'><i class="fa fa-edit"></i> UPDATE </button>
                        </td>
                         <td>
                            <button class="btn btn-info topic-record-table-row-views" data-toggle="modal" data-target="#topic1-<?php echo $topic_all["topic_id"][$r]; ?>"><i class="fa fa-eye"></i> VIEW 
                          </button>
                      </td>
                            <td>
                                <?php
                                    if ($topic_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                            
        <!--View Modal -->
        <td>
        <?php echo $topic_all["topic_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="topic1-<?php echo $topic_all["topic_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fab fa-cloudversify"></i> Topic View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Topic ID </th>
                            <th><i class="fas fa-pen-alt"></i>  Topic  </th>
                            <th><i class="fas fa-pen-alt"></i> Description </th></tr>
                            <td style="border:0px;"><?php echo $topic_all["topic_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $topic_all["topic"][$r];?></td>
                            <td style="border:0px;"><?php echo $topic_all["description"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i>  Remarks </th>
                            <th><i class="far fa-calendar-alt"></i> Date Added </th></tr>
                            <td style="border:0px;"><?php echo $topic_all["remarks"][$r];?></td>
                            <td style="border:0px;"><?php echo $topic_all["date_added"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="fa fa-check-circle"></i> Status</th></tr>
                            <td style="border:0px;"> 
                              <?php
                                    if ($topic_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
        <!--View Modal -->
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{

            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';
        }
            echo ob_get_clean();
        break;

         case "course_create": 
            $course->set_course_credential("coursecode_id",$_POST["coursecode_id"]);
            $course->set_course_credential("areacode_id",$_POST["areacode_id"]);
            $course->set_course_credential("coursetitle_id",$_POST["coursetitle_id"]);
            $course->set_course_credential("unit_id",$_POST["unit_id"]);
            $course->set_course_credential("teacher_id",$_POST["teacher_id"]);
            $course->set_course_credential("remarks",$_POST["remarks"]);
            $course->set_course_credential("date_added",$_POST["date_added"]);
            $course->set_course_credential("approval",$_POST["approval"]);
            $course->set_course_credential("status",$_POST["status"]);
            
            if($course->startcreatecourse()) echo "Successfully created a new Course";
            else echo "Ooops! something went wrong."; 
        break;

        case "course_update": 
            $course->set_course_credential("course_id",$_POST["course_id"]);
            $course->set_course_credential("coursecode_id",$_POST["coursecode_id"]);
            $course->set_course_credential("areacode_id",$_POST["areacode_id"]);
            $course->set_course_credential("coursetitle_id",$_POST["coursetitle_id"]);
            $course->set_course_credential("unit_id",$_POST["unit_id"]);
            $course->set_course_credential("teacher_id",$_POST["teacher_id"]);
            $course->set_course_credential("remarks",$_POST["remarks"]);
            $course->set_course_credential("date_added",$_POST["date_added"]);
            $course->set_course_credential("approval",$_POST["approval"]);
            $course->set_course_credential("status",$_POST["status"]);

        if($course->startupdatecourse()) echo "Successfully updated the Course number " . $_POST["course_id"];
            else echo "Ooops! something went wrong."; 
        break;

         case "coursebystatus_update": 
            $course->set_course_credential("course_id",$_POST["course_id"]);
            $course->set_course_credential("coursecode_id",$_POST["coursecode_id"]);
            $course->set_course_credential("teacher_id",$_POST["teacher_id"]);
            $course->set_course_credential("approval",$_POST["approval"]);
            $course->set_course_credential("status",$_POST["status"]);

        if($course->startupdatecoursebystatus()) echo "Successfully updated the Course by status number " . $_POST["course_id"];
            else echo "Ooops! something went wrong."; 
        break;

        case "course_find": 
            ob_start();

            if($_POST["key"]!=""){
            $course = new Course();
            $course->startfindcourse($_POST["key"]);
            $course_all = $course->get_course_credential("all");

            if($course_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($course_all["course_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $course_all["course_id"][$r] ?></th>
                       
                         <td>
                                 <?php
                                     $coursecode = new Coursecode();
                                     $coursecode->startreadcoursecode();

                                     $coursecode_all = $coursecode->get_coursecode_credential("all");

                                     if($coursecode_all !== null) {
                                        for( $j=0; $j < count($coursecode_all["coursecode_id"]); $j++ ) {
                                            if($course_all["coursecode_id"][$r] == $coursecode_all["coursecode_id"][$j]) echo $coursecode_all["coursecode"][$j];
                                                    }
                                                } else {
                                                    echo 'coursecode_id: ' . $coursecode_all["coursecode_id"][$r];
                                                }
                                ?>  
                            </td>
                            <td>
                                 <?php
                                     $areacode = new Areacode();
                                     $areacode->startreadareacode();

                                     $areacode_all = $areacode->get_areacode_credential("all");

                                     if($areacode_all !== null) {
                                        for( $j=0; $j < count($areacode_all["areacode_id"]); $j++ ) {
                                            if($course_all["areacode_id"][$r] == $areacode_all["areacode_id"][$j]) echo $areacode_all["areacode"][$j];
                                                    }
                                                } else {
                                                    echo 'areacode_id: ' . $areacode_all["areacode_id"][$r];
                                                }
                                    ?> 
                            </td>
                            <td>
                                <?php
                                     $teacher = new Teacher();
                                     $teacher->startreadteacher();

                                     $teacher_all = $teacher->get_teacher_credential("all");

                                     if($teacher_all !== null) {
                                        for( $j=0; $j < count($teacher_all["teacher_id"]); $j++ ) {
                                            if($course_all["teacher_id"][$r] == $teacher_all["teacher_id"][$j]) echo $teacher_all["lname"][$j].','.$teacher_all["fname"][$j].' '.$teacher_all["mname"][$j];
                                                    }
                                                } else {
                                                    echo 'teacher_id: ' . $teacher_all["teacher_id"][$r];
                                                }
                                ?>
                            </td>

                         <td>
                            <button class="btn btn-white course-record-table-row" data-toggle="modal" data-target="#updatecoursemodal" data-coursedata ='{ 
                            "course_id" : "<?php echo $course_all["course_id"][$r] ?>",
                            "coursecode_id" : "<?php echo $course_all["coursecode_id"][$r] ?>",
                            "areacode_id" : "<?php echo $course_all["areacode_id"][$r] ?>",
                            "coursetitle_id" : "<?php echo $course_all["coursetitle_id"][$r] ?>",
                            "unit_id" : "<?php echo $course_all["unit_id"][$r] ?>",
                            "teacher_id" : "<?php echo $course_all["teacher_id"][$r] ?>",
                            "remarks" : "<?php echo $course_all["remarks"][$r] ?>", 
                            "date_added" : "<?php echo $course_all["date_added"][$r] ?>",
                            "approval" : "<?php echo $course_all["approval"][$r] ?>",
                            "status" : "<?php echo $course_all["status"][$r] ?>" }'><i class="fas fa-recycle" style="color:#48C9B0;"></i> </button>
                            </td>

                            <td>
                              <button class="btn btn-white course-record-table-row-view" data-toggle="modal" data-target="#course1-<?php echo $course_all["course_id"][$r]; ?>"><i class="fa fa-eye" style="color:#AF7AC5;"></i>  
                              </button>
                           </td>

                            <td>
                               <?php
                                    if ($course_all["approval"][$r] == "2") 
                                        echo '<span class="badge badge-success" style="background-color:#F5B041;"><i class="fas fa-hourglass-half"></i> Pending </span>';
                                    
                                    else if ($course_all["approval"][$r] == "1") 
                                     echo '<span class="badge badge-danger" style="background-color:#76D7C4;"><i class="far fa-thumbs-up"></i> Confirm </span>';
                                
                                    else echo '<span class="badge badge-danger" style="background-color:#F1948A;"><i class="far fa-thumbs-down"></i> Cancel </span>';
                                
                                ?>
                           </td>
                            <td>
                                <?php
                                    if ($course_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                            
        <!--View Modal -->
     <td>
        <?php echo $course_all["course_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="course1-<?php echo $course_all["course_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fas fa-chalkboard-teacher"></i> Course View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Course ID </th>
                            <th><i class="fas fa-pen-alt"></i> Course Code </th>
                            <th><i class="fas fa-pen-alt"></i> Area Code  </th>
                            <th><i class="fas fa-pen-alt"></i> Course Title  </th></tr>
                            <td style="border:0px;"><?php echo $course_all["course_id"][$r];?></td>
                            <td style="border:0px;">
                                    <?php
                                     $coursecode = new Coursecode();
                                     $coursecode->startreadcoursecode();

                                     $coursecode_all = $coursecode->get_coursecode_credential("all");

                                     if($coursecode_all !== null) {
                                        for( $j=0; $j < count($coursecode_all["coursecode_id"]); $j++ ) {
                                            if($course_all["coursecode_id"][$r] == $coursecode_all["coursecode_id"][$j]) echo $coursecode_all["coursecode"][$j];
                                                    }
                                                } else {
                                                    echo 'coursecode_id: ' . $coursecode_all["coursecode_id"][$r];
                                                }
                                        ?>
                            </td>
                            <td style="border:0px;">
                                   <?php
                                     $areacode = new Areacode();
                                     $areacode->startreadareacode();

                                     $areacode_all = $areacode->get_areacode_credential("all");

                                     if($areacode_all !== null) {
                                        for( $j=0; $j < count($areacode_all["areacode_id"]); $j++ ) {
                                            if($course_all["areacode_id"][$r] == $areacode_all["areacode_id"][$j]) echo $areacode_all["areacode"][$j];
                                                    }
                                                } else {
                                                    echo 'areacode_id: ' . $areacode_all["areacode_id"][$r];
                                                }
                                    ?> 
                             </td>
                             <td style="border:0px;">
                                  <?php
                                     $coursetitle = new Coursetitle();
                                     $coursetitle->startreadcoursetitle();

                                     $coursetitle_all = $coursetitle->get_coursetitle_credential("all");

                                     if($coursetitle_all !== null) {
                                        for( $j=0; $j < count($coursetitle_all["coursetitle_id"]); $j++ ) {
                                            if($course_all["coursetitle_id"][$r] == $coursetitle_all["coursetitle_id"][$j]) echo $coursetitle_all["coursetitle"][$j];
                                                    }
                                                } else {
                                                    echo 'coursetitle_id: ' . $coursetitle_all["coursetitle_id"][$r];
                                                }
                                ?>
                             </td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i>  Unit </th>
                            <th><i class="fa fa-user-tie"></i> Teacher </th>
                            <th><i class="fas fa-pen-alt"></i> Remarks </th></tr>
                            <td style="border:0px;">
                                    <?php
                                     $unit = new Unit();
                                     $unit->startreadunit();

                                     $unit_all = $unit->get_unit_credential("all");

                                     if($unit_all !== null) {
                                        for( $j=0; $j < count($unit_all["unit_id"]); $j++ ) {
                                            if($course_all["unit_id"][$r] == $unit_all["unit_id"][$j]) echo $unit_all["unit"][$j];
                                                    }
                                                } else {
                                                    echo 'unit_id: ' . $unit_all["unit_id"][$r];
                                                }
                                    ?> 
                            </td>
                            <td style="border:0px;">
                                    <?php
                                     $teacher = new Teacher();
                                     $teacher->startreadteacher();

                                     $teacher_all = $teacher->get_teacher_credential("all");

                                     if($teacher_all !== null) {
                                        for( $j=0; $j < count($teacher_all["teacher_id"]); $j++ ) {
                                            if($course_all["teacher_id"][$r] == $teacher_all["teacher_id"][$j]) 
                                                echo $teacher_all["lname"][$j].' , '.$teacher_all["fname"][$j].' '.$teacher_all["mname"][$j];
                                                    }
                                                } else {
                                                    echo 'teacher_id: ' . $teacher_all["teacher_id"][$r];
                                                }
                                        ?>
                                </td>
                                <td style="border:0px;"><?php echo $course_all["remarks"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="far fa-calendar-alt"></i> Date Created</th>
                            <th><i class="fas fa-pen-alt"></i> Apporval </th>
                            <th><i class="fas fa-pen-alt"></i> Status </th></tr>
                            <td style="border:0px;"><?php echo $course_all["date_added"][$r];?></td>
                            <td style="border:0px;"><?php 
                             if ($course_all["approval"][$r] == "2") 
                                        echo '<span class="badge badge-success" style="background-color:#F5B041;"><i class="fas fa-hourglass-half"></i> Pending </span>';
                                    
                                    else if ($course_all["approval"][$r] == "1") 
                                     echo '<span class="badge badge-danger" style="background-color:#76D7C4;"><i class="far fa-thumbs-up"></i> Confirm </span>';
                                
                                    else echo '<span class="badge badge-danger" style="background-color:#F1948A;"><i class="far fa-thumbs-down"></i> Cancel </span>';
                                    ?>
                            </td>
                            <td style="border:0px;"> 
                              <?php
                                    if ($course_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;"><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
        <!--View Modal -->
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{

            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';
        }
            echo ob_get_clean();
        break;

         case "recordcourse_find": 
            ob_start();

            if($_POST["key"]!=""){
            $course = new Course();
            $course->startfindcourse($_POST["key"]);
            $course_all = $course->get_course_credential("all");

            if($course_all !== null) {
                $noresult = true;
                for( $r=0; $r < count($course_all["course_id"]); $r++ ) {
                    $noresult = false;
                    ?>
                    <tr>
                        <th scope="row"><?php echo $course_all["course_id"][$r] ?></th>
                        <td>
                            <button class="btn btn-white course-record-table-row-by-status" data-toggle="modal" data-target="#updatecoursebystatusmodal" data-recordcoursedata ='{ 
                            "course_id" : "<?php echo $course_all["course_id"][$r] ?>",
                            "coursecode_id" : "<?php echo $course_all["coursecode_id"][$r] ?>",
                            "teacher_id" : "<?php echo $course_all["teacher_id"][$r] ?>",
                            "approval" : "<?php echo $course_all["approval"][$r] ?>",
                            "status" : "<?php echo $course_all["status"][$r] ?>" }'><i class="fas fa-edit" style="color:#5D6D7E;"></i> </button>
                            </td>

                            <td>
                              <button class="btn btn-white course-record-table-row-view" data-toggle="modal" data-target="#recordcourse1-<?php echo $course_all["course_id"][$r]; ?>"><i class="fa fa-eye" style="color:#5D6D7E;"></i>  
                              </button>
                           </td>
                         <td>
                                 <?php
                                     $coursecode = new Coursecode();
                                     $coursecode->startreadcoursecode();

                                     $coursecode_all = $coursecode->get_coursecode_credential("all");

                                     if($coursecode_all !== null) {
                                        for( $j=0; $j < count($coursecode_all["coursecode_id"]); $j++ ) {
                                            if($course_all["coursecode_id"][$r] == $coursecode_all["coursecode_id"][$j]) echo $coursecode_all["coursecode"][$j];
                                                    }
                                                } else {
                                                    echo 'coursecode_id: ' . $coursecode_all["coursecode_id"][$r];
                                                }
                                ?>  
                            </td>
                            <td>
                                <?php
                                     $teacher = new Teacher();
                                     $teacher->startreadteacher();

                                     $teacher_all = $teacher->get_teacher_credential("all");

                                     if($teacher_all !== null) {
                                        for( $j=0; $j < count($teacher_all["teacher_id"]); $j++ ) {
                                            if($course_all["teacher_id"][$r] == $teacher_all["teacher_id"][$j]) echo $teacher_all["lname"][$j].','.$teacher_all["fname"][$j].' '.$teacher_all["mname"][$j];
                                                    }
                                                } else {
                                                    echo 'teacher_id: ' . $teacher_all["teacher_id"][$r];
                                                }
                                ?>
                            </td>
                              <td>
                               <?php
                                    if ($course_all["approval"][$r] == "2") 
                                        echo '<span class="badge badge-success" style="background-color:#F5B041;"><i class="fas fa-hourglass-half"></i> Pending </span>';
                                    
                                    else if ($course_all["approval"][$r] == "1") 
                                     echo '<span class="badge badge-danger" style="background-color:#76D7C4;"><i class="far fa-thumbs-up"></i> Confirm </span>';
                                
                                    else echo '<span class="badge badge-danger" style="background-color:#F1948A;"><i class="far fa-thumbs-down"></i> Cancel </span>';
                                
                                ?>
                           </td>
                            <td>
                                <?php
                                    if ($course_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                            
        <!--View Modal -->
         <td>
        <?php echo $course_all["course_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="recordcourse1-<?php echo $course_all["course_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fas fa-book-reader"></i> Record Course View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Course ID </th>
                            <th><i class="fas fa-pen-alt"></i> Course Code </th>
                            <th><i class="fas fa-pen-alt"></i> Area Code  </th>
                            <th><i class="fas fa-pen-alt"></i> Course Title  </th></tr>
                            <td style="border:0px;"><?php echo $course_all["course_id"][$r];?></td>
                            <td style="border:0px;">
                                    <?php
                                     $coursecode = new Coursecode();
                                     $coursecode->startreadcoursecode();

                                     $coursecode_all = $coursecode->get_coursecode_credential("all");

                                     if($coursecode_all !== null) {
                                        for( $j=0; $j < count($coursecode_all["coursecode_id"]); $j++ ) {
                                            if($course_all["coursecode_id"][$r] == $coursecode_all["coursecode_id"][$j]) echo $coursecode_all["coursecode"][$j];
                                                    }
                                                } else {
                                                    echo 'coursecode_id: ' . $coursecode_all["coursecode_id"][$r];
                                                }
                                        ?>
                            </td>
                            <td style="border:0px;">
                                   <?php
                                     $areacode = new Areacode();
                                     $areacode->startreadareacode();

                                     $areacode_all = $areacode->get_areacode_credential("all");

                                     if($areacode_all !== null) {
                                        for( $j=0; $j < count($areacode_all["areacode_id"]); $j++ ) {
                                            if($course_all["areacode_id"][$r] == $areacode_all["areacode_id"][$j]) echo $areacode_all["areacode"][$j];
                                                    }
                                                } else {
                                                    echo 'areacode_id: ' . $areacode_all["areacode_id"][$r];
                                                }
                                    ?> 
                             </td>
                             <td style="border:0px;">
                                  <?php
                                     $coursetitle = new Coursetitle();
                                     $coursetitle->startreadcoursetitle();

                                     $coursetitle_all = $coursetitle->get_coursetitle_credential("all");

                                     if($coursetitle_all !== null) {
                                        for( $j=0; $j < count($coursetitle_all["coursetitle_id"]); $j++ ) {
                                            if($course_all["coursetitle_id"][$r] == $coursetitle_all["coursetitle_id"][$j]) echo $coursetitle_all["coursetitle"][$j];
                                                    }
                                                } else {
                                                    echo 'coursetitle_id: ' . $coursetitle_all["coursetitle_id"][$r];
                                                }
                                ?>
                             </td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i>  Unit </th>
                            <th><i class="fa fa-user-tie"></i> Teacher </th>
                            <th><i class="fas fa-pen-alt"></i> Remarks </th></tr>
                            <td style="border:0px;">
                                    <?php
                                     $unit = new Unit();
                                     $unit->startreadunit();

                                     $unit_all = $unit->get_unit_credential("all");

                                     if($unit_all !== null) {
                                        for( $j=0; $j < count($unit_all["unit_id"]); $j++ ) {
                                            if($course_all["unit_id"][$r] == $unit_all["unit_id"][$j]) echo $unit_all["unit"][$j];
                                                    }
                                                } else {
                                                    echo 'unit_id: ' . $unit_all["unit_id"][$r];
                                                }
                                    ?> 
                            </td>
                            <td style="border:0px;">
                                    <?php
                                     $teacher = new Teacher();
                                     $teacher->startreadteacher();

                                     $teacher_all = $teacher->get_teacher_credential("all");

                                     if($teacher_all !== null) {
                                        for( $j=0; $j < count($teacher_all["teacher_id"]); $j++ ) {
                                            if($course_all["teacher_id"][$r] == $teacher_all["teacher_id"][$j]) 
                                                echo $teacher_all["lname"][$j].' , '.$teacher_all["fname"][$j].' '.$teacher_all["mname"][$j];
                                                    }
                                                } else {
                                                    echo 'teacher_id: ' . $teacher_all["teacher_id"][$r];
                                                }
                                        ?>
                                </td>
                                <td style="border:0px;"><?php echo $course_all["remarks"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="far fa-calendar-alt"></i> Date Created</th>
                            <th><i class="fas fa-pen-alt"></i> Apporval </th>
                            <th><i class="fas fa-pen-alt"></i> Status </th></tr>
                            <td style="border:0px;"><?php echo $course_all["date_added"][$r];?></td>
                            <td style="border:0px;"><?php 
                             if ($course_all["approval"][$r] == "2") 
                                        echo '<span class="badge badge-success" style="background-color:#F5B041;"><i class="fas fa-hourglass-half"></i> Pending </span>';
                                    
                                    else if ($course_all["approval"][$r] == "1") 
                                     echo '<span class="badge badge-danger" style="background-color:#76D7C4;"><i class="far fa-thumbs-up"></i> Confirm </span>';
                                
                                    else echo '<span class="badge badge-danger" style="background-color:#F1948A;"><i class="far fa-thumbs-down"></i> Cancel </span>';
                                    ?>
                            </td>
                            <td style="border:0px;"> 
                              <?php
                                    if ($course_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;"><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
        <!--View Modal -->
                    </tr>
                    <?php
                }
                if($noresult) {
                    ?>
                    <tr>
                        <th scope="row" colspan="10"><center>No matching records found for "<?php echo $_POST["key"]; ?>"</center></th>
                    </tr>
                    <?php
                }
            }
        }
          else{

            echo'<tr><td scope="row" colspan="10"><center>No data available in table</td></tr>';
        }
            echo ob_get_clean();
        break;
       






      }
        ?>    
