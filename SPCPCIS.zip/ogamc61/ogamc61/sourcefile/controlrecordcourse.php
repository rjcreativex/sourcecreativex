<?php 
    include '../sourcefile/functions.php';
?>
<?php 
    include 'themepart/mylinkcss.php';
?>
<?php 
    include 'themepart/admin.php';
?>
<?php 
    include 'themepart/top_menu.php';
?><br>
  <div class="content-wrapper">
    <form class="form-group">
        <div class="col-md-12">
            <div class="card bg-white text-info"> 
        <div class="card-body">
             <h4 class="card-title" style="font-size:20px;"> Record Course <i class="fas fa-book-reader" style="font-size:24px"></i></h4>
             <p class="card-text text-info">Control everything here. Create, Find, Activate and Deactivate Course.</p>
        </div>
        </div>
    </div>
  </form>

<form class="form-control-lg">
          <div class="input-group mb-3">
            <div class="input-group-prepend"  >
              <button class="btn btn-info"><i class="fa fa-search"></i></button>
            </div>
            <input type="text" id="controlrecordcoursemaininput" class="form-control form-control-lg" placeholder="Type anything you search.." style="font-size:14px;">
          </div>
        </form><br>

<section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
            </div>
            <div class="card-body">
              <table id="datatablecourse2" class="table table-hover">
                <thead class="table-light">
                <tr>
                  <th># Course ID</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Course Code</th>
                  <th>Area Code</th>
                  <th>Teacher</th>
                  <th>Approval</th>
                  <th>Status</th>
                  <th># Course ID </th>
                </tr> 
                </thead>
                <tbody id="controlrecordcoursemainoutput">
                <?php
                $course = new Course();
                $course->startreadcourse();
                $course_all = $course->get_course_credential("all");

                if($course_all !== null) {
                    for( $r=0; $r < count($course_all["course_id"]); $r++ ) {
                        ?>
                        <tr>
                            <th scope="row"><?php echo $course_all["course_id"][$r] ?></th>

                            <td>
                            <button class="btn btn-white course-record-table-row-by-status" data-toggle="modal" data-target="#updatecoursebystatusmodal" data-recordcoursedata ='{ 
                            "course_id" : "<?php echo $course_all["course_id"][$r] ?>",
                            "coursecode_id" : "<?php echo $course_all["coursecode_id"][$r] ?>",
                            "teacher_id" : "<?php echo $course_all["teacher_id"][$r] ?>",
                            "approval" : "<?php echo $course_all["approval"][$r] ?>",
                            "status" : "<?php echo $course_all["status"][$r] ?>" }'><i class="fas fa-edit" style="color:#5D6D7E;"></i> </button>
                            </td>

                            <td>
                              <button class="btn btn-white course-record-table-row-view" data-toggle="modal" data-target="#recordcourse1-<?php echo $course_all["course_id"][$r]; ?>"><i class="fa fa-eye" style="color:#5D6D7E;"></i>  
                              </button>
                           </td>
                           
                            <td>
                                 <?php
                                     $coursecode = new Coursecode();
                                     $coursecode->startreadcoursecode();

                                     $coursecode_all = $coursecode->get_coursecode_credential("all");

                                     if($coursecode_all !== null) {
                                        for( $j=0; $j < count($coursecode_all["coursecode_id"]); $j++ ) {
                                            if($course_all["coursecode_id"][$r] == $coursecode_all["coursecode_id"][$j]) echo $coursecode_all["coursecode"][$j];
                                                    }
                                                } else {
                                                    echo 'coursecode_id: ' . $coursecode_all["coursecode_id"][$r];
                                                }
                                ?>  
                            </td>
                            <td>
                                 <?php
                                     $areacode = new Areacode();
                                     $areacode->startreadareacode();

                                     $areacode_all = $areacode->get_areacode_credential("all");

                                     if($areacode_all !== null) {
                                        for( $j=0; $j < count($areacode_all["areacode_id"]); $j++ ) {
                                            if($course_all["areacode_id"][$r] == $areacode_all["areacode_id"][$j]) echo $areacode_all["areacode"][$j];
                                                    }
                                                } else {
                                                    echo 'areacode_id: ' . $areacode_all["areacode_id"][$r];
                                                }
                                    ?> 
                            </td>
                            <td>
                                <?php
                                     $teacher = new Teacher();
                                     $teacher->startreadteacher();

                                     $teacher_all = $teacher->get_teacher_credential("all");

                                     if($teacher_all !== null) {
                                        for( $j=0; $j < count($teacher_all["teacher_id"]); $j++ ) {
                                            if($course_all["teacher_id"][$r] == $teacher_all["teacher_id"][$j]) echo $teacher_all["lname"][$j].' , '.$teacher_all["fname"][$j].' '.$teacher_all["mname"][$j];
                                                    }
                                                } else {
                                                    echo 'teacher_id: ' . $teacher_all["teacher_id"][$r];
                                                }
                                ?>
                            </td>
                           
                           <td>
                               <?php
                                    if ($course_all["approval"][$r] == "2") 
                                        echo '<span class="badge badge-success" style="background-color:#F5B041;"><i class="fas fa-hourglass-half"></i> Pending </span>';
                                    
                                    else if ($course_all["approval"][$r] == "1") 
                                     echo '<span class="badge badge-danger" style="background-color:#76D7C4;"><i class="far fa-thumbs-up"></i> Confirm </span>';
                                
                                    else echo '<span class="badge badge-danger" style="background-color:#F1948A;"><i class="far fa-thumbs-down"></i> Cancel </span>';
                                
                                ?>
                           </td>
                            <td>
                                <?php
                                    if ($course_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;" ><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
        <!--View Modal -->
        <td>
        <?php echo $course_all["course_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="recordcourse1-<?php echo $course_all["course_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fas fa-book-reader"></i> Record Course View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Course ID </th>
                            <th><i class="fas fa-pen-alt"></i> Course Code </th>
                            <th><i class="fas fa-pen-alt"></i> Area Code  </th>
                            <th><i class="fas fa-pen-alt"></i> Course Title  </th></tr>
                            <td style="border:0px;"><?php echo $course_all["course_id"][$r];?></td>
                            <td style="border:0px;">
                                    <?php
                                     $coursecode = new Coursecode();
                                     $coursecode->startreadcoursecode();

                                     $coursecode_all = $coursecode->get_coursecode_credential("all");

                                     if($coursecode_all !== null) {
                                        for( $j=0; $j < count($coursecode_all["coursecode_id"]); $j++ ) {
                                            if($course_all["coursecode_id"][$r] == $coursecode_all["coursecode_id"][$j]) echo $coursecode_all["coursecode"][$j];
                                                    }
                                                } else {
                                                    echo 'coursecode_id: ' . $coursecode_all["coursecode_id"][$r];
                                                }
                                        ?>
                            </td>
                            <td style="border:0px;">
                                   <?php
                                     $areacode = new Areacode();
                                     $areacode->startreadareacode();

                                     $areacode_all = $areacode->get_areacode_credential("all");

                                     if($areacode_all !== null) {
                                        for( $j=0; $j < count($areacode_all["areacode_id"]); $j++ ) {
                                            if($course_all["areacode_id"][$r] == $areacode_all["areacode_id"][$j]) echo $areacode_all["areacode"][$j];
                                                    }
                                                } else {
                                                    echo 'areacode_id: ' . $areacode_all["areacode_id"][$r];
                                                }
                                    ?> 
                             </td>
                             <td style="border:0px;">
                                  <?php
                                     $coursetitle = new Coursetitle();
                                     $coursetitle->startreadcoursetitle();

                                     $coursetitle_all = $coursetitle->get_coursetitle_credential("all");

                                     if($coursetitle_all !== null) {
                                        for( $j=0; $j < count($coursetitle_all["coursetitle_id"]); $j++ ) {
                                            if($course_all["coursetitle_id"][$r] == $coursetitle_all["coursetitle_id"][$j]) echo $coursetitle_all["coursetitle"][$j];
                                                    }
                                                } else {
                                                    echo 'coursetitle_id: ' . $coursetitle_all["coursetitle_id"][$r];
                                                }
                                ?>
                             </td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fas fa-pen-alt"></i>  Unit </th>
                            <th><i class="fa fa-user-tie"></i> Teacher </th>
                            <th><i class="fas fa-pen-alt"></i> Remarks </th></tr>
                            <td style="border:0px;">
                                    <?php
                                     $unit = new Unit();
                                     $unit->startreadunit();

                                     $unit_all = $unit->get_unit_credential("all");

                                     if($unit_all !== null) {
                                        for( $j=0; $j < count($unit_all["unit_id"]); $j++ ) {
                                            if($course_all["unit_id"][$r] == $unit_all["unit_id"][$j]) echo $unit_all["unit"][$j];
                                                    }
                                                } else {
                                                    echo 'unit_id: ' . $unit_all["unit_id"][$r];
                                                }
                                    ?> 
                            </td>
                            <td style="border:0px;">
                                    <?php
                                     $teacher = new Teacher();
                                     $teacher->startreadteacher();

                                     $teacher_all = $teacher->get_teacher_credential("all");

                                     if($teacher_all !== null) {
                                        for( $j=0; $j < count($teacher_all["teacher_id"]); $j++ ) {
                                            if($course_all["teacher_id"][$r] == $teacher_all["teacher_id"][$j]) 
                                                echo $teacher_all["lname"][$j].' , '.$teacher_all["fname"][$j].' '.$teacher_all["mname"][$j];
                                                    }
                                                } else {
                                                    echo 'teacher_id: ' . $teacher_all["teacher_id"][$r];
                                                }
                                        ?>
                                </td>
                                <td style="border:0px;"><?php echo $course_all["remarks"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr>
                            <th><i class="far fa-calendar-alt"></i> Date Created</th>
                            <th><i class="fas fa-pen-alt"></i> Apporval </th>
                            <th><i class="fas fa-pen-alt"></i> Status </th></tr>
                            <td style="border:0px;"><?php echo $course_all["date_added"][$r];?></td>
                            <td style="border:0px;"><?php 
                             if ($course_all["approval"][$r] == "2") 
                                        echo '<span class="badge badge-success" style="background-color:#F5B041;"><i class="fas fa-hourglass-half"></i> Pending </span>';
                                    
                                    else if ($course_all["approval"][$r] == "1") 
                                     echo '<span class="badge badge-danger" style="background-color:#76D7C4;"><i class="far fa-thumbs-up"></i> Confirm </span>';
                                
                                    else echo '<span class="badge badge-danger" style="background-color:#F1948A;"><i class="far fa-thumbs-down"></i> Cancel </span>';
                                    ?>
                            </td>
                            <td style="border:0px;"> 
                              <?php
                                    if ($course_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#66CDAA;"><i class="fas fa-lock-open"></i> Open </span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#FA8072;"><i class="fas fa-lock"></i> Close </span>';
                                ?>
                            </td>
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
        <!--View Modal -->
                        </tr>
                        <?php
                    }
                }
            ?> 
                </tbody id="controlcoursemainoutput">
                <tfoot class="table-light">
                <tr>
                  <th># Course ID</th>
                  <th>Action</th>
                  <th>View</th>
                  <th>Course Code</th>
                  <th>Area Code</th>
                  <th>Teacher</th>
                  <th>Approval</th>
                  <th>Status</th>
                  <th># Course ID </th>
                </tr>
                </tfoot>
              </table>
            </div>
          </div>

        </div>
      </div>
    </section>
   
   <div class="modal_container">
    <div class="modal fade" id="updatecoursebystatusmodal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fas fa-book-reader"></i> Record Course Update </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>

                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: code is always unique.</small>
                        <input type="hidden" id="updatecoursebystatusmodal_course_id">
                    </div>

        <div class="form-group">
                 <div class="row">
                    <div class="col-6">
                      <i class="fas fa-pen-alt"></i>
                        <label class="text-sm"> Coursecode </label>
                        <?php 
                            $coursecode = new Coursecode();
                            $coursecode->startreadcoursecode();

                            $coursecode_all = $coursecode->get_coursecode_credential("all");

                            if($coursecode_all !== null) {
                                ?>
                    <select class="form-control form-control-md" id="updatecoursebystatusmodal_coursecode_id" disabled="true">
                                <?php
                                for( $r=0; $r < count($coursecode_all["coursecode_id"]); $r++ ) {
                                    ?>
             <option value="<?php echo $coursecode_all["coursecode_id"][$r] ?>"><?php echo $coursecode_all["coursecode"][$r]?></option>
                                    <?php
                                }
                                ?>
                                </select>
                                <?php
                            }
                        ?>
                    </div>
                     <div class="col-6">
                      <i class="fa fa-user-tie"></i>
                        <label class="text-sm"> Teacher </label>
                        <?php 
                            $teacher = new Teacher();
                            $teacher->startreadteacher();

                            $teacher_all = $teacher->get_teacher_credential("all");

                            if($teacher_all !== null) {
                                ?>
                    <select class="form-control form-control-md" id="updatecoursebystatusmodal_teacher_id" disabled="true">
                                <?php
                                for( $j=0; $j < count($teacher_all["teacher_id"]); $j++ ) {
                                    ?>
             <option value="<?php echo $teacher_all["teacher_id"][$j] ?>"><?php echo $teacher_all["lname"][$j].','.$teacher_all["fname"][$j].' '.$teacher_all["mname"][$j]; ?></option>
                                    <?php
                                }
                                ?>
                                </select>
                                <?php
                            }
                        ?>
                </div>
                </div>
            </div>


                <div class="form-group">
                  <div class="row">
                    <div class="col-4">
                        <i class="fas fa-pen-alt"></i>
                          <label class="text">Approval</label>
                            <select class="custom-select form-control-md" id="updatecoursebystatusmodal_approval">
                                <option value="1">Confirm</option>
                                <option value="2">Pending</option>
                                <option value="0">Cancel</option>
                            </select>
                     </div>

                     <div class="col-4">
                        <i class="fas fa-pen-alt"></i>
                          <label class="text">Status</label>
                            <select class="custom-select form-control-md" id="updatecoursebystatusmodal_status" disabled="true">
                                <option value="1">Open</option>
                                <option value="0">Close</option>
                            </select>
                     </div>
                  </div>
                </div>
          
                
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-success" id="updatecoursebystatusmodalbutton">
                    <i class="fa fa-save"></i> Save Changes </button>
                </div>
            </div>
        </div>
    </div>
</div>

</div>

<?php 
    include 'themepart/bottom.php';
?>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/coordinatorlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function() {
    $("#datatablecoordinatoracc").DataTable();
    $('#datatablecoordinator2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

</body>
</html>


