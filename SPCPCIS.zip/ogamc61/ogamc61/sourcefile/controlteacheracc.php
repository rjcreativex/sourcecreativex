<?php 
    include '../sourcefile/functions.php';
?>
<?php 
    include 'themepart/mylinkcss.php';
?>
<?php 
    include 'themepart/admin.php';
?>
<?php 
    include 'themepart/top_menu.php';
?><br>
  <div class="content-wrapper">
    <form class="form-group">
        <div class="col-md-12">
            <div class="card bg-white text-info"> 
        <div class="card-body">
             <h4 class="card-title" style="font-size:20px;"> Teacher <i class="fa fa-user-tie" style="font-size:24px"></i></h4>
             <p class="card-text text-info">Control everything here. Create, Find, Activate and Deactivate Teacher.</p>
        </div>
        </div>
    </div>
  </form>

  <section class="content">
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
            </div>
            <div class="card-body">
              <table id="datatableteacheracc" class="table table-hover">
                <thead class="table-light">
                <tr>
                  <th># Teacher ID</th>
                  <th>Fullname</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Code</th>
                  <th>Pass</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Teacher ID</th>
                </tr>
                </thead>
                <tbody id="controlteachermainoutputacc">
                <?php
                $teacher = new Teacher();
                $teacher->startreadteacher();
                $teacher_all = $teacher->get_teacher_credential("all");

                if($teacher_all !== null) {
                    for( $r=0; $r < count($teacher_all["teacher_id"]); $r++ ) {
                        ?>
                        <tr>
                            <th scope="row"><?php echo $teacher_all["teacher_id"][$r] ?></th>
                        <td><?php echo $teacher_all["lname"][$r] .' , '. $teacher_all["fname"][$r] .' '. $teacher_all["mname"][$r]; ?></td>
                        <td><?php echo $teacher_all["contact"][$r]; ?></td>
                        <td><?php echo $teacher_all["email"][$r]; ?></td>
                        <td><?php echo $teacher_all["code"][$r]; ?></td>
                        <td><?php echo $teacher_all["pass"][$r]; ?></td>
                           <td>
                            <button class="btn btn-info btn-sm teacher-record-table-row-view" data-target="#teacheracc1-<?php echo $teacher_all["teacher_id"][$r]; ?>" data-toggle="modal"><i class="fas fa-eye"></i> View </button>
                          </td>
                            <td>
                                <?php
                                    if ($teacher_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
        <td>
        <?php echo $teacher_all["teacher_id"][$r];?>
        <div class="modal fade" tabindex="-1" id="teacheracc1-<?php echo $teacher_all["teacher_id"][$r]; ?>" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h6 class="modal-title"><i class="fa fa-user-tie"></i> Teacher View </h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <small class="form-text text-muted">*advisory: Teacher code is always unique.</small>
                    </div>
                     <table class="table">
                            <tr><th># Teacher ID</th>
                            <th><i class="fas fa-pen-alt"></i> Fullname </th>
                            <th><i class="fa fa-phone-square"></i> Contact </th>
                            <th><i class="fa fa-envelope-square"></i> Email </th></tr>
                            <td style="border:0px;"><?php echo $teacher_all["teacher_id"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["lname"][$r] .' , '. $teacher_all["fname"][$r] .' '. $teacher_all["mname"][$r]; ?></td>
                            <td style="border:0px;"><?php echo $teacher_all["contact"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["email"][$r];?></td>
                    </table>
                    <table class="table">
                            <tr><th><i class="fa fa-id-card"></i> Code </th>
                            <th><i class="fa fa-eye-slash"></i> Pass </th>
                            <th><i class="fa fa-check-circle"></i> Status </th>
                            </tr>
                            <td style="border:0px;"><?php echo $teacher_all["code"][$r];?></td>
                            <td style="border:0px;"><?php echo $teacher_all["pass"][$r];?></td>
                            <td style="border:0px;"> 
                             <?php
                                    if ($teacher_all["status"][$r]) echo '<span class="badge badge-success" style="background-color:#48C9B0;"><i class="fas fa-lock-open"></i> Activated</span>';
                                    else  echo '<span class="badge badge-danger" style="background-color:#E59866;"><i class="fas fa-lock"></i> Deactivated</span>';
                                ?>
                            </td>
                            
                    </table>
                </div>
                </div>
            </div>
        </div>
                          </td>
                        </tr>
                        <?php
                    }
                }
            ?> 
                </tbody id="controlteachermainoutput1">
                <tfoot class="table">
                <tr>
                  <th># Teacher ID</th>
                  <th>Fullname</th>
                  <th>Contact</th>
                  <th>Email</th>
                  <th>Code</th>
                  <th>Pass</th>
                  <th>View</th>
                  <th>Status</th>
                  <th># Teacher ID</th>
                </tr>
                </tfoot>
              </table>
            </div>
          </div>

        </div>
      </div>
    </section>

</div>
  </div>
<?php 
    include 'themepart/bottom.php';
?>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/teacherlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function() {
    $("#datatableteacheracc").DataTable();
    $('#datatableteacher2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
    });
  });
</script>

</body>
</html>


